import { BaseComponent } from '../base.com.js';

// export class DropdownTreeComponent extends BaseComponent {
// 	private LOC_TREE_ITEM = '//div[@role="menu"]//amp-select-tree-item';
// 	private LOC_COLUMN_FILTER_ITEM = (tmp: string) =>
// 		`//div[@role="menu"]//amp-select-tree-item//span[normalize-space(text())="${tmp}"]`;
// 	private LOC_COLUMN_EXPAND_ICON = (tmp: string) =>
// 		`//div[@role="menu"]//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]]//amp-button`;

// 	public async selectItem(path: string[]) {
// 		for (const part of path) {
// 			let isElementFound = false;
// 			while (!isElementFound) {
// 				const elements = await this.page.locator(this.LOC_TREE_ITEM).all();
// 				for (const element of elements) {
// 					const textContent = await element.textContent();
// 					if (textContent?.trim() === part) {
// 						isElementFound = true;
// 						if (path[path.length - 1] === part) {
// 							await this.page.locator(this.LOC_COLUMN_FILTER_ITEM(part)).click();
// 						} else {
// 							let viewBox = await element.locator('//*[name()="svg"]').getAttribute('viewBox');
// 							if (viewBox?.includes('320')) {
// 								await this.page.locator(this.LOC_COLUMN_EXPAND_ICON(part)).click();
// 							}
// 						}

// 						break;
// 					}
// 				}

// 				if (!isElementFound) {
// 					const lastElement = elements[elements.length - 1];
// 					if (lastElement) {
// 						await lastElement.scrollIntoViewIfNeeded();
// 						await this.page.waitForTimeout(500);
// 					} else {
// 						throw new Error(`Element "${part}" not found in the tree`);
// 					}
// 				}
// 			}
// 		}

// 		await this.pressKeyboardButton('Escape');
// 	}
// }

export class DropdownTreeComponent extends BaseComponent {
	// private LOC_TREE_ITEM = '//div[@role="menu"]//amp-select-tree-item';
	// 	private LOC_COLUMN_FILTER_ITEM = (tmp: string) =>
	// 		`//div[@role="menu"]//amp-select-tree-item//span[normalize-space(text())="${tmp}"]`;
	// 	private LOC_COLUMN_EXPAND_ICON = (tmp: string) =>
	// 		`//div[@role="menu"]//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]]//amp-button`;

	private LOC_TREE_ITEM = (level: number) =>
		`//div[@role="menu"]//amp-select-tree-item[@style="--item-level: ${level};"]`;
	private LOC_COLUMN_FILTER_ITEM = (tmp: string, level: number) =>
		`//div[@role="menu"]//amp-select-tree-item[@style="--item-level: ${level};"]//span[normalize-space(text())="${tmp}"]`;
	private LOC_COLUMN_EXPAND_ICON = (tmp: string, level: number) =>
		`//div[@role="menu"]//amp-select-tree-item[@style="--item-level: ${level};"][.//span[normalize-space(text())="${tmp}"]]//amp-button`;

	public async selectItem(path: string[]) {
		for (let level = 0; level < path.length; level++) {
			const part = path[level];
			let isElementFound = false;

			while (!isElementFound) {
				const elements = await this.page.locator(this.LOC_TREE_ITEM(level)).all();
				for (const element of elements) {
					const textContent = await element.textContent();
					if (textContent?.trim() === part) {
						isElementFound = true;

						if (level === path.length - 1) {
							// Click the final item
							await this.page.locator(this.LOC_COLUMN_FILTER_ITEM(part!, level)).click();
						} else {
							// Expand the current item if it has a collapse/expand button
							const viewBox = await element.locator('//*[name()="svg"]').getAttribute('viewBox');
							if (viewBox?.includes('320')) {
								await this.page.locator(this.LOC_COLUMN_EXPAND_ICON(part!, level)).click();
							}
						}
						break;
					}
				}

				if (!isElementFound) {
					const lastElement = elements[elements.length - 1];
					if (lastElement) {
						await lastElement.scrollIntoViewIfNeeded();
						await this.page.waitForTimeout(500);
					} else {
						throw new Error(`Element "${part}" not found at level ${level}`);
					}
				}
			}
		}

		// Close the dropdown if necessary
		await this.pressKeyboardButton('Escape');
	}
}
