import { BaseComponent } from '../base.com.js';

export class ScheduleComponent extends BaseComponent {
	private readonly LOC_CLOSE_BTN = '//ngb-modal-window[@role="dialog"]//amp-icon[@iconname="xmark"]';
	private readonly LOC_APPLY_BTN = '//ngb-modal-window[@role="dialog"]//amp-button[@category="success"]';

	/* PAGE ACTIONS */
	public async clickCloseScheduleButton() {
		await this.page.locator(this.LOC_CLOSE_BTN).click();
	}

	public async clickApplyScheduleButton() {
		await this.page.locator(this.LOC_APPLY_BTN).click();
	}
}
