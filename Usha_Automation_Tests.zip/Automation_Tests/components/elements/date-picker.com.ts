import { BaseComponent } from '../base.com.js';

export class DatePickerComponent extends BaseComponent {
	private LOC_DATE_PICKER = '//div[contains(@class,"flatpickr-calendar") and contains(@class,"open")]';
	private LOC_MONTH_SEL = '//select[@aria-label="Month"]';
	private LOC_DAY_LBL = (day: string, month: string, year: string) => `//span[@aria-label="${month} ${day}, ${year}"]`;
	private LOC_YEAR_INP = '//input[@aria-label="Year"]';
	private LOC_YEAR_UP = '//span[@class="arrowUp"]';
	private LOC_YEAR_DOWN = '//span[@class="arrowDown"]';

	public async isDatepickerOpen(): Promise<boolean> {
		const datePicker = this.page.locator(this.LOC_DATE_PICKER);
		return (await datePicker.count()) > 0 ? true : false;
	}

	public async selectDate(date: string) {
		const targetDate = new Date(date);
		const year = targetDate.getFullYear();
		const month = targetDate.toLocaleString('default', { month: 'long' });
		const day = targetDate.getDate();

		await this.selectMonth(month);
		await this.selectYear(year);
		await this.selectDay(day.toString(), month, year.toString());
	}

	public async selectDateRange(fromDate: string, toDate: string) {
		const from = new Date(fromDate);
		const to = new Date(toDate);

		await this.selectDay(
			from.getDate().toString(),
			from.toLocaleString('default', { month: 'long' }),
			from.getFullYear().toString()
		);
		await this.selectDay(
			to.getDate().toString(),
			to.toLocaleString('default', { month: 'long' }),
			to.getFullYear().toString()
		);
	}

	private async selectMonth(month: string) {
		const datePicker = this.page.locator(this.LOC_DATE_PICKER);
		await datePicker.waitFor();
		const monthDropdownSelector = datePicker.locator(this.LOC_MONTH_SEL);
		await monthDropdownSelector.selectOption(month);
	}

	private async selectDay(day: string, month: string, year: string) {
		const datePicker = this.page.locator(this.LOC_DATE_PICKER);
		await datePicker.waitFor();
		await datePicker.locator(this.LOC_DAY_LBL(day, month, year)).first().click();
	}

	private async selectYear(year: number) {
		const datePicker = this.page.locator(this.LOC_DATE_PICKER);
		await datePicker.waitFor();
		const currentValueStr = await datePicker.locator(this.LOC_YEAR_INP).inputValue();
		const currentValue = Number(currentValueStr);
		const yearShift = year - currentValue;
		if (yearShift === 0) {
			return;
		}

		const arrowLocator = yearShift > 0 ? datePicker.locator(this.LOC_YEAR_UP) : datePicker.locator(this.LOC_YEAR_DOWN);
		for (let i = 0; i < Math.abs(yearShift); i++) {
			await arrowLocator.click();
			await this.page.waitForTimeout(500);
		}
	}
}
