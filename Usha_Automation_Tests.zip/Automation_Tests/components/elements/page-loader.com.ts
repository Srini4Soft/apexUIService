import { expect } from '@playwright/test';
import log from 'src/common/utils/logger.js';
import { BaseComponent } from '../base.com.js';

export class PageLoaderComponent extends BaseComponent {
	private LOC_SPLASH_SCREEN = '#splashScreen';
	private LOC_ROUND_SPINNER = '//amp-spinner';
	private LOC_DOTS_SPINNER = '//*[contains(@class,"amp-button__three-dots")]';

	public async waitForPageLoad(time: number = 60 * 1000): Promise<void> {
		log.info('Wait for page load');
		await expect(this.page.locator(this.LOC_SPLASH_SCREEN)).toHaveCount(0, { timeout: time });
		await expect(this.page.locator(this.LOC_ROUND_SPINNER)).toHaveCount(0, { timeout: time });
		await expect(this.page.locator(this.LOC_DOTS_SPINNER)).toHaveCount(0, { timeout: time });
		await this.page.waitForTimeout(1000);
	}
}
