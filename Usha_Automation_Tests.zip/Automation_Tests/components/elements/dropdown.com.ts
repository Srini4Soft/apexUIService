import { BaseComponent } from '../base.com.js';

export class DropdownComponent extends BaseComponent {
	private LOC_DROPDOWN_ITEM = (tmp: string) =>
		`(//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//span[contains(normalize-space(text()),"${tmp}")])[1]`;
	private LOC_DROPDOWN_ITEM_CUSTOM = (tmp: string) =>
		`(//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//amp-custom-option-template[contains(normalize-space(text()),"${tmp}")])[1]`;

	private LOC_DROPDOWN_ITEM_EXACT = (tmp: string) =>
		`(//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//span[normalize-space(text())="${tmp}"])[1]`;
	private LOC_DROPDOWN_ITEM_CUSTOM_EXACT = (tmp: string) =>
		`(//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//amp-custom-option-template[normalize-space(text())="${tmp}"])[1]`;

	public async selectItem(value: string) {
		const defaultLocator = this.page.locator(this.LOC_DROPDOWN_ITEM(value));
		const customLocator = this.page.locator(this.LOC_DROPDOWN_ITEM_CUSTOM(value));
		if ((await customLocator.count()) > 0) {
			await customLocator.first().click();
		} else {
			await defaultLocator.first().click();
		}
	}

	public async selectExactItem(value: string) {
		const defaultLocator = this.page.locator(this.LOC_DROPDOWN_ITEM_EXACT(value));
		const customLocator = this.page.locator(this.LOC_DROPDOWN_ITEM_CUSTOM_EXACT(value));
		if ((await customLocator.count()) > 0) {
			await customLocator.first().click();
		} else {
			await defaultLocator.first().click();
		}
	}
}
