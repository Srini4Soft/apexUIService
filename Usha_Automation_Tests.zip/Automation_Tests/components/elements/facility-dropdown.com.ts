import { Locator } from '@playwright/test';
import { BaseComponent } from '../base.com.js';

export class FacilityDropdownComponent extends BaseComponent {
	private LOC_FACILITY_SEARCH_INP = '//amp-input[@data-test-id="amp-select-tree-search-input"]//input';
	private LOC_FACILITY_TREE_ITM = (tmp: string) =>
		`//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]][1]`;

	public async selectFacility(value: string) {
		const inputElement: Locator = this.page.locator(this.LOC_FACILITY_SEARCH_INP);
		const itemElement: Locator = this.page.locator(this.LOC_FACILITY_TREE_ITM(value));

		await inputElement.clear();
		await this.page.waitForTimeout(500);
		await inputElement.pressSequentially(value);
		await this.page.waitForTimeout(500);
		await itemElement.click();
		await this.page.waitForTimeout(500);
	}
}
