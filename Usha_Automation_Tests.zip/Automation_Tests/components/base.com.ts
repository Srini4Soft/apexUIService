import { Page } from '@playwright/test';
import { PageInstance } from 'src/common/helpers/page-instance.js';

export abstract class BaseComponent {
	protected page: Page;

	constructor() {
		this.page = PageInstance.getInstance().getPage();
	}

	public async waitForTimeout(time: number): Promise<void> {
		await this.page.waitForTimeout(time);
	}

	public async pressKeyboardButton(key: string) {
		await this.page.keyboard.press(key);
	}
}
