import { defineConfig } from '@playwright/test';

export default defineConfig({
	timeout: 5 * 60 * 1000, // maximum time one test can run for
	expect: {
		timeout: 10 * 1000, // maximum time expect() should wait for the condition to be met.
	},
	fullyParallel: false,
	retries: process.env.CI ? 1 : 1,
	workers: 2,
	reporter: [
		['html', { open: 'never' }],
		['junit', { outputFile: 'test-results/results.xml' }],
	],
	use: {
		actionTimeout: 60000,
		browserName: 'chromium',
		channel: 'chrome',
		headless: true,
		ignoreHTTPSErrors: true,
		launchOptions: {
			slowMo: 100, // slow down execution (by N milliseconds per operation)
		},
		navigationTimeout: 60000,
		screenshot: 'only-on-failure',
		viewport: {
			width: 1680,
			height: 840,
		},
	},
	projects: [
		{
			name: 'rcm-all',
			testDir: './tests/rcm',
			use: {
				baseURL: process.env['APEX_ENV'] || 'https://deploytest-dev.axgsolutions.com/',
			},
		},
		{
			name: 'fcc-all',
			testDir: './tests/fcc',
			use: {
				baseURL: process.env['APEX_ENV'] || 'https://fcc-stage.axgsolutions.com/',
				storageState: './.auth/user.json',
			},
		},
	],
});

export const loginInfoDeploy = {
	URL: process.env['APEX_ENV_LOGIN'] || 'https://deploytest-login-dev.axgsolutions.com/',
	baseURL: process.env['APEX_ENV'] || 'https://deploytest-dev.axgsolutions.com/',
	username: process.env['APEX_USERNAME'] || 'AlexVovk1',
	password: process.env['APEX_PASSWORD'] || 'test012!',
};

export const apiRequestData = {
	apiURL: process.env['APEX_API_URL'] || 'https://deploytest-api-dev.axgsolutions.com/api/',
	client_id: process.env['CLIENT_ID'] || 'RMP.WebSite',
	client_secret: process.env['CLIENT_SECRET'] || '5wY4algZDuEyR//IXAf1/uYXrtHjOc2TXmS6syv+j8g=',
	scope: 'RMP.API openid profile offline_access',
	username: process.env['APEX_USERNAME'] || 'AlexVovk1',
	password: process.env['APEX_PASSWORD'] || 'test012!',
};
