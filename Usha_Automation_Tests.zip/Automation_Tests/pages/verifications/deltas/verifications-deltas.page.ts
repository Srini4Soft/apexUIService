import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class VerificationDeltasPage extends BasePage {
	private readonly LOC_SELECT_VIEW_DRP = '//amp-grid-title//h2//amp-select';

	public async open(): Promise<void> {
		const url = URL.VERIFICATION_DELTAS;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */

	/* ASSERTIONS */
	public async isSelectViewDropdownVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_SELECT_VIEW_DRP).isVisible();
	}
}
