import { BasePage } from 'src/pages/base.page.js';

export class ResidentsDetailsPage extends BasePage {
	private LOC_DOCUMENTS_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/documents") + 1) = "/documents"]';

	public async clickOnDocumentsTab(): Promise<void> {
		await this.page.locator(this.LOC_DOCUMENTS_TAB).click();
	}

	/* DOCUMENTS PAGE */
	public async addFileToUpload(filePath: string): Promise<void> {
		const handle = this.page.locator('//amp-add-file//input[@type="file"]');
		await handle.setInputFiles(filePath);
	}

	public async startUpload(): Promise<void> {
		const button = this.page.locator('//amp-add-file//amp-button/button[./span[normalize-space() = "Start Upload"]]');
		await button.click();
	}
}
