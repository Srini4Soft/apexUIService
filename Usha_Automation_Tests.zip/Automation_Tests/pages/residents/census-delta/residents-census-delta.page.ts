import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class ResidentsCensusDeltaPage extends BasePage {
	private readonly LOC_SELECT_CURRENT_INP = '//amp-select[@data-test-id="amp-census-delta-from-source"]//input';
	private readonly LOC_SELECT_SOURCE_INP = '//amp-select[@data-test-id="amp-census-delta-to-source"]//input';
	private readonly LOC_COMMON_SECTION_TITLE = (tmp: string) => `//amp-portlet//span[text()="${tmp}"]`;

	public async open(): Promise<void> {
		const url = URL.RESIDENTS_CENSUS_DELTA;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async fillFromSource(value: string) {
		await this.page.locator(this.LOC_SELECT_CURRENT_INP).fill(value);
	}

	public async fillToSource(value: string) {
		await this.page.locator(this.LOC_SELECT_SOURCE_INP).fill(value);
	}

	/* ASSERTIONS */
	public async isSectionVisible(value: string): Promise<boolean> {
		return this.page.locator(this.LOC_COMMON_SECTION_TITLE(value)).isVisible();
	}
}
