import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class ResidentsDashboardPage extends BasePage {
	private readonly LOC_COMMON_WIDGET_TITLE = (tmp: string) => `//amp-dashboard//span[text()="${tmp}"]`;

	public async open(): Promise<void> {
		const url = URL.RESIDENTS_DASHBOARD;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */

	/* ASSERTIONS */
	public async isWidgetTitleVisible(value: string): Promise<boolean> {
		return this.page.locator(this.LOC_COMMON_WIDGET_TITLE(value)).isVisible();
	}
}
