import { Locator, Page } from '@playwright/test';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import {
	DatePickerComponent,
	DropdownComponent,
	DropdownTreeComponent,
	FacilityDropdownComponent,
	PageLoaderComponent,
	ScheduleComponent,
} from 'src/components/index.js';

export abstract class BasePage {
	protected page: Page;
	private comDropdown: DropdownComponent;
	private comDropdownTree: DropdownTreeComponent;
	private comDatePicker: DatePickerComponent;
	private comFacilityDropdown: FacilityDropdownComponent;
	private comPageLoader: PageLoaderComponent;
	private comSchedule: ScheduleComponent;

	constructor() {
		this.page = PageInstance.getInstance().getPage();
		this.comDropdown = new DropdownComponent();
		this.comDropdownTree = new DropdownTreeComponent();
		this.comDatePicker = new DatePickerComponent();
		this.comFacilityDropdown = new FacilityDropdownComponent();
		this.comPageLoader = new PageLoaderComponent();
		this.comSchedule = new ScheduleComponent();
	}

	public getUrl(): string {
		return this.page.url();
	}

	public async waitForTimeout(time: number): Promise<void> {
		await this.page.waitForTimeout(time);
	}

	public async waitForPageLoad(): Promise<void> {
		await this.comPageLoader.waitForPageLoad();
	}

	public async clickOn(locator: string) {
		await this.page.locator(locator).click();
	}

	public async pressKeyboardButton(key: string): Promise<void> {
		await this.page.keyboard.press(key);
	}

	public async keyboardType(value: string): Promise<void> {
		await this.page.keyboard.type(value);
	}

	public async reloadPage(): Promise<void> {
		await this.page.reload();
	}

	public async setExactDropdownValue(locator: Locator, value: string): Promise<void> {
		await locator.click();
		await this.waitForPageLoad();
		await this.comDropdown.selectExactItem(value);
	}

	public async setDropdownValue(locator: Locator, value: string): Promise<void> {
		await locator.scrollIntoViewIfNeeded();
		await locator.click();
		await this.waitForPageLoad();
		await this.comDropdown.selectItem(value);
	}

	public async setSearchDropdownValue(locator: Locator, value: string): Promise<void> {
		await locator.click();
		await locator.locator('//input').pressSequentially(value);
		await this.waitForPageLoad();
		await this.comDropdown.selectItem(value);
	}

	/** Use if dropdown list is already open */
	public async selectDropdownValue(value: string): Promise<void> {
		await this.comDropdown.selectItem(value);
	}

	public async setDropdownTreeValue(locator: Locator, value: string[]): Promise<void> {
		await locator.click();
		await this.waitForPageLoad();
		await this.comDropdownTree.selectItem(value);
	}

	/** Facility selector with search field and tree items view */
	public async setFacilityDropdownValue(locator: Locator, value: string): Promise<void> {
		await locator.click();
		await this.comFacilityDropdown.selectFacility(value);
	}

	public async setInputValue(locator: Locator, value: string): Promise<void> {
		await locator.clear();
		await locator.pressSequentially(value);
	}

	public async setDateValue(locator: Locator, value: string): Promise<void> {
		if (!(await this.comDatePicker.isDatepickerOpen())) {
			await locator.click();
		}
		await this.comDatePicker.selectDate(value);
	}

	public async setCheckboxValue(locator: Locator, value: boolean): Promise<void> {
		if ((await this.getCheckboxValue(locator)) != value) {
			await locator.click();
		}
	}

	public async setSchedule(locator: Locator, value: boolean): Promise<void> {
		if (!value) return;
		await locator.click();
		await this.comSchedule.clickApplyScheduleButton();
	}

	public async getCheckboxValue(locator: Locator): Promise<boolean> {
		const classList = await locator.getAttribute('class');
		if (classList!.includes('amp-checkbox--selected')) {
			return true;
		} else if (classList!.includes('amp-checkbox--unselected')) {
			return false;
		} else {
			return false;
		}
	}

	public async isFieldDisplayed(element: string): Promise<boolean> {
		const locator = `//*[@formcontrolname="${element}"]`;
		const result = await this.page.locator(locator).count();
		return result > 0 ? true : false;
	}

	public async isFieldReadonly(element: string): Promise<boolean> {
		const locator = `//*[@formcontrolname="${element}"]`;
		const mainElement = await this.page.locator(locator).count();
		const targetElement = await this.page.locator(locator + '//input').count();
		return mainElement > 0 && targetElement == 0 ? true : false;
	}

	public async isFieldRequired(element: string): Promise<boolean> {
		await this.page.waitForTimeout(3000);
		const locator = `//*[@formcontrolname="${element}"]//label//span[contains(@class,"amp-input__required")]`;
		const result = await this.page.locator(locator).count();
		return result > 0 ? true : false;
	}
}
