import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class NotificationRulesPage extends BasePage {
	private readonly LOC_CREATE_RULE_BTN = '//amp-grid-title//h2//amp-button';

	public async open(): Promise<void> {
		const url = URL.SETTINGS_NOTIFICATION_RULES;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async clickOnCreateRuleButton() {
		await this.page.locator(this.LOC_CREATE_RULE_BTN).click();
	}

	/* ASSERTIONS */
	public async isCreateRuleButtonDisplayed(): Promise<boolean> {
		return await this.page.locator(this.LOC_CREATE_RULE_BTN).isVisible();
	}
}
