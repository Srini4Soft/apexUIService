import { expect, Locator } from '@playwright/test';
import { BasePage } from '../../base.page.js';

export class ManageNotificationRulePage extends BasePage {
	// Rules locators
	private readonly LOC_NAME_INP = '//amp-input[@formcontrolname="name"]//input';
	private readonly LOC_APPLY_FACILITIES_BTN =
		'//form//amp-facility-filter//amp-button[@data-test-id="amp-facility-filter-open-btn"]/following-sibling::amp-button';
	private readonly LOC_EVENT_TYPES_BTN = '//amp-select-tree[@formcontrolname="eventTypeIds"]';
	private readonly LOC_ENABLED_CHB = '//amp-checkbox[@formcontrolname="isEnabled"]/label';
	private readonly LOC_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]/label';
	private readonly LOC_SKIP_SENDING_CHB = '//amp-checkbox[@formcontrolname="skipSendOnHolidays"]/label';
	// Recipients locators
	// private readonly locDropdownItem = '//ng-dropdown-panel[@role="listbox"]//div[@role="option"]';
	private readonly LOC_GROUP_SEL = '//amp-select[@formcontrolname="groupIds"]';
	// private readonly locGroupValue =
	// 	'//amp-select[@formcontrolname="groupIds"]//ng-select//span[contains(@class,"amp-select__option")]';
	private readonly LOC_FACILITY_CONTACT_TYPES_SEL = '//amp-select[@formcontrolname="facilityContactTypeIds"]';
	// private readonly locFacilityContactTypesValue =
	// 	'//amp-select[@formcontrolname="facilityContactTypeIds"]//ng-select//span[contains(@class,"amp-select__option")]';
	private readonly LOC_USER_SEL = '//amp-select[@formcontrolname="userIds"]';
	// private readonly locUsersValue =
	// 	'//amp-select[@formcontrolname="userIds"]//ng-select//span[contains(@class,"amp-select__option")]';
	private readonly LOC_EMAILS_INP = '//amp-select[@formcontrolname="emails"]//ng-select//input';
	// private readonly locEmailsValue =
	// 	'//amp-select[@formcontrolname="emails"]//ng-select//span[@class="ng-value-label ng-star-inserted"]';
	private readonly LOC_RECIPIENT_USER_CHB = '//amp-checkbox[@formcontrolname="notifyRecipientUser"]/label';
	private readonly LOC_SEND_SINGLE_EMAIL_CHB = '//amp-checkbox[@formcontrolname="sendSingleEmail"]/label';
	private readonly LOC_INCLUDE_INITIATOR_CHB = '//amp-checkbox[@formcontrolname="includeInitiator"]/label';
	private readonly LOC_EXCLUDE_INITIATOR_CHB = '//amp-checkbox[@formcontrolname="excludeInitiator"]/label';
	// Digest of Notifications locators
	private readonly LOC_DIGEST_NOTIFICATION_CHB = '//amp-checkbox[@formcontrolname="isDigestNotifications"]/label';
	private readonly LOC_RECIPIENT_GROUP_TYPE_SEL = '//amp-select[@formcontrolname="recipientGroupType"]';
	// private readonly locRecipientGroupTypeValue =
	// 	'//amp-select[@formcontrolname="recipientGroupType"]//ng-select//span[contains(@class,"amp-select__option")]';
	private readonly LOC_EVENTS_THRESHOLD_INP = '//amp-input[@formcontrolname="eventsThreshold"]//input';
	private readonly LOC_SCHEDULE_BTN = '//form//amp-portlet[2]//div[@portletbody]//amp-button';
	// Actions locators
	private readonly LOC_ADD_ACTION_BTN = '//amp-notification-rule-actions//amp-button[@shape="rounded"]';
	private readonly LOC_ACTIONS_METHOD = '//amp-notification-rule-actions//amp-button[@category="link"]//span';
	private readonly LOC_ACTION_TEMPLATE = '//amp-notification-rule-actions//div[@class="align-items-center"]';
	// Footer locators
	private readonly LOC_FINISH_BTN = '//footer//button//span[contains(text(),"Finish")]/..';
	private readonly LOC_SAVE_BTN = '//footer//button//span[contains(text(),"Save")]/..';
	private readonly LOC_CANCEL_BTN = '//footer//button//span[contains(text(),"Cancel")]/..';
	// Add action modal window locators
	private readonly LOC_ADD_ACTION_APPLY_BTN = '//ngb-modal-window[@role="dialog"]//amp-button[@category="success"]';
	private readonly LOC_ADD_ACTION_METHOD_INP = '//amp-select[@formcontrolname="method"]';
	private readonly LOC_ADD_ACTION_TEMPLATE_INP = '//amp-select[@formcontrolname="notificationTemplateId"]';

	/* Actions for Rules section */
	public async fillName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async clickApplyFacilitiesButton(): Promise<void> {
		await this.page.locator(this.LOC_APPLY_FACILITIES_BTN).click();
	}

	public async fillEventTypes(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EVENT_TYPES_BTN);
		await this.setDropdownTreeValue(element, [value]);
		await this.pressKeyboardButton('Escape');
	}

	public async fillEnabled(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ENABLED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillGlobal(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillSkipSending(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SKIP_SENDING_CHB);
		await this.setCheckboxValue(element, value);
	}

	/* Actions for Recipients section */
	public async fillGroups(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_GROUP_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillFacilityContactTypes(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FACILITY_CONTACT_TYPES_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillUsers(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_USER_SEL);
		await this.setSearchDropdownValue(element, value);
	}

	public async fillEmails(value: string): Promise<void> {
		await this.page.locator(this.LOC_EMAILS_INP).fill(value);
		await this.page.keyboard.press('Enter');
	}

	public async fillRecipientUsers(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_RECIPIENT_USER_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillSendSingleEmail(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SEND_SINGLE_EMAIL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillIncludeInitiator(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_INCLUDE_INITIATOR_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillExcludeInitiator(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EXCLUDE_INITIATOR_CHB);
		await this.setCheckboxValue(element, value);
	}

	/* Actions for Digest of Notifications section */
	public async fillDigestOfNotifications(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DIGEST_NOTIFICATION_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillRecipientGroupType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_RECIPIENT_GROUP_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillEventsThreshold(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EVENTS_THRESHOLD_INP);
		await this.setInputValue(element, value);
	}

	public async fillSchedule(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SCHEDULE_BTN);
		await this.setSchedule(element, value);
	}

	/* Actions for Action section */
	public async clickActionsButton() {
		await this.page.locator(this.LOC_ADD_ACTION_BTN).click();
	}

	public async fillActionMethod(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ADD_ACTION_METHOD_INP);
		await this.setDropdownValue(element, value);
	}

	public async fillActionTemplate(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ADD_ACTION_TEMPLATE_INP);
		await this.setDropdownValue(element, value);
	}

	public async getActionMethodValue(): Promise<string> {
		const value = await this.page.locator(this.LOC_ACTIONS_METHOD).textContent();
		if (!value) {
			return '';
		} else {
			return value.trim();
		}
	}

	public async getActionTemplateValue(): Promise<string> {
		const value = await this.page.locator(this.LOC_ACTION_TEMPLATE).textContent();
		if (!value) {
			return '';
		} else {
			return value.trim();
		}
	}

	public async clickApplyActionButton() {
		await expect(this.page.locator(this.LOC_ADD_ACTION_APPLY_BTN), 'Is actions "Apply" button visible?').toBeVisible();
		await this.page.locator(this.LOC_ADD_ACTION_APPLY_BTN).click();
	}

	public async clickFinishButton() {
		await expect(this.page.locator(this.LOC_FINISH_BTN), 'Is "Finish" rule button visible?').toBeVisible();
		await this.page.locator(this.LOC_FINISH_BTN).click();
	}

	public async clickSaveButton() {
		await expect(this.page.locator(this.LOC_SAVE_BTN), 'Is "Save" rule button visible?').toBeVisible();
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}

	public async clickCancelButton() {
		await expect(this.page.locator(this.LOC_CANCEL_BTN), 'Is "Cancel" rule button visible?').toBeVisible();
		await this.page.locator(this.LOC_CANCEL_BTN).click();
	}

	/* CHECKING THE STATUS OF ELEMENTS */

	public async isFinishButtonDisabled(): Promise<boolean> {
		await this.page.waitForTimeout(500);
		return await this.page.locator(this.LOC_FINISH_BTN).isDisabled();
	}

	public async isSaveButtonDisabled(): Promise<boolean> {
		await this.page.waitForTimeout(500);
		return await this.page.locator(this.LOC_SAVE_BTN).isDisabled();
	}
}
