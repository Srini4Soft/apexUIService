import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class SettingsEventLogPage extends BasePage {
	public async open(): Promise<void> {
		const url = URL.SETTINGS_EVENT_LOG;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */

	/* ASSERTIONS */
}
