import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ManagePayerPage extends BasePage {
	private LOC_PAYER_CATEGORY_SEL = '//amp-select[@formcontrolname="payerCategoryId"]';
	private LOC_NAME_INP = '//amp-input[@formcontrolname="name"]//input';
	private LOC_PRIMARY_PAYER_SEL = '//amp-select[@formcontrolname="primaryPayerId"]';
	private LOC_DESCRIPTION_INP = '//amp-input[@formcontrolname="description"]//textarea';
	private LOC_IS_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]/label';
	private LOC_CAN_BE_PRIMARY_CHB = '//amp-checkbox[@formcontrolname="canBePrimary"]/label';
	private LOC_CAN_BE_ANCILLARY_CHB = '//amp-checkbox[@formcontrolname="canBeAncillary"]/label';
	private LOC_CAN_BE_COINSURANCE_CHB = '//amp-checkbox[@formcontrolname="canBeCoinsurance"]/label';
	private LOC_ELIGIBILITY_PROVIDER_KEY_SEL = '//amp-select[@formcontrolname="eligibilityProviderKey"]';
	private LOC_STATE_SEL = '//amp-select[@formcontrolname="primaryStateId"]';
	private LOC_DISCHARGE_BILLING_TYPE_SEL = '//amp-select[@formcontrolname="dischargeBillingType"]';
	private LOC_REQUIRES_AUTH_CHB = '//amp-checkbox[@formcontrolname="requiresAuthorization"]/label';
	private LOC_SIMPLIFIED_CHB = '//amp-checkbox[@formcontrolname="simplifiedAuthorization"]/label';
	private LOC_VERIFY_DEFAULT_START_TYPE_SEL = '//amp-select[@formcontrolname="verificationDefaultStartType"]';
	private LOC_IS_PENDING_CHB = '//amp-checkbox[@formcontrolname="isPending"]/label';
	private LOC_REVIEWED_ON_DAT = '//amp-input[@formcontrolname="reviewedOn"]//input';
	private LOC_FINISH_BTN = '//footer//amp-button//span[contains(text(),"Finish")]';
	private LOC_SAVE_BTN = '//footer//amp-button//span[contains(text(),"Save")]';
	private LOC_CANCEL_BTN = '//footer//amp-button//span[contains(text(),"Cancel")]';

	public async fillPayerCategory(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_PAYER_CATEGORY_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillPrimaryPayer(value: string): Promise<void> {
		const locator =
			'(//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//amp-payer-option-template//div[contains(., "${tmp}") and not(div)])[last()]';
		await this.page.locator(this.LOC_PRIMARY_PAYER_SEL).click();
		await this.page.locator(locator.replace('${tmp}', value)).click();
	}

	public async fillDescription(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DESCRIPTION_INP);
		await this.setInputValue(element, value);
	}

	public async fillIsGlobal(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillCanBePrimary(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CAN_BE_PRIMARY_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillCanBeAncillary(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CAN_BE_ANCILLARY_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillCanBeCoinsurance(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CAN_BE_COINSURANCE_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillEligibilityProviderKey(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ELIGIBILITY_PROVIDER_KEY_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillState(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_STATE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillDischargeBillingType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DISCHARGE_BILLING_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillRequiresAuthorization(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_REQUIRES_AUTH_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillSimplified(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SIMPLIFIED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillVerificationDefaultStartType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_VERIFY_DEFAULT_START_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillIsPending(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_PENDING_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillReviewedOn(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_REVIEWED_ON_DAT);
		await this.setDateValue(element, value);
	}

	public async clickSaveButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}

	public async clickCancelButton(): Promise<void> {
		await this.page.locator(this.LOC_CANCEL_BTN).click();
	}

	/* ELEMENTS VERIFICATION */
	public async isNameInputVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_NAME_INP).isVisible();
	}

	public async isFinishButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_FINISH_BTN).isVisible();
	}

	public async isSaveButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_SAVE_BTN).isVisible();
	}

	public async isCancelButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_CANCEL_BTN).isVisible();
	}
}
