import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ManagePersonPage extends BasePage {
	private LOC_FACILITIES_SEL = '//amp-select-tree[@formcontrolname="facilityIds"]//amp-button';
	private LOC_TYPE_SEL = '//amp-select[@formcontrolname="type"]';
	private LOC_LAST_NAME_INP = '//amp-input[@formcontrolname="lastName"]//input';
	private LOC_FIRST_NAME_INP = '//amp-input[@formcontrolname="firstName"]//input';
	private LOC_MIDDLE_NAME_INP = '//amp-input[@formcontrolname="middleName"]//input';
	private LOC_GENDER_SEL = '//amp-select[@formcontrolname="gender"]';
	private LOC_BIRTH_DAT = '//amp-input[@formcontrolname="birthDate"]//input';
	private LOC_DOCTOR_SPEC_INP = '//amp-input[@formcontrolname="speciality"]//input';
	private LOC_NPI_INP = '//amp-input[@formcontrolname="npi"]//input';
	private LOC_ADDRESS_ONE_INP = '//amp-input[@formcontrolname="addressLine1"]//input';
	private LOC_ADDRESS_TWO_INP = '//amp-input[@formcontrolname="addressLine2"]//input';
	private LOC_CITY_INP = '//amp-input[@formcontrolname="city"]//input';
	private LOC_STATE_SEL = '//amp-select[@formcontrolname="stateId"]';
	private LOC_ZIP_CODE_INP = '//amp-input[@formcontrolname="zipCode"]//input';
	private LOC_COUNTRY_SEL = '//amp-select[@formcontrolname="countyId"]';
	private LOC_EMAIL_INP = '//amp-input[@formcontrolname="email"]//input';
	private LOC_WORK_NUMBER_INP = '//amp-input[@formcontrolname="workPhoneNumber"]//input';
	private LOC_WORK_NUMBER_EXT_INP = '//amp-input[@formcontrolname="workPhoneNumberExt"]//input';
	private LOC_MOBILE_NUMBER_INP = '//amp-input[@formcontrolname="mobilePhoneNumber"]//input';
	private LOC_HOME_NUMBER_INP = '//amp-input[@formcontrolname="homePhoneNumber"]//input';
	private LOC_FAX_NUMBER_INP = '//amp-input[@formcontrolname="faxNumber"]//input';
	private LOC_USER_SEL = '//amp-select[@formcontrolname="userId"]';
	private LOC_EMPLOYEE_START_DAT = '//amp-input[@formcontrolname="employeeStartDate"]//input';
	private LOC_LOCATION_INP = '//amp-input[@formcontrolname="location"]//input';
	private LOC_IS_APPROVED_CHB = '//amp-checkbox[@formcontrolname="isApproved"]/label';
	private LOC_IS_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]/label';
	private LOC_ADD_ORGANIZATION_BTN = '//amp-button[@shape="rounded" and @icon="plus" and @category="secondary"]';
	private LOC_ORGANIZATION_SEL = '//amp-select[@formcontrolname="organizationId"]';
	private LOC_POSITION_SEL = '//amp-select[@formcontrolname="lookupPositionId"]';
	private LOC_CREATE_BTN = '//footer//amp-button[@category="success"]';

	/* FILL FORM */

	public async fillType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillLastName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_LAST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillFirstName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FIRST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillMiddleName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MIDDLE_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillGender(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_GENDER_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillBirthDate(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_BIRTH_DAT);
		await this.setDateValue(element, value);
	}

	public async fillIsApproved(value: boolean) {
		const element: Locator = this.page.locator(this.LOC_IS_APPROVED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillIsGlobal(value: boolean) {
		const element: Locator = this.page.locator(this.LOC_IS_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillFacility(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FACILITIES_SEL);
		await this.setFacilityDropdownValue(element, value);
		await this.pressKeyboardButton('Escape');
	}

	public async fillDoctorSpeciality(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DOCTOR_SPEC_INP);
		await this.setInputValue(element, value);
	}

	public async fillNpi(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_NPI_INP);
		await this.setInputValue(element, value);
	}

	public async fillAddressLineOne(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ADDRESS_ONE_INP);
		await this.setInputValue(element, value);
	}

	public async fillAddressLineTwo(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ADDRESS_TWO_INP);
		await this.setInputValue(element, value);
	}

	public async fillCity(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CITY_INP);
		await this.setInputValue(element, value);
	}

	public async fillState(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_STATE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillZipCode(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ZIP_CODE_INP);
		await this.setInputValue(element, value);
	}

	public async fillCounty(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_COUNTRY_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillEmail(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EMAIL_INP);
		await this.setInputValue(element, value);
	}

	public async fillWorkNumber(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_WORK_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	public async fillWorkNumberExt(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_WORK_NUMBER_EXT_INP);
		await this.setInputValue(element, value);
	}

	public async fillMobileNumber(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MOBILE_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	public async fillHomeNumber(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_HOME_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	public async fillFaxNumber(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FAX_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	public async fillUser(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_USER_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillEmployeeStartDate(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EMPLOYEE_START_DAT);
		await this.setDateValue(element, value);
	}

	public async fillLocation(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_LOCATION_INP);
		await this.setInputValue(element, value);
	}

	public async clickAddOrganizationButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_ORGANIZATION_BTN).click();
	}

	public async fillOrganization(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ORGANIZATION_SEL);
		await this.setSearchDropdownValue(element, value);
	}

	public async fillPosition(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_POSITION_SEL);
		await this.setDropdownValue(element, value);
	}

	public async clickCreateButton(): Promise<void> {
		await this.page.locator(this.LOC_CREATE_BTN).click();
	}
}
