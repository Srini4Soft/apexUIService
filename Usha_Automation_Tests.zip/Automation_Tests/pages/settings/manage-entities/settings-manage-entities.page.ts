import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class SettingsManageEntitiesPage extends BasePage {
	private readonly LOC_CREATE_BTN = '//amp-manage-entities//h2//amp-button';
	private readonly LOC_LOOKUP_TAB = '//amp-tabs//a[@href="/v2/settings/management/lookups"]';
	private readonly LOC_PAYERS_TAB = '//amp-tabs//a[@href="/v2/settings/management/payers"]';
	private readonly LOC_PEOPLE_TAB = '//amp-tabs//a[@href="/v2/settings/management/people"]';

	public async open(): Promise<void> {
		const url = URL.SETTINGS_MANAGE_ENTITIES_LOOKUPS;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async openPeoplePage(): Promise<void> {
		await this.page.goto(URL.SETTINGS_MANAGE_ENTITIES_PEOPLE);
		await this.page.waitForURL(`**${URL.SETTINGS_MANAGE_ENTITIES_PEOPLE}`);
	}

	public async openPayersPage(): Promise<void> {
		await this.page.goto(URL.SETTINGS_MANAGE_ENTITIES_PAYERS);
		await this.page.waitForURL(`**${URL.SETTINGS_MANAGE_ENTITIES_PAYERS}`);
	}

	public async clickOnPeopleTab(): Promise<void> {
		await this.page.locator(this.LOC_PEOPLE_TAB).click();
	}

	public async clickOnLookupsTab(): Promise<void> {
		await this.page.locator(this.LOC_LOOKUP_TAB).click();
	}

	public async clickOnPayersTab(): Promise<void> {
		await this.page.locator(this.LOC_PAYERS_TAB).click();
	}

	public async clickOnCreateButton(): Promise<void> {
		await this.page.locator(this.LOC_CREATE_BTN).click();
	}

	/* ASSERTIONS */
	public async isCreateEntityButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_CREATE_BTN).isVisible();
	}
}
