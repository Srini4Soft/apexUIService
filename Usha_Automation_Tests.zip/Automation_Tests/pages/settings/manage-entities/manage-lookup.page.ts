import { expect, Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ManageLookupPage extends BasePage {
	private LOC_NAME_INP = '//amp-input[@formcontrolname="name"]//input';
	private LOC_TYPE_SEL = '//amp-select[@formcontrolname="lookupNamespaceId"]';
	private LOC_CODE_INP = '//amp-input[@formcontrolname="code"]//input';
	private LOC_IS_APPROVED_CHB = '//amp-checkbox[@formcontrolname="isApproved"]/label';
	private LOC_IS_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]/label';
	private LOC_FACILITIES_SEL = '(//amp-facility-filter[@formcontrolname="facilityIds"]//amp-button)[1]';
	private locFacilitiesUnselectAllButton = '//*[@data-test-id="amp-facility-filter-unselect-all-btn"]';
	private locSearchInput = '//amp-input[@data-test-id="amp-facility-filter-search-input"]//input';
	private locTreeItem = '//mat-tree-node[.//div[normalize-space(text())="${tmp}"]][1]//amp-checkbox';
	private locFacilityApplyButton = '//*[@data-test-id="amp-facility-filter-apply-filter-btn"]';
	private LOC_DISPLAY_COLOR_SEL = '//amp-select[@formcontrolname="displayColorId"]';
	private LOC_FINISH_BTN = '//footer//amp-button//span[contains(text(),"Finish")]';
	private LOC_SAVE_BTN = '//footer//amp-button//span[contains(text(),"Save")]';
	private LOC_CANCEL_BTN = '//footer//amp-button//span[contains(text(),"Cancel")]';

	/* FILL FORM */
	public async fillName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillCode(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CODE_INP);
		await this.setInputValue(element, value);
	}

	public async fillIsApproved(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_APPROVED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillIsGlobal(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	// --------------
	// TODO: rework
	public async clickFacilitySelect() {
		await expect(this.page.locator(this.LOC_FACILITIES_SEL), 'Is "Facilities" select visible?').toBeVisible();
		await this.page.locator(this.LOC_FACILITIES_SEL).click();
	}

	public async clickFacilityUnselectAll() {
		await expect(
			this.page.locator(this.locFacilitiesUnselectAllButton),
			'Is "Facilities unselect all" button visible?'
		).toBeVisible();
		await this.page.locator(this.locFacilitiesUnselectAllButton).click();
	}

	public async fillFacilitySearchInput(facility: string) {
		await this.page.locator(this.locSearchInput).clear();
		await this.page.locator(this.locSearchInput).pressSequentially(facility);
	}

	public async clickFacilityItem(facility: string) {
		await this.page.locator(this.locTreeItem.replace('${tmp}', facility)).click();
	}

	public async clickFacilityApplyButton() {
		await this.page.locator(this.locFacilityApplyButton).click();
	}

	public async fillDisplayColor(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DISPLAY_COLOR_SEL);
		await this.setDropdownValue(element, value);
	}

	public async clickFinishButton(): Promise<void> {
		await this.page.locator(this.LOC_FINISH_BTN).click();
	}

	public async clickSaveButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}

	public async clickCancelButton(): Promise<void> {
		await this.page.locator(this.LOC_CANCEL_BTN).click();
	}

	/*	ELEMENTS VERIFICATION 	*/
	public async isNameInputVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_NAME_INP).isVisible();
	}

	public async isFinishButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_FINISH_BTN).isVisible();
	}

	public async isSaveButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_SAVE_BTN).isVisible();
	}

	public async isCancelButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_CANCEL_BTN).isVisible();
	}
}
