import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class SettingsMappingListPage extends BasePage {
	private readonly locCreateMappingButton = '//amp-grid-title//h2//amp-button';

	public async open(): Promise<void> {
		const url = URL.SETTINGS_MAPPING_LIST;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async clickOnCreateButton() {
		await this.page.locator(this.locCreateMappingButton).click();
	}

	/* ASSERTIONS */
	public async isCreateMappingButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.locCreateMappingButton).isVisible();
	}
}
