import { Locator } from '@playwright/test';
import { BasePage } from '../../base.page.js';

export class ManageMappingPage extends BasePage {
	private readonly LOC_MAPPING_TYPE_SEL = '//amp-select[@formcontrolname="mappingTypeId"]';
	private readonly LOC_SOURCE_SYSTEM_SEL = '//amp-select[@formcontrolname="sourceSystemId"]';
	private readonly LOC_INPUT_INP = '//amp-input[@formcontrolname="input"]//input';
	private readonly LOC_OUTPUT_INP = '//amp-input[@formcontrolname="output"]//input';
	private readonly LOC_DESCRIPTION_INP = '//amp-input[@formcontrolname="description"]//input';
	private readonly LOC_START_DAT = '//amp-input[@formcontrolname="startDate"]//input';
	private readonly LOC_END_DAT = '//amp-input[@formcontrolname="endDate"]//input';
	private readonly LOC_ORGANIZATION_TYPE_SEL = '//amp-select[@formcontrolname="organizationType"]';
	private readonly LOC_ORGANIZATION_SEL = '//amp-select[@formcontrolname="organizationId"]';
	private readonly LOC_IS_DISABLED_CHB = '//amp-checkbox[@formcontrolname="isDisabled"]/label';
	private readonly LOC_IS_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]/label';
	private readonly LOC_TENANT_ENTITY_SEL = '//amp-select-tree[@formcontrolname="tenantEntityId"]';
	private readonly LOC_SEARCH_INP = '//amp-input[@data-test-id="amp-select-tree-search-input"]//input';
	private readonly LOC_TREE_ITEM = (tmp: string) =>
		`//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]][1]`;
	private readonly LOC_SAVE_BTN = '//amp-button[@category="success"]//span[normalize-space(text())="Save"]';
	private readonly LOC_CANCEL_BTN = '//amp-button[@category="subtle"]//span[normalize-space(text())="Cancel"]';
	private readonly LOC_COPY_MAPPING_BTN =
		'//ngb-modal-window[@role="dialog"]//amp-button[@category="success"]//span[normalize-space(text())="Copy"]';

	/* FILL FORM */
	public async fillMappingType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MAPPING_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillSourceSystem(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SOURCE_SYSTEM_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillInput(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_INPUT_INP);
		await this.setInputValue(element, value);
	}

	public async fillOutput(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_OUTPUT_INP);
		await this.setInputValue(element, value);
	}

	public async fillDescription(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DESCRIPTION_INP);
		await this.setInputValue(element, value);
	}

	public async fillStartDate(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_START_DAT);
		await this.setDateValue(element, value);
	}

	public async fillEndDate(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_END_DAT);
		await this.setDateValue(element, value);
	}

	public async fillOrganizationType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ORGANIZATION_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillOrganization(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ORGANIZATION_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillIsDisabled(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_DISABLED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillIsGlobal(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_IS_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async fillTenantEntity(value: string): Promise<void> {
		await this.page.locator(this.LOC_TENANT_ENTITY_SEL).click();
		await this.page.locator(this.LOC_SEARCH_INP).clear();
		await this.page.locator(this.LOC_SEARCH_INP).pressSequentially(value);
		await this.page.locator(this.LOC_TREE_ITEM(value)).click();
	}

	public async clickSaveButton() {
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}

	public async clickCancelButton() {
		await this.page.locator(this.LOC_CANCEL_BTN).click();
	}

	public async clickCopyMappingButton() {
		await this.page.locator(this.LOC_COPY_MAPPING_BTN).click();
	}
}
