import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class CensusDashboardPage extends BasePage {
	private readonly LOC_COMMON_WIDGET = (tmp: string) =>
		`//gridster-item[1]//amp-dashboard-widget//div[contains(@class,"amp-dashboard-widget__title")]/div[contains(text(),"${tmp}")]`;
	private readonly LOC_EXPAND_ALL_BTN = '//amp-button[@data-test-id="amp-census-overview-expand-all-btn"]';
	private readonly LOC_MONTH_BTN = '//amp-button[@data-test-id="amp-census-overview-calendar-view-month"]';
	private readonly LOC_WEEK_BTN = '//amp-button[@data-test-id="amp-census-overview-calendar-view-week"]';
	private readonly LOC_DAY_BTN = '//amp-button[@data-test-id="amp-census-overview-calendar-view-day"]';
	private readonly LOC_PREV_PERIOD_BTN = '//amp-button[@data-test-id="amp-census-overview-datepicker-previous-period"]';
	private readonly LOC_NEXT_PERIOD_BTN = '//amp-button[@data-test-id="amp-census-overview-datepicker-next-period"]';
	private readonly LOC_CALENDAR_BTN = '//amp-button[@data-test-id="amp-census-overview-datepicker-calendar"]';

	public async open(): Promise<void> {
		const url = URL.CENSUS_DASHBOARD;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */

	/* ASSERTIONS */
	public async isWidgetTitleVisible(value: string): Promise<boolean> {
		return this.page.locator(this.LOC_COMMON_WIDGET(value)).isVisible();
	}

	public async isExpandCollapseButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_EXPAND_ALL_BTN).isVisible();
	}

	public async isMonthButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_MONTH_BTN).isVisible();
	}

	public async isWeekButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_WEEK_BTN).isVisible();
	}

	public async isDayButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_DAY_BTN).isVisible();
	}

	public async isPreviousPeriodButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_PREV_PERIOD_BTN).isVisible();
	}

	public async isNextPeriodButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_NEXT_PERIOD_BTN).isVisible();
	}

	public async isCalendarButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_CALENDAR_BTN).isVisible();
	}
}
