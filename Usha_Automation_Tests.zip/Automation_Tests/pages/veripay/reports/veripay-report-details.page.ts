import { BasePage } from 'src/pages/base.page.js';

export class VeripayReportDetailsPage extends BasePage {
	private readonly LOC_CONFIG_VIEW = '//amp-report-details';
	private readonly LOC_VIEW_REPORT_BTN = '//amp-button//span[contains(text(),"View Report")]';
	private readonly LOC_RETURN_BTN = '//amp-button//span[contains(text(),"Return")]';

	/* ACTIONS */
	public async pressReturnButton() {
		await this.page.locator(this.LOC_RETURN_BTN).click();
	}

	/* ASSERTIONS */
	public async isReportConfigurationViewVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_CONFIG_VIEW).isVisible();
	}

	public async isViewReportButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_VIEW_REPORT_BTN).isVisible();
	}

	public async isReturnButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_RETURN_BTN).isVisible();
	}
}
