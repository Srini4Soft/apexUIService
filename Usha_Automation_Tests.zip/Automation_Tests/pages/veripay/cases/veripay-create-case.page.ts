import { expect, Locator } from '@playwright/test';
import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class VeripayCreateCasePage extends BasePage {
	private LOC_FACILITY_SEL = '//amp-select-tree[@formcontrolname="facilityId"]//amp-button';
	// private locSearchInput = '//amp-input[@data-test-id="amp-select-tree-search-input"]//input';
	// private locTreeItem = '//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]][1]';
	// private locSelectDropdownItem =
	// 	'//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//span[normalize-space(text())="${tmp}"]';
	private LOC_OWNER_SEL = '//amp-select[@formcontrolname="ownerUserId"]//ng-select';
	private LOC_LAST_NAME_INP = '//amp-input[@formcontrolname="lastName"]//input';
	private LOC_SSN_INP = '//amp-input[@formcontrolname="ssn"]//input';
	private LOC_FOUND_RESIDENTS_BANNER = '//amp-found-residents//amp-inline-banner';
	private LOC_CONTINUE_BTN = '//footer//amp-button[@category="success"]//button';

	public async open(): Promise<void> {
		const url = URL.RTS_CREATE_REFERRAL;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async fillFacility(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FACILITY_SEL);
		await this.setFacilityDropdownValue(element, value);
	}

	// public async fillFacilitySearchInput(facility: string) {
	// 	await this.page.locator(this.locSearchInput).clear();
	// 	await this.page.locator(this.locSearchInput).pressSequentially(facility);
	// }

	// public async clickFacilityItem(facility: string) {
	// 	await this.page.locator(this.locTreeItem.replace('${tmp}', facility)).click();
	// }

	public async fillOwner(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_OWNER_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillLastName(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_LAST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillSsn(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SSN_INP);
		await this.setInputValue(element, value);
	}

	public async clickContinueButton() {
		await this.page.locator(this.LOC_CONTINUE_BTN).click();
	}

	/* ASSERTIONS */
	public async isBannerVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_FOUND_RESIDENTS_BANNER).isVisible();
	}

	public async isCreateNewResidentButtonDisabled() {
		expect(this.page.locator(this.LOC_CONTINUE_BTN), 'Is "Create New Resident" button disabled?').toBeDisabled();
	}

	/* GET VALUES */
	public async getOwnerValue(): Promise<string> {
		const element = this.page.locator(this.LOC_OWNER_SEL);
		const text = await element.locator('//span[contains(@class,"amp-select__option")]').textContent();
		return text != undefined ? text?.trim() : '';
	}
}
