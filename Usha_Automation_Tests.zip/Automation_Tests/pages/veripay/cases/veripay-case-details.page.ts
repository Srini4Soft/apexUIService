import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class VeripayCaseDetailsPage extends BasePage {
	private LOC_REFERRAL_NAME_LNK = '//amp-details-title//a';
	private LOC_TRACKING_STATUS_BADGE =
		'//div[contains(@class, "amp-case-details__header")]/div[1]/amp-button/button/span';
	private LOC_NOTES_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/notes") + 1) = "/notes"]';
	private LOC_DOCUMENTS_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/documents") + 1) = "/documents"]';
	private LOC_MEDICAID_APPS_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/medicaid-financials") + 1) = "/medicaid-financials"]';
	private LOC_TASKS_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/tasks") + 1) = "/tasks"]';
	private LOC_CASE_TERM_BADGE = (tmp: string) =>
		`((//amp-tabs//form//amp-tag-list[@formcontrolname="tagValues"])[1]//amp-tag)[${tmp}]`;
	private LOC_CASE_TERM_BADGES =
		'(//amp-tabs//form//amp-tag-list[@formcontrolname="tagValues"])[1]//amp-tag/div[contains(@class,"amp-tag--checked")]';
	private LOC_SAVE_BUTTON = '//footer//button//span[normalize-space(text())="Save"]';

	private LOC_ADD_PAYER_BTN = '//amp-rts-veripay-payer-info//amp-tabs//amp-button[@icon="plus"]';
	private LOC_PAYER_EFFECTIVE_DATE_DAT = '//amp-input[@formcontrolname="effectiveDate"]//input';
	private LOC_PAYER_CATEGORY_SEL = '//amp-select[@formcontrolname="payerCategoryId"]//ng-select';

	private LOC_AUTHORIZATION_NUMBER_INP = '//amp-input[@formcontrolname="authorizationNumber"]//input';

	public async getReferralName(): Promise<string> {
		const referral = await this.page.locator(this.LOC_REFERRAL_NAME_LNK).textContent();
		return referral ? referral : '';
	}

	public async clickOnNotesTab(): Promise<void> {
		await this.page.locator(this.LOC_NOTES_TAB).click();
	}

	public async clickOnDocumentsTab(): Promise<void> {
		await this.page.locator(this.LOC_DOCUMENTS_TAB).click();
	}

	public async clickOnMedicaidAppsTab(): Promise<void> {
		await this.page.locator(this.LOC_MEDICAID_APPS_TAB).click();
	}

	public async clickOnTasksTab(): Promise<void> {
		await this.page.locator(this.LOC_TASKS_TAB).click();
	}

	public async selectCaseTerm(serialNumber: number): Promise<void> {
		await this.page.locator(this.LOC_CASE_TERM_BADGE(serialNumber.toString())).click();
	}

	/* PAYER INFORMATION */
	public async clickAddPayerButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_PAYER_BTN).click();
	}

	public async fillPayerCategory(value: string): Promise<void> {
		const element = this.page.locator(this.LOC_PAYER_CATEGORY_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillPayerEffectiveDate(value: string): Promise<void> {
		const element = this.page.locator(this.LOC_PAYER_EFFECTIVE_DATE_DAT);
		await this.setDateValue(element, value);
	}

	/* DOCUMENTS PAGE */
	public async addFileToUpload(filePath: string): Promise<void> {
		const handle = this.page.locator('//amp-add-file//input[@type="file"]');
		await handle.setInputFiles(filePath);
	}

	public async startUpload(): Promise<void> {
		const button = this.page.locator('//amp-add-file//amp-button/button[./span[normalize-space() = "Start Upload"]]');
		await button.click();
	}

	/* PREADMISSION SCREENING */
	public async fillAuthorizationNumber(value: string): Promise<void> {
		const element = this.page.locator(this.LOC_AUTHORIZATION_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	/* Footer */
	public async clickSaveButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_BUTTON).click();
	}

	/* ASSERTIONS */

	/* GET VALUES */
	public async getTrackingStatus(): Promise<string> {
		const result = await this.page.locator(this.LOC_TRACKING_STATUS_BADGE).textContent();
		return result!.trim();
	}

	public async getActiveCaseTerms(): Promise<Locator[]> {
		return await this.page.locator(this.LOC_CASE_TERM_BADGES).all();
	}

	public async getNotesMessages(): Promise<string[]> {
		const locator = '//amp-rts-veripay-case-notes//amp-discussion-message//span';
		const elementsLocator = this.page.locator(locator);
		await elementsLocator.first().waitFor();
		return await elementsLocator.allTextContents();
	}

	public async getValidationMessages(): Promise<string[]> {
		const locator = '//amp-rule-validation-banner//span[@class="amp-inline-banner__title"]/div';
		const elements = await this.page.locator(locator).all();
		let result: string[] = [];
		for (const element of elements) {
			const text = await element.textContent();
			result.push(text!.trim());
		}

		return result;
	}

	public async getTaskInfo(): Promise<{ title: string; status: string }[]> {
		const LOC_TASK = '//amp-rts-veripay-case-tasks//amp-task';
		const LOC_TASK_TITLE = '//div[@class="amp-task__title"]';
		const LOC_TASK_STATUS = '//span[@class="amp-badge__title"]';

		const result: { title: string; status: string }[] = [];

		const tasks = await this.page.locator(LOC_TASK).all();
		for (const task of tasks) {
			const title = (await task.locator(LOC_TASK_TITLE).textContent()) || '';
			const status = (await task.locator(LOC_TASK_STATUS).textContent()) || '';
			result.push({ title: title.trim(), status: status.trim() });
		}

		return result;
	}

	public async getPayersNumber(): Promise<number> {
		const locator = '//*[@formgroupname="payerInformation"]//amp-tabs//ul/li[@cdkdrag]';
		const elements = this.page.locator(locator);
		return (await elements.all()).length;
	}

	public async getMedicaidAppsNumber(): Promise<number> {
		const locator = '//*[@formgroupname="medicaidAppsModel"]//amp-tabs//ul/li[@cdkdrag]';
		const elements = this.page.locator(locator);
		return (await elements.all()).length;
	}

	public async getLocRequestedNumber(): Promise<number> {
		const locator = '//*[@formgroupname="workflow"]//amp-tabs//ul/li[@cdkdrag]';
		const elements = this.page.locator(locator);
		return (await elements.all()).length;
	}
}
