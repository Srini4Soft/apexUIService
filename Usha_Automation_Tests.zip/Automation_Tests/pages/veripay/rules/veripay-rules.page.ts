import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class VeripayRulesPage extends BasePage {
	private readonly LOC_AUTOMATION_RULES_TAB = '//amp-tabs//a[@href="/v2/veripay/settings/rules/automationrules"]';
	private readonly LOC_VALIDATION_RULES_TAB = '//amp-tabs//a[@href="/v2/veripay/settings/rules/validationrules"]';
	private readonly LOC_CREATE_RULE_BTN = '//div[@id="ampVeripaySettingsHeaderActions"]//amp-button';

	public async open(): Promise<void> {
		const url = URL.VERIPAY_RULES;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async clickOnAutomationRulesTab() {
		await this.page.locator(this.LOC_AUTOMATION_RULES_TAB).click();
	}

	public async clickOnValidationRulesTab() {
		await this.page.locator(this.LOC_VALIDATION_RULES_TAB).click();
	}

	public async clickOnCreateRuleButton() {
		await this.page.locator(this.LOC_CREATE_RULE_BTN).click();
	}

	/* ASSERTIONS */
	public async isCreateRuleButtonDisplayed(): Promise<boolean> {
		return await this.page.locator(this.LOC_CREATE_RULE_BTN).isVisible();
	}
}
