import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class DashboardComponent extends BasePage {
	private LOC_SELECT_MENU_BTN = '//amp-button[@data-test-id="amp-dashboard-available-dashboards-btn"]';
	private LOC_SETTINGS_MENU_BTN = '//amp-button[@data-test-id="amp-dashboard-settings-btn"]';
	private LOC_MENU_BY_NAME_ITM = (tmp: string) => `//amp-dropdown-item//span[contains(text(),"${tmp}")]`;
	private LOC_MENU_BY_NUMBER_ITM = (tmp: string) =>
		`(//amp-dropdown-item/div/span//span[@class="amp-wrap-text"])[${tmp}]`;

	/** Locators for MVC UI */
	private LOC_SELECT_MENU_MVC_BTN = '//div[@id="siteMapPathBlock"]//div[@class="page-title"]';
	private LOC_SETTINGS_MENU_MVC_BTN =
		'//div[@id="siteMapPathBlock"]//div[@class="edit-dashboard-tools"]//button[@data-toggle="dropdown"]';
	private LOC_MENU_BY_NAME_MVC_ITM = (tmp: string) =>
		`//div[@id="siteMapPathBlock"]//div[@class="page-title"]//ul[@role="menu"]//a[text()="${tmp}"]`;
	private LOC_MENU_BY_NUMBER_MVC_ITM = (tmp: string) =>
		`(//div[@id="siteMapPathBlock"]//div[@class="page-title"]//ul[@role="menu"]//a)[${tmp}]`;

	public async selectDashboardByPositionNumber(value: number = 1): Promise<void> {
		log.info(`Select dashboard number "${value}"`);
		const locator = this.LOC_MENU_BY_NUMBER_ITM(value.toString());
		await this.page.locator(this.LOC_SELECT_MENU_BTN).click();
		await this.page.locator(locator).click();
	}

	public async selectDashboardByName(value: string): Promise<void> {
		log.info(`Select dashboard wit name: "${value}"`);
		const locator = this.LOC_MENU_BY_NAME_ITM(value);
		await this.page.locator(this.LOC_SELECT_MENU_BTN).click();
		await this.page.locator(locator).click();
	}

	public async isSettingsButtonVisible(): Promise<boolean> {
		return this.page.locator(this.LOC_SETTINGS_MENU_BTN).isVisible();
	}

	/** Methods for MVC UI */
	public async selectDashboardByPositionNumberMvc(value: number = 1): Promise<void> {
		log.info(`Select dashboard number "${value}"`);
		const locator = this.LOC_MENU_BY_NUMBER_MVC_ITM(value.toString());
		await this.page.locator(this.LOC_SELECT_MENU_MVC_BTN).click();
		await this.page.locator(locator).click();
	}

	public async selectDashboardByNameMvc(value: string): Promise<void> {
		log.info(`Select dashboard wit name: "${value}"`);
		const locator = this.LOC_MENU_BY_NAME_MVC_ITM(value);
		await this.page.locator(this.LOC_SELECT_MENU_MVC_BTN).click();
		await this.page.locator(locator).click();
	}

	public async isSettingsButtonVisibleMvc(): Promise<boolean> {
		return this.page.locator(this.LOC_SETTINGS_MENU_MVC_BTN).isVisible();
	}
}
