import { BasePage } from 'src/pages/base.page.js';

export class ShareLinkComponent extends BasePage {
	private LOC_LINK_BTN = '//amp-header//amp-button[@icon="share"]';
	private LOC_CLOSE_WINDOW_BTN = '//ngb-modal-window//amp-icon[@iconname="xmark"]';
	private LOC_LINK_INP = '//ngb-modal-window//form//amp-input//input[@readonly]';

	public async clickShortLinkButton(): Promise<void> {
		await this.page.locator(this.LOC_LINK_BTN).click();
		await this.waitForPageLoad();
	}

	public async closeShareWindow(): Promise<void> {
		await this.page.locator(this.LOC_CLOSE_WINDOW_BTN).click();
	}

	public async getShortLink(): Promise<string> {
		return await this.page.locator(this.LOC_LINK_INP).inputValue();
	}
}
