import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class GridCustomFilterComponent extends BasePage {
	private readonly LOC_APPLY_1_BTN = '//amp-button[@data-test-id="amp-modal-custom-filter-apply-btn"]';
	private readonly LOC_APPLY_2_BTN = '(//ngb-modal-window//amp-button[@category="success"])[2]';
	private readonly LOC_CLOSE_BTN = '//amp-button[@data-test-id="amp-modal-custom-filter-close-btn"]';
	private readonly LOC_ADD_CONDITION_BTN =
		'//amp-add-actions[@data-test-id="amp-rule-expression-actions"]//amp-button[@icon="cond"]';
	private readonly LOC_ADD_GROUP_BTN =
		'//amp-add-actions[@data-test-id="amp-rule-expression-actions"]//amp-button[@icon="group-cond"]';
	private readonly LOC_SHOW_EXPRESSION_BTN = '//amp-button[@data-test-id="amp-rule-expression-show-btn"]';
	private readonly LOC_APPLY_EXPRESSION_BTN = '//ngb-modal-window[@role="dialog"]//amp-button[@iconleft="rotate"]';
	private readonly LOC_COLUMN_TITLE_SEL =
		'//amp-select-tree[@data-test-id="amp-rule-expression-item-prop-name-select"]';
	private readonly LOC_CONDITION_SEL = '//amp-select[@data-test-id="amp-rule-expression-item-predicate-select"]';
	private readonly LOC_FILTER_VALUE_SEL =
		'//*[@data-test-id="amp-rule-expression-item-comparison-value"]//amp-select[@formcontrolname="value"]';
	private readonly LOC_FILTER_VALUE_INP =
		'//*[@data-test-id="amp-rule-expression-item-comparison-value"]//amp-input[@formcontrolname="value"]//input';
	private readonly LOC_COLUMNS_FILTER_INP = '//div[@role="menu"]//amp-input//input[@placeholder="Filter"]';
	private readonly LOC_COLUMNS_FILTER_ITM = (tmp: string) =>
		`//div[@role="menu"]//amp-select-tree-item//span[normalize-space(text())="${tmp}"]`;
	private readonly LOC_COLUMNS_EXPAND_ICO = (tmp: string) =>
		`//div[@role="menu"]//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]]//amp-button`;
	private readonly LOC_TRE_ITEM = '//div[@role="menu"]//amp-select-tree-item';
	private readonly LOC_EXPRESSION_TXT = '//amp-input[@data-test-id="amp-rule-expression-input"]//textarea';

	public async clickApplyButton() {
		if ((await this.page.locator(this.LOC_APPLY_1_BTN).count()) > 0) {
			await this.page.locator(this.LOC_APPLY_1_BTN).click();
		} else {
			await this.page.locator(this.LOC_APPLY_2_BTN).click();
		}
	}

	public async clickCloseButton() {
		await this.page.locator(this.LOC_CLOSE_BTN).click();
	}

	public async clickAddConditionButton() {
		await this.page.locator(this.LOC_ADD_CONDITION_BTN).click();
	}

	public async clickAddGroupButton() {
		await this.page.locator(this.LOC_ADD_GROUP_BTN).click();
	}

	public async clickShowExpressionButton() {
		await this.page.locator(this.LOC_SHOW_EXPRESSION_BTN).click();
	}

	public async clickApplyExpressionButton() {
		await this.page.locator(this.LOC_APPLY_EXPRESSION_BTN).click();
		await this.page.waitForTimeout(1000);
	}

	public async fillColumnFilterInput(value: string) {
		await this.page.locator(this.LOC_COLUMNS_FILTER_INP).click();
		await this.page.keyboard.type(value);
		await this.page.waitForTimeout(500);
	}

	public async clickExpandItemIcon(value: string) {
		await this.page.locator(this.LOC_COLUMNS_EXPAND_ICO(value)).click();
	}

	public async clickColumnFilterItem(value: string) {
		this.page.locator(this.LOC_COLUMNS_FILTER_ITM(value)).click();
	}

	public async clickColumnTitleSelect() {
		await this.page.locator(this.LOC_COLUMN_TITLE_SEL).click();
	}

	public async clickConditionSelect() {
		await this.page.locator(this.LOC_CONDITION_SEL).click();
	}

	public async clickFilterValueSelect() {
		await this.page.locator(this.LOC_FILTER_VALUE_SEL).click();
	}

	public async fillFilterValueInput(value: string) {
		await this.page.locator(this.LOC_FILTER_VALUE_INP).fill(value);
	}

	public async getExpressionValue(): Promise<string> {
		const expression = await this.page.locator(this.LOC_EXPRESSION_TXT).inputValue();
		return expression ? expression : '';
	}

	public async fillExpressionValue(value: string) {
		await this.page.locator(this.LOC_EXPRESSION_TXT).fill(value);
	}

	public async getVisibleTreeElements(): Promise<Locator[]> {
		return await this.page.locator(this.LOC_TRE_ITEM).all();
	}

	public async getFilterValue(): Promise<string> {
		return await this.page.locator(this.LOC_FILTER_VALUE_INP).inputValue();
	}
}
