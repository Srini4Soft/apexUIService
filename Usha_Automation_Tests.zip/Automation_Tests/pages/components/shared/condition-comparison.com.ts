import { expect } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ConditionComparisonComponent extends BasePage {
	private LOC_WINDOW = '//ngb-modal-window[@role="dialog"]//div[@role="document"]';
	private LOC_FIRST_LINK_SEL = '//amp-select[@formcontrolname="firstLinkId"]';
	private LOC_SECOND_LINK_SEL = '//amp-select[@formcontrolname="secondLinkId"]//label';
	private LOC_COMPARE_BTN = '//div[@role="document"]//div[@ampscrollbar]//amp-button//button';
	private LOC_CLOSE_BTN = '//div[@role="document"]//amp-button[@category="subtle"]';
	private LOC_ALL_CASES_CHANGE_BTN =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="All Cases Changes"]]';
	private LOC_ADD_CASES_BTN =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="Added Cases"]]';
	private LOC_REMOVE_CASES_BTN =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="Removed Cases"]]';
	private LOC_ALL_CASES_BADGE =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="All Cases Changes"]]//amp-badge//span';
	private LOC_ADD_CASES_BADGE =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="Added Cases"]]//amp-badge//span';
	private LOC_REMOVE_CASES_BADGE =
		'//div[@role="document"]//amp-grid-toolbar//button[.//div[normalize-space(text())="Removed Cases"]]//amp-badge//span';

	/* ACTIONS */
	public getWindowLocator() {
		return this.page.locator(this.LOC_WINDOW);
	}

	public async clickFirstLinkSelector() {
		await this.page.locator(this.LOC_FIRST_LINK_SEL).click();
	}

	public async clickSecondLinkSelector() {
		await this.page.locator(this.LOC_SECOND_LINK_SEL).click();
	}

	public async clickCompareButton() {
		await this.page.locator(this.LOC_COMPARE_BTN).click();
	}

	public async clickCloseButton() {
		await this.page.locator(this.LOC_CLOSE_BTN).click();
	}

	public async clickAllCasesChangeButton() {
		await this.page.locator(this.LOC_ALL_CASES_CHANGE_BTN).click();
	}

	public async clickAddedCasesButton() {
		await this.page.locator(this.LOC_ADD_CASES_BTN).click();
	}

	public async clickRemovedCasesButton() {
		await this.page.locator(this.LOC_REMOVE_CASES_BTN).click();
	}

	public async getAllCasesChangeBadgeText(): Promise<string> {
		const text = await this.page.locator(this.LOC_ALL_CASES_BADGE).textContent();
		return text != null ? text.trim().toString() : '';
	}

	public async getAddedCasesBadgeText(): Promise<string> {
		const text = await this.page.locator(this.LOC_ADD_CASES_BADGE).textContent();
		return text != null ? text.trim().toString() : '';
	}

	public async getRemovedCasesBadgeText(): Promise<string> {
		const text = await this.page.locator(this.LOC_REMOVE_CASES_BADGE).textContent();
		return text != null ? text.trim().toString() : '';
	}

	/* ASSERTIONS */
	public async isAllCasesChangeButtonVisible() {
		await expect(
			this.page.locator(this.LOC_ALL_CASES_CHANGE_BTN),
			'Is "All Cases Change" button visible?'
		).toBeVisible();
	}

	public async isAddedCasesButtonVisible() {
		await expect(this.page.locator(this.LOC_ADD_CASES_BTN), 'Is "Added Cases" button visible?').toBeVisible();
	}

	public async isRemovedCasesButtonVisible() {
		await expect(this.page.locator(this.LOC_REMOVE_CASES_BTN), 'Is "Removed Cases" button visible?').toBeVisible();
	}
}
