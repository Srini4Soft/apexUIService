import { BasePage } from 'src/pages/base.page.js';

export class ProfileMenuComponent extends BasePage {
	private LOC_OPEN_BTN = '//amp-header//div[@aria-haspopup="menu"]';
	private LOC_MY_LINKS = '//amp-dropdown-item[@iconname="link"]//span[normalize-space(text())="My links"]';
	private LOC_VIEW_ALL_LINKS = '//amp-dropdown-item//span[normalize-space(text())="View All Links"]';

	public async clickOpenProfileMenuButton() {
		await this.page.locator(this.LOC_OPEN_BTN).click();
	}

	public async clickMyLinksMenuItem() {
		await this.page.locator(this.LOC_MY_LINKS).click();
	}

	public async clickViewAllLinksMenuItem() {
		await this.page.locator(this.LOC_VIEW_ALL_LINKS).click();
	}
}
