import { expect } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ToasterComponent extends BasePage {
	private LOC_CLOSE_BUTTON = '//div[@id="toast-container"]//button[@aria-label="Close"]';
	private LOC_MESSAGE_TXT = '//div[@id="toast-container"]//div[@role="alert"]';

	public async close(): Promise<void> {
		const closeButton = this.page.locator(this.LOC_CLOSE_BUTTON);
		await expect(closeButton, 'Is "Toaster" visible?').toBeVisible();
		await closeButton.click();
	}

	public async getMessage(): Promise<string> {
		const toaster = this.page.locator(this.LOC_MESSAGE_TXT);
		const message = await toaster.textContent();
		return message ?? '';
	}
}
