import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class FormComponent extends BasePage {
	private LOC_ALL_FORM_FIELDS = '//*[@formcontrolname]';
	private LOC_FORM_FIELD = (tmp: string) => `//*[@formcontrolname="${tmp}"]`;

	public async getListOfFields(): Promise<Locator[]> {
		return await this.page.locator(this.LOC_ALL_FORM_FIELDS).all();
	}

	public getField(fieldName: string): Locator {
		return this.page.locator(this.LOC_FORM_FIELD(fieldName));
	}
}
