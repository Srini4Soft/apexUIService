import { BasePage } from 'src/pages/base.page.js';

export class FacilityFilterComponent extends BasePage {
	private LOC_OPEN_FILTER_BTN = '//amp-button[@data-test-id="amp-facility-filter-open-btn"]';
	private LOC_SAVED_VIEWS_BTN = '//amp-button[@data-test-id="amp-facility-filter-saved-views-btn"]';
	private LOC_SELECT_ALL_BTN = '//amp-button[@data-test-id="amp-facility-filter-select-all-btn"]';
	private LOC_UNSELECT_ALL_BTN = '//amp-button[@data-test-id="amp-facility-filter-unselect-all-btn"]';
	private LOC_APPLY_BTN = '//amp-button[@data-test-id="amp-facility-filter-apply-filter-btn"]';
	private LOC_SELECT_ONLY_MY_ITM = '//amp-dropdown-item[@data-test-id="amp-facility-filter-select-my-btn"]';
	private LOC_PORTFOLIO_ITM = '//mat-tree/mat-nested-tree-node';
	private LOC_SEARCH_INP = '//amp-input[@data-test-id="amp-facility-filter-search-input"]//input';

	public async clickFacilityFilterBtn() {
		await this.page.locator(this.LOC_OPEN_FILTER_BTN).click();
	}

	public async clickOnlyMyFacilities() {
		await this.page.locator(this.LOC_SAVED_VIEWS_BTN).click();
		await this.page.locator(this.LOC_SELECT_ONLY_MY_ITM).click();
	}

	public async clickSelectAllBtn() {
		await this.page.locator(this.LOC_SELECT_ALL_BTN).click();
	}

	public async clickUnselectAllBtn() {
		await this.page.locator(this.LOC_UNSELECT_ALL_BTN).click();
	}

	public async clickApplyFilterBtn() {
		await this.page.locator(this.LOC_APPLY_BTN).click();
	}

	public async clickSelectFirstPortfolioCheck() {
		await this.page.locator(`(${this.LOC_PORTFOLIO_ITM}//amp-checkbox)[1]`).click();
	}

	public async clickSelectPortfolioByNameCheck(name: string) {
		await this.page.locator(`${this.LOC_PORTFOLIO_ITM}//amp-checkbox[../div[normalize-space() = '${name}']]`).click();
	}

	public async setSearchStringValue(value: string) {
		const searchInput = this.page.locator(this.LOC_SEARCH_INP);
		await searchInput.clear();
		await searchInput.pressSequentially(value);
	}

	public async clearSearchInput() {
		await this.page.locator(this.LOC_SEARCH_INP).clear();
	}
}
