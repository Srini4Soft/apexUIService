import { BasePage } from 'src/pages/base.page.js';

export class SelectRuleActionPage extends BasePage {
	private readonly LOC_ACTION_ITM = (tmp: string) =>
		`//ngb-modal-window//amp-inline-banner[.//span[normalize-space(text())="${tmp}"]]`;

	public async selectAction(name: string) {
		await this.page.locator(this.LOC_ACTION_ITM(name)).click();
	}
}
