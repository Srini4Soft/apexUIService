import { BasePage } from 'src/pages/base.page.js';

export class AutomationRulePage extends BasePage {
	private LOC_RULE_ID_TXT = '//amp-rule-details/amp-details-title/h2//span[contains(text(),"Rule")]';
	private LOC_NAME_INP = '//amp-input[@formcontrolname="name"]//input';
	private LOC_TARGET_PROP_SEL = '//amp-select-tree[@formcontrolname="targetProperties"]';
	private LOC_IS_GLOBAL_CHB = '//amp-checkbox[@formcontrolname="isGlobal"]//label';
	private LOC_IS_ENABLED_CHB = '//amp-checkbox[@formcontrolname="isEnabled"]//label';
	private LOC_ADD_SUCCESS_ACTION = '//amp-rule-actions[.//span[contains(text(),"Success")]]//amp-button[@icon="plus"]';
	private LOC_DEL_SUCCESS_ACTION_BTN = '//amp-rule-actions[1]//amp-button[@icon="delete"]';
	private LOC_CREATE_BTN = '//footer//amp-button[@category="success"]';
	private LOC_SAVE_BTN = '//footer//amp-button[@category="success"]//span[contains(normalize-space(text()),"Save")]';

	constructor() {
		super();
	}

	public async getRuleId(): Promise<string> {
		const element = this.page.locator(this.LOC_RULE_ID_TXT);
		const text = (await element.textContent()) ?? '';
		const match = text.match(/#(\d+)/);
		return match?.[1] ?? '';
	}

	public async fillNameInput(value: string): Promise<void> {
		const element = this.page.locator(this.LOC_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillTargetProperties(value: string[]): Promise<void> {
		const element = this.page.locator(this.LOC_TARGET_PROP_SEL);
		await this.setDropdownTreeValue(element, value);
	}

	public async setIsGlobalCheckbox(value: boolean): Promise<void> {
		const element = this.page.locator(this.LOC_IS_GLOBAL_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async setIsEnabledCheckbox(value: boolean): Promise<void> {
		const element = this.page.locator(this.LOC_IS_ENABLED_CHB);
		await this.setCheckboxValue(element, value);
	}

	public async clickAddActionOnSuccessButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_SUCCESS_ACTION).click();
	}

	public async clickDeleteActionOnSuccessButton(): Promise<void> {
		await this.page.locator(this.LOC_DEL_SUCCESS_ACTION_BTN).click();
	}

	public async clickCreateButton(): Promise<void> {
		await this.page.locator(this.LOC_CREATE_BTN).click();
		await this.waitForTimeout(10000);
	}

	public async clickSaveButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_BTN).click();
		await this.waitForTimeout(10000);
	}
}
