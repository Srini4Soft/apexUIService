import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class SetValueAction extends BasePage {
	private readonly LOC_TARGET_FIELD_SEL = '//amp-select-tree[@formcontrolname="targetValuePath"]//amp-button';
	private readonly LOC_TYPE_SEL = '//amp-select[@formcontrolname="valueSourceType"]//ng-select';
	private readonly LOC_DATE_OPERATOR_SEL = '//amp-select[@formcontrolname="dateOperator"]//ng-select';
	private readonly LOC_VALUE_DAT = '//ngb-modal-window//amp-input[@formcontrolname="value"]//input';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillTargetField(value: string[]): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TARGET_FIELD_SEL);
		await this.setDropdownTreeValue(element, value);
	}

	public async fillSourceType(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TYPE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillDateOperator(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DATE_OPERATOR_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillDateValue(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_VALUE_DAT);
		await this.setDateValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
