import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class CreateWorkflowInstanceAction extends BasePage {
	private readonly LOC_WORKFLOW_DEFINITION = '//amp-select[@formcontrolname="workflowDefinitionId"]//ng-select';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillWorkflowDefinitionField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_WORKFLOW_DEFINITION);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
