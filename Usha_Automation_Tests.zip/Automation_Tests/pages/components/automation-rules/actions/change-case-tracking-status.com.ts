import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class ChangeCaseTrackingStatusAction extends BasePage {
	private readonly LOC_TRACKING_STATUS = '//amp-select[@formcontrolname="caseTrackingStatusType"]//ng-select';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillTrackingStatus(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TRACKING_STATUS);
		await this.setExactDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
