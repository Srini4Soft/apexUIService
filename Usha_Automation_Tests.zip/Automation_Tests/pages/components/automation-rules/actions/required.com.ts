import { BasePage } from 'src/pages/base.page.js';

export class RequiredAction extends BasePage {
	private readonly LOC_MESSAGE = '//amp-input[@formcontrolname="message"]//textarea';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillRequiredMessage(value: string) {
		await this.page.locator(this.LOC_MESSAGE).fill(value);
	}

	public async clickAddButton() {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
