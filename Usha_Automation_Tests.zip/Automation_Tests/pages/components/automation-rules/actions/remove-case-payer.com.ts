import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class RemoveCasePayerAction extends BasePage {
	private readonly LOC_PRIMARY_PAYER = '//amp-select[@formcontrolname="payerPeriod"]//ng-select';
	private readonly LOC_PAYER_CATEGORY = '//amp-select[@formcontrolname="payerCategory"]//ng-select';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillPrimaryPayer(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_PRIMARY_PAYER);
		await this.setDropdownValue(element, value);
	}

	public async fillPayerCategory(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_PAYER_CATEGORY);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
