import { BasePage } from 'src/pages/base.page.js';

export class SelectRuleAction extends BasePage {
	private static readonly LOC_ACTION_ITEM =
		'//ngb-modal-window//amp-inline-banner[.//span[normalize-space(text())="${tmp}"]]';

	public static async selectAction(name: string) {
		await this.getPage().locator(this.LOC_ACTION_ITEM.replace('${tmp}', name)).click();
	}
}
