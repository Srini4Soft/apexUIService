import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class RemoveCaseTagAction extends BasePage {
	private readonly LOC_SCOPE = '//amp-select[@formcontrolname="scope"]//ng-select';
	private readonly LOC_TAG = '//amp-select[@formcontrolname="lookupId"]//ng-select';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillScope(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SCOPE);
		await this.setDropdownValue(element, value);
	}

	public async fillTag(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_TAG);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
