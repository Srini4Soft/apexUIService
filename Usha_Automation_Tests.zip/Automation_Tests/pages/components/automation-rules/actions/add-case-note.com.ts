import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class AddCaseNoteAction extends BasePage {
	private readonly LOC_MESSAGE = '//amp-input[@formcontrolname="message"]//textarea';
	private readonly LOC_AGGREGATED_MESSAGE = '//amp-checkbox[@formcontrolname="isAggregateMessage"]//label';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillMessageField(value: string) {
		await this.page.locator(this.LOC_MESSAGE).fill(value);
	}

	public async setIsAggregateMessageCheckbox(value: boolean) {
		const element: Locator = this.page.locator(this.LOC_AGGREGATED_MESSAGE);
		await this.setCheckboxValue(element, value);
	}

	public async clickAddButton() {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
