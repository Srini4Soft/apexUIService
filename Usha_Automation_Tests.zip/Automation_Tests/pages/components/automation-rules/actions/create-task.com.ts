import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class CreateTaskAction extends BasePage {
	private readonly LOC_TITLE = '//amp-input[@formcontrolname="title"]//textarea';
	private readonly LOC_CATEGORY = '//amp-select[@formcontrolname="lookupTaskCategoryId"]//ng-select';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillTitleField(value: string): Promise<void> {
		await this.page.locator(this.LOC_TITLE).fill(value);
	}

	public async fillCategoryField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_CATEGORY);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
