import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class WarningAction extends BasePage {
	private readonly LOC_MESSAGE_INP = '//amp-input[@formcontrolname="message"]//input';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillWarningMessage(value: string) {
		const element: Locator = this.page.locator(this.LOC_MESSAGE_INP);
		await this.setInputValue(element, value);
	}

	public async clickAddButton() {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
