import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class AddCaseTagAction extends BasePage {
	private LOC_SCOPE = '//amp-select[@formcontrolname="scope"]//ng-select';
	private LOC_TAG = '//amp-select[@formcontrolname="lookupId"]//ng-select';
	private LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillScopeField(value: string) {
		const element: Locator = this.page.locator(this.LOC_SCOPE);
		await this.setDropdownValue(element, value);
	}

	public async fillTagField(value: string) {
		const element: Locator = this.page.locator(this.LOC_TAG);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
