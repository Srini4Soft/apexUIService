import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class CompleteTaskAction extends BasePage {
	private readonly LOC_SCOPE = '//amp-select[@formcontrolname="scope"]//ng-select';
	private readonly LOC_RELATED_ID = '//amp-select-tree[@formcontrolname="targetValuePath"]//amp-button';
	private readonly LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async fillScopeField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SCOPE);
		await this.setDropdownValue(element, value);
	}

	public async fillRelatedEntity(value: string[]): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_RELATED_ID);
		await this.setDropdownTreeValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
