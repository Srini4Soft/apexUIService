import { BasePage } from 'src/pages/base.page.js';

export class AddMedicaidApplicationAction extends BasePage {
	private LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
