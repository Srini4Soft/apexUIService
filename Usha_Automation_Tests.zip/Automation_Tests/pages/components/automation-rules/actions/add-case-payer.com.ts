import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class AddCasePayerAction extends BasePage {
	private LOC_ALLOW_MULTIPLE_EXECUTION = '//amp-checkbox[@formcontrolname="allowMultipleExecution"]//label';
	private LOC_PRIMARY_PAYER = '//amp-select[@formcontrolname="payerRole"]//ng-select';
	private LOC_PAYER_CATEGORY = '//amp-select[@formcontrolname="payerCategory"]//ng-select';
	private LOC_EFFECTIVE_DATE_INPUT = '//amp-input[@formcontrolname="effectiveDateInput"]//input';
	private LOC_EFFECTIVE_DATE_DROPDOWN = '//amp-select[@formcontrolname="effectiveDateDropDown"]//ng-select';
	private LOC_EFFECTIVE_DATE_PROPERTY = '//amp-select[@formcontrolname="effectiveDateProperty"]//ng-select';
	private LOC_ADD_BUTTON = '//ngb-modal-window//amp-button[@category="success"]';

	public async setAllowMultipleExecutionCheckbox(value: boolean): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_ALLOW_MULTIPLE_EXECUTION);
		await this.setCheckboxValue(element, value);
	}

	public async fillPayerRoleField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_PRIMARY_PAYER);
		await this.setDropdownValue(element, value);
	}

	public async fillPayerCategoryField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_PAYER_CATEGORY);
		await this.setDropdownValue(element, value);
	}

	public async fillEffectiveDateInputField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EFFECTIVE_DATE_INPUT);
		await this.setInputValue(element, value);
	}

	public async fillEffectiveDateDropdownField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EFFECTIVE_DATE_DROPDOWN);
		await this.setDropdownValue(element, value);
	}

	public async fillEffectiveDatePropertyField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_EFFECTIVE_DATE_PROPERTY);
		await this.setDropdownValue(element, value);
	}

	public async clickAddButton(): Promise<void> {
		await this.page.locator(this.LOC_ADD_BUTTON).click();
	}
}
