import { BaseFilter } from './base-filter.com.js';

export class DateRangeFilter extends BaseFilter {
	private LOC_FROM_INP = '//amp-input[@data-test-id="amp-date-filter-date-picker-start"]//input';
	private LOC_TO_INP = '//amp-input[@data-test-id="amp-date-filter-date-picker-end"]//input';
	private LOC_PERIOD_ITM = (tmp: string) =>
		`//ul[@data-test-id="amp-date-filter-range-selectors"]/li[normalize-space(text())="${tmp}"]`;
	private LOC_SELECT_DAY = '(//span[contains(@class,"flatpickr-day") and contains(@class,"selected")])[2]';

	public async clickOnTimePeriod(period: string) {
		await this.page.locator(this.LOC_PERIOD_ITM(period)).click();
	}

	public async clickOnInput(type: 'from' | 'to') {
		const inputLocator = type === 'from' ? this.LOC_FROM_INP : this.LOC_TO_INP;
		await this.page.locator(inputLocator).click();
	}

	public async fillInput(type: 'from' | 'to', value: string) {
		const inputLocator = type === 'from' ? this.LOC_FROM_INP : this.LOC_TO_INP;
		await this.page.locator(inputLocator).pressSequentially(value);
		if (type === 'to') {
			await this.page.locator(this.LOC_SELECT_DAY).click();
		}
	}
}
