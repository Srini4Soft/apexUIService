import { test } from 'src/common/fixtures/test-fixture.js';
import { BasePage } from 'src/pages/base.page.js';

export class BaseFilter extends BasePage {
	private LOC_APPLY_BTN = '//*[@data-test-id="amp-filter-popup-apply-btn"]';
	private LOC_CLEAR_BTN = '//*[@data-test-id="amp-filter-popup-clear-btn"]';

	public async apply() {
		await test.step('Apply column filter', async () => {
			await this.page.waitForTimeout(500);
			await this.page.locator(this.LOC_APPLY_BTN).click();
		});
	}

	public async clear() {
		await test.step('Clear column filter', async () => {
			await this.page.locator(this.LOC_CLEAR_BTN).click();
		});
	}

	public async waitForTimeout(timeout: number): Promise<void> {
		await this.page.waitForTimeout(timeout);
	}
}
