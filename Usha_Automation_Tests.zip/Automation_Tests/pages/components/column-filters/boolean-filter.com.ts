import { BaseFilter } from './base-filter.com.js';

export class BooleanFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) =>
		`//amp-grid-filter-boolean[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_RADIO_ITM = (tmp: string) =>
		`//*[@data-test-id="amp-filter-boolean-radio-buttons"]//span[normalize-space(text())="${tmp}"]`;

	public async clickRadioButtonItem(name: string, value: string) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(name));
		await filter.locator(this.LOC_RADIO_ITM(value)).click();
	}
}
