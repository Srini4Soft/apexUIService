import { Locator } from '@playwright/test';
import log from 'src/common/utils/logger.js';
import { BaseFilter } from './base-filter.com.js';

export class MultiEnumerationFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) =>
		`//amp-grid-filter-multi-enumeration[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_CHECKBOX_LABELS =
		'(//div[contains(@class,"amp-filter-popup")]//amp-grid-filter-multi-enumeration//div/div)[1]//span';
	private LOC_CHECKBOX_BY_ORDER = (column: string, tmp: string) =>
		`(//div[contains(@class,"amp-filter-popup")]//amp-grid-filter-multi-enumeration//amp-checkbox-list)[${column}]//amp-checkbox[${tmp}]/label`;

	public async setCheckboxFilter(filterName: string, values: string[]) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(filterName));
		await this.unselectAll(filter);
		for (const value of values) {
			await this.selectCheckboxByLabel(filter, value, 1);
			await this.selectCheckboxByLabel(filter, value, 2);
		}
	}

	public async unselectAllChecks(filterName: string) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(filterName));
		await this.unselectAll(filter);
	}

	public async selectAllChecks(filterName: string) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(filterName));
		await this.selectCheckboxByLabel(filter, 'All', 1);
		await this.selectCheckboxByLabel(filter, 'All', 2);
	}

	private async unselectAll(filterName: Locator) {
		await this.selectCheckboxByLabel(filterName, 'All', 1, true);
		await this.selectCheckboxByLabel(filterName, 'All', 2, true);
	}

	private async selectCheckboxByLabel(filterName: Locator, label: string, column: number, deselect: boolean = false) {
		const allCheckboxLabels = await filterName.locator(this.LOC_CHECKBOX_LABELS).all();
		const columnIndex = await this.getElementIndex(allCheckboxLabels, label);
		log.debug(`LOCATOR: ${this.LOC_CHECKBOX_BY_ORDER(column.toString(), columnIndex.toString())}`);
		if (columnIndex !== -1) {
			const element = filterName.locator(this.LOC_CHECKBOX_BY_ORDER(column.toString(), columnIndex.toString()));
			const classAttribute = await element.getAttribute('class');
			const isSelected = classAttribute?.includes('amp-checkbox--selected');

			if ((deselect && isSelected) || (!deselect && !isSelected)) {
				await element.click();
			}
		} else {
			log.error(`Checkbox with label "${label}" not found.`);
		}
	}

	private async getElementIndex(items: Locator[], value: string): Promise<number> {
		for (let i = 0; i < items.length; i++) {
			const text = await items[i]?.textContent();
			if (text?.trim() === value) {
				return i;
			}
		}
		return -1;
	}
}
