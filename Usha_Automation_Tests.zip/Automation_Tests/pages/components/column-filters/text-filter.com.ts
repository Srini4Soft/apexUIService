import { BaseFilter } from './base-filter.com.js';

export class TextFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) => `//amp-grid-filter-text[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_CONDITION_SEL = '//amp-select[@data-test-id="amp-filter-text-condition"]';
	private LOC_VALUE_INP = '//amp-input[@data-test-id="amp-filter-text-value"]//input';
	private LOC_SELECT_DROPDOWN_ITM = (tmp: string) =>
		`//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//span[contains(text(),"${tmp}")]`;

	public async selectCondition(name: string, condition: string) {
		const filter = name ? this.page.locator(this.LOC_FILTER_BY_NAME(name)) : this.page;
		await filter.locator(this.LOC_CONDITION_SEL).click();
		await this.page.locator(this.LOC_SELECT_DROPDOWN_ITM(condition)).click();
	}

	public async fillValue(name: string, value?: string) {
		if (value?.trim()) {
			const filter = name ? this.page.locator(this.LOC_FILTER_BY_NAME(name)) : this.page;
			const valueInput = filter.locator(this.LOC_VALUE_INP);
			await valueInput.clear();
			await valueInput.fill(value.trim());
		}
	}
}
