import { Locator } from '@playwright/test';
import { BaseFilter } from './base-filter.com.js';

export class CheckboxListFilter extends BaseFilter {
	// private LOC_FILTER_BY_NAME = (tmp: string) => `//amp-checkbox-list[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_FILTER_BY_NAME = (tmp: string) =>
		`//amp-grid-filter-container//span[normalize-space(text())="${tmp}"]/following-sibling::div[@class="amp-filter-value"][1]`;
	private LOC_FILTER_WITHOUT_LABEL = '//amp-grid-filter-container//div[@class="amp-filter-value"][1]';
	private LOC_CHECKBOX_ITM = (tmp: string) => `//amp-checkbox//span[normalize-space(text())="${tmp}"]/../../label`;

	public async setCheckboxFilter(name: string, value: string | string[]) {
		const filter = this.getFilterElement(name);
		await this.toggleAllCheckbox(filter);
		await this.selectCheckboxValues(filter, value);
	}

	private async toggleAllCheckbox(filter: Locator) {
		const allCheckbox = filter.locator(this.LOC_CHECKBOX_ITM('Select all'));
		if (!(await allCheckbox.first().isVisible())) {
			return;
		}
		const classAttribute = await allCheckbox.getAttribute('class');
		if (classAttribute?.includes('amp-checkbox--selected')) {
			await allCheckbox.click();
		} else {
			await allCheckbox.click();
			await this.page.waitForTimeout(500);
			await allCheckbox.click();
		}
	}

	private async selectCheckboxValues(filter: Locator, value: string | string[]) {
		const values = Array.isArray(value) ? value : [value];
		for (const item of values) {
			const checkboxLocator = filter.locator(this.LOC_CHECKBOX_ITM(item));
			await checkboxLocator.click();
		}
	}

	private getFilterElement(name?: string): Locator {
		return name ? this.page.locator(this.LOC_FILTER_BY_NAME(name)) : this.page.locator(this.LOC_FILTER_WITHOUT_LABEL);
	}
}
