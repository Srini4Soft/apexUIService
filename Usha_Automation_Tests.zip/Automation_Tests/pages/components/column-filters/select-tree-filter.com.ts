import { Locator } from '@playwright/test';
import { BaseFilter } from './base-filter.com.js';

export class SelectTreeFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) => `//amp-select-tree[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_FILTER_WITHOUT_LABEL = '//amp-select-tree';
	private LOC_SEARCH_INP = '//amp-input[@data-test-id="amp-select-tree-search-input"]//input';
	private LOC_SELECT_ALL_BTN = '//amp-button[@data-test-id="amp-select-tree-select-all-btn"]';
	private LOC_UNSELECT_ALL_BTN = '//amp-button[@data-test-id="amp-select-tree-unselect-all-btn"]';
	private LOC_TREE_ITM = (tmp: string) => `//amp-select-tree-item[.//span[normalize-space(text())="${tmp}"]][1]`;

	public async fillSearchInput(name: string, value: string) {
		const filter = this.getFilterElement(name);
		const searchInput = filter.locator(this.LOC_SEARCH_INP);
		await searchInput.clear();
		await searchInput.pressSequentially(value);
	}

	public async clickSelectAllButton(name: string) {
		const filter = this.getFilterElement(name);
		await filter.locator(this.LOC_SELECT_ALL_BTN).click();
	}

	public async clickUnselectAllButton(name: string) {
		const filter = this.getFilterElement(name);
		await filter.locator(this.LOC_UNSELECT_ALL_BTN).click();
	}

	public async clickTreeItemCheck(name: string, value: string) {
		const filter = this.getFilterElement(name);
		await filter.locator(this.LOC_TREE_ITM(value)).click();
	}

	private getFilterElement(name?: string): Locator {
		return name ? this.page.locator(this.LOC_FILTER_BY_NAME(name)) : this.page.locator(this.LOC_FILTER_WITHOUT_LABEL);
	}
}
