import { BaseFilter } from './base-filter.com.js';

export class NumberFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) =>
		`//amp-grid-filter-number[.//span[normalize-space(text())="${tmp}"]][1]`;
	private LOC_CONDITION_SEL = '//amp-select[@data-test-id="amp-filter-number-condition"]';
	private LOC_VALUE_INP = '//amp-input[@data-test-id="amp-filter-number-value"]//input';
	private LOC_SECOND_VALUE_INP = '//amp-input[@data-test-id="amp-filter-number-second-value"]//input';
	private LOC_SELECT_DROPDOWN_ITM = (tmp: string) =>
		`//*[@data-test-id="amp-select-overlay"]//div[@role="listbox"]//span[contains(text(),"${tmp}")]`;

	public async selectCondition(name: string, condition: string) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(name));
		await filter.locator(this.LOC_CONDITION_SEL).click();
		await this.page.locator(this.LOC_SELECT_DROPDOWN_ITM(condition)).first().click();
	}

	public async fillValue(name: string, value: number) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(name));
		await filter.locator(this.LOC_VALUE_INP).clear();
		await filter.locator(this.LOC_VALUE_INP).fill(value.toString());
	}

	public async fillSecondValue(name: string, secondValue: number) {
		const filter = this.page.locator(this.LOC_FILTER_BY_NAME(name));
		await filter.locator(this.LOC_SECOND_VALUE_INP).clear();
		await filter.locator(this.LOC_SECOND_VALUE_INP).fill(secondValue.toString());
	}
}
