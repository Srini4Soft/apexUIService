import { BaseFilter } from './base-filter.com.js';

export class CheckboxCustomFilter extends BaseFilter {
	private LOC_FILTER_BY_NAME = (tmp: string) => `//amp-grid-filter-container//amp-checkbox[.//span[text()="${tmp}"]]`;
	private LOC_FILTER_INP =
		'//amp-grid-filter-container//amp-checkbox[.//span[text()="Expiring Soon"]]/../amp-input//input';

	public async setCheckboxFilter(name: string, value?: string) {
		const checkboxLocator = this.page.locator(this.LOC_FILTER_BY_NAME(name));
		await checkboxLocator.click();
		if (value) {
			await this.page.locator(this.LOC_FILTER_INP).fill(value.toString());
		}
	}
}
