import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class GridTableComponent extends BasePage {
	private LOC_OPEN_FILTER_BTN = (column: string, type: string) =>
		`//div[@data-column-definition-name="${column}"]//amp-header-cell//amp-icon[@iconname="${type}"]`;
	private LOC_SELECT_ALL_ROWS_CHB = '//amp-checkbox[@data-test-id="amp-grid-table-select-all-checkbox"]';
	private LOC_ROW = '//div[@data-row-id]';
	private LOC_COLUMN_NAME = '//amp-grid//amp-header-cell//div[@class="amp-header-cell__title"]//span';
	private LOC_COLUMN_CONTENT = (tmp: string) =>
		`//div[contains(@class,"amp-grid-table__body")]//div[@data-column-definition-name="${tmp}"]`;
	private LOC_SORT_COLUMN_ICO = (tmp: string) =>
		`//div[@data-column-definition-name="${tmp}"]//amp-header-cell//amp-icon[contains(@iconname,"sort")]`;
	private LOC_ROW_ACTION_BTN = '//div[@data-row-id]//amp-button[@aria-haspopup="menu"]';
	private LOC_ACTION_MENU_ITM = (tmp: string) => `//amp-dropdown-item//span[normalize-space(text())="${tmp}"]`;
	private LOC_ACTION_DIALOG_YES_BTN = '//ngb-modal-window[@role="dialog"]//amp-button[@category="success"]';
	private LOC_ROW_CHB = '//div[@data-row-id]//amp-checkbox';
	private LOC_COLUMN_CELL = (row: number, column: string) =>
		`(//div[@data-row-id])[${row}]//div[@data-column-definition-name='${column}']`;

	public async clickColumnFilterButton(column: string, type: string): Promise<void> {
		const locator = this.LOC_OPEN_FILTER_BTN(column, type);
		await this.page.locator(locator).click();
	}

	public async clickOnFirstRecordId(): Promise<void> {
		const firstRow = this.page.locator(this.LOC_ROW).first();
		await firstRow.locator('(//div[contains(@class,"amp-grid-table__cell ng-star-inserted")]//a)[1]').click();
	}

	public async getRowsCount(parentElement?: Locator): Promise<number> {
		if (parentElement) {
			return (await parentElement.locator(this.LOC_ROW).all()).length;
		} else {
			return (await this.page.locator(this.LOC_ROW).all()).length;
		}
	}

	/**
	 * Returns list of displayed column names in the table.
	 *
	 * @returns {string[]} - List of displayed column names.
	 * */
	public async getColumnNames(): Promise<string[]> {
		const elements = await this.page.locator(this.LOC_COLUMN_NAME).all();
		let columnNames: string[] = [];
		for (const element of elements) {
			const text = await element.textContent();
			columnNames.push(text ? text.trim() : '');
		}

		return columnNames;
	}

	/**
	 * Returns a collection of text values ​​for cells in a specific table column.
	 *
	 * @param {string} column - Column name.
	 *
	 * @returns {string[][]} - An array of arrays of text node values ​​for each cell in the column.
	 */
	public async getColumnTextValues(column: string, index?: number): Promise<string[][]> {
		const locator = this.LOC_COLUMN_CONTENT(column);
		const baseElementHandles = await this.page.$$(locator);
		const results: string[][] = [];
		for (const baseElementHandle of baseElementHandles) {
			const textNodeValues = await baseElementHandle.evaluate((element: SVGElement | HTMLElement) => {
				const getTextNodes = (node: Node): string[] => {
					let textNodes: string[] = [];
					node.childNodes.forEach((child) => {
						if (child.nodeType === Node.TEXT_NODE) {
							textNodes.push((child.textContent || '').trim());
						} else {
							textNodes = textNodes.concat(getTextNodes(child));
						}
					});
					return textNodes;
				};
				return getTextNodes(element);
			});

			if (index !== undefined) {
				results.push([textNodeValues[index] || '']);
			} else {
				results.push(textNodeValues);
			}
		}

		return results;
	}

	/**
	 * Returns a collection of icon values ​​for cells in a Tasks table column.
	 * Take info from data-test-value attribute.
	 *
	 * @param {string} column - Column name.
	 *
	 * @returns {string[][][]} - An array of arrays of attribute values ​​for each cell in the column.
	 */
	public async getTasksColumnIconValues(column: string): Promise<string[][][]> {
		const locator = this.LOC_COLUMN_CONTENT(column);
		const baseElementHandles = await this.page.$$(locator);

		const results: string[][][] = [];
		for (const cellHandle of baseElementHandles) {
			const taskItemHandles = await cellHandle.$$('amp-grid-case-task-item');
			const cellResults: string[][] = [];

			for (const taskItemHandle of taskItemHandles) {
				const iconHandles = await taskItemHandle.$$('amp-icon');
				const iconValues = await Promise.all(
					iconHandles.map(async (iconHandle) => {
						const value = await iconHandle.getAttribute('data-test-value');
						return value ?? '';
					})
				);

				cellResults.push(iconValues);
			}

			results.push(cellResults);
		}

		return results;
	}

	/**
	 * Returns a collection of icon values ​​for cells in a table column.
	 * Take info from data-test-value attribute.
	 *
	 * @param {string} column - Column name.
	 *
	 * @returns {string[][]} - An array of arrays of attribute values ​​for each cell in the column.
	 */
	public async getColumnIconValues(column: string): Promise<string[][]> {
		const locator = this.LOC_COLUMN_CONTENT(column);
		const baseElementHandles = await this.page.$$(locator);
		const results: string[][] = [];
		for (const cellHandle of baseElementHandles) {
			const iconHandles = await cellHandle.$$('amp-icon');
			const iconValues = await Promise.all(
				iconHandles.map(async (iconHandle) => {
					const value =
						(await iconHandle.getAttribute('data-test-value')) || (await iconHandle.getAttribute('iconname'));
					return value ?? '';
				})
			);

			results.push(iconValues);
		}

		return results;
	}

	public async getCurrentSortOrder(column: string): Promise<string> {
		const locator = this.LOC_SORT_COLUMN_ICO(column);
		return (await this.page.locator(locator).getAttribute('iconname')) ?? 'sort';
	}

	public async clickSortColumnButton(column: string): Promise<void> {
		const locator = this.LOC_SORT_COLUMN_ICO(column);
		await this.page.locator(locator).click();
	}

	public async clickRowActionMenuButton(rowNumber: number): Promise<void> {
		const locator = `(${this.LOC_ROW_ACTION_BTN})[${rowNumber}]`;
		await this.page.locator(locator).click();
	}

	public async clickOnColumnCell(rowNumber: number, column: string) {
		const locator = this.LOC_COLUMN_CELL(rowNumber, column);
		await this.page.locator(locator).click();
	}

	public async clickActionMenuItem(action: string): Promise<void> {
		const locator = this.LOC_ACTION_MENU_ITM(action);
		await this.page.locator(locator).click();
	}

	public async confirmActionDialog(): Promise<void> {
		const isDialogVisible = await this.page.locator(this.LOC_ACTION_DIALOG_YES_BTN).isVisible();
		if (isDialogVisible) {
			await this.page.locator(this.LOC_ACTION_DIALOG_YES_BTN).click();
		} else {
			console.log('Dialog confirmation button is not visible, skipping action.');
		}
	}

	public async clickRowSelectCheckBox(rowNumber: number): Promise<void> {
		const locator = `(${this.LOC_ROW_CHB})[${rowNumber}]`;
		await this.page.locator(locator).click();
	}

	/*	ELEMENTS VERIFICATION 	*/
	public async isSelectAllButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_SELECT_ALL_ROWS_CHB).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_SELECT_ALL_ROWS_CHB})[1]`).isVisible({ timeout: 5000 });
		}
	}
}
