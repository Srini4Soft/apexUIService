import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class GridMenuComponent extends BasePage {
	private LOC_MENU_ITM = (tmp: string) =>
		`//div[contains(@id,"mat-menu-panel")]//amp-dropdown-item[.//span[normalize-space(text())="${tmp}"]]`;
	private LOC_EXPORT_TO_CSV_BTN = '//*[@data-test-id="amp-grid-toolbar-menu-export-btn"]';
	private LOC_PRINT_MENU_BTN = '//*[@data-test-id="amp-grid-toolbar-menu-print-btn"]';
	private LOC_PRINT_VIEW_BTN = '//amp-grid-toolbar-print//button[span[text()="Print"]]';
	private LOC_RESET_VIEW_BTN =
		'//div[contains(@id,"mat-menu-panel")]//amp-dropdown-item//span[normalize-space(text())="Reset View"]';
	private LOC_COLUMN_SETTINGS_BTN =
		'//div[contains(@id,"mat-menu-panel")]//amp-dropdown-item//span[normalize-space(text())="Columns"]';
	private LOC_CUSTOM_FILTER_BTN =
		'//div[contains(@id,"mat-menu-panel")]//amp-dropdown-item//span[normalize-space(text())="Custom Filter"]';
	private LOC_SAVE_VIEW_BTN = '//amp-dropdown-item[@data-test-id="amp-grid-toolbar-menu-save-view-btn"]';
	private LOC_UPDATE_VIEW_BTN = '//amp-dropdown-item[@data-test-id="amp-grid-toolbar-menu-update-view-btn"]';
	private LOC_SEARCH_VIEW_INP = '//amp-input[@data-test-id="amp-grid-toolbar-menu-search-input"]//input';
	private LOC_SAVED_VIEW_ITM = (tmp: string) =>
		`//div[@ampscrollbar]//amp-dropdown-item//span[normalize-space(text())="${tmp}"]`;
	private LOC_COMPARE_LIST_CONDITIONS_BTN = '//amp-dropdown-item[@iconname="arrow-right-arrow-left"]';

	public async clickColumnsSettingsButton(): Promise<void> {
		await this.page.locator(this.LOC_COLUMN_SETTINGS_BTN).click();
	}

	public async clickExportToCSVButton(): Promise<void> {
		await this.page.locator(this.LOC_EXPORT_TO_CSV_BTN).click();
		await this.page.waitForTimeout(2000);
	}

	public async clickResetViewButton(): Promise<void> {
		await this.page.locator(this.LOC_RESET_VIEW_BTN).click();
	}

	public async clickPrintViewButton(): Promise<void> {
		await this.page.locator(this.LOC_PRINT_MENU_BTN).click();
		await this.page.locator(this.LOC_PRINT_VIEW_BTN).click();
	}

	public async clickCustomFilterButton(): Promise<void> {
		await this.page.locator(this.LOC_CUSTOM_FILTER_BTN).click();
	}

	public async clickSaveViewButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_VIEW_BTN).click();
	}

	public async clickUpdateViewButton(): Promise<void> {
		await this.page.locator(this.LOC_UPDATE_VIEW_BTN).click();
	}

	public async fillViewSearchInput(name: string): Promise<void> {
		await this.page.locator(this.LOC_SEARCH_VIEW_INP).clear();
		await this.page.locator(this.LOC_SEARCH_VIEW_INP).click();
		await this.page.keyboard.type(name);
	}

	public async clickViewByName(name: string): Promise<void> {
		const locator = this.LOC_SAVED_VIEW_ITM(name);
		await this.page.locator(locator).click();
	}

	public async clickCompareListConditionsButton(): Promise<void> {
		await this.page.locator(this.LOC_COMPARE_LIST_CONDITIONS_BTN).click();
	}

	public async clickDynamicMenuItem(name: string): Promise<void> {
		const locator = this.LOC_MENU_ITM(name);
		await this.page.locator(locator).click();
	}

	public async updateViewLink(oldName: string, newName: string): Promise<void> {
		const locLinkName = '//amp-input[@formcontrolname="name"]//input';
		const locUpdateButton = '//amp-button[@category="success"]';

		await this.selectDropdownValue(oldName);
		await this.page.locator(locLinkName).fill(newName);
		await this.page.locator(locUpdateButton).click();
	}

	/* ASSERTIONS */
	public async isMenuItemVisible(itemName: string, parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_MENU_ITM(itemName)).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_MENU_ITM(itemName)})[1]`).isVisible({ timeout: 5000 });
		}
	}
}
