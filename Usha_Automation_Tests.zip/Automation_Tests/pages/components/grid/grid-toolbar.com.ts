import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class GridToolbarComponent extends BasePage {
	private readonly LOC_MENU_BTN = '//amp-button[@data-test-id="amp-grid-toolbar-menu-btn"]';
	private readonly LOC_MENU_BTN_MVC = '//button[@id="common-menu"]';
	private readonly LOC_SEARCH_BTN = '//amp-button[@data-test-id="amp-grid-toolbar-search-btn"]';
	private readonly LOC_SEARCH_INP = '//amp-input[@data-test-id="amp-grid-toolbar-search-input"]//input';
	private readonly LOC_RESET_FILTER_BTN = '//amp-button[@data-test-id="amp-grid-toolbar-reset-filters-btn"]';
	private readonly LOC_GRID_TITLE = '//amp-grid-title/h2/span/span[1]';
	private readonly LOC_FACILITY_NUMBER = '//amp-grid-title//amp-badge//span';
	private readonly LOC_FACILITY_NAME = '//amp-grid-title//span[contains(@class,"page__title--city")]';

	public async clickMenuButton(): Promise<void> {
		await this.page.locator(this.LOC_MENU_BTN).click();
	}

	public async clickSearchButton(): Promise<void> {
		await this.page.locator(this.LOC_SEARCH_BTN).click();
	}

	public async fillSearchInput(value: string): Promise<void> {
		await this.page.locator(this.LOC_SEARCH_INP).fill(value.trim());
	}

	public async clickResetFiltersButton(): Promise<void> {
		await this.page.locator(this.LOC_RESET_FILTER_BTN).click();
	}

	public async getGridTitleValue(): Promise<string> {
		const value = await this.page.locator(this.LOC_GRID_TITLE).textContent();
		return value !== null ? value.trim() : '';
	}

	public getGridTitleLocator(): Locator {
		return this.page.locator(this.LOC_GRID_TITLE);
	}

	public async getFacilityInfoValue(): Promise<{ name: string; number: string }> {
		const name = await this.page.locator(this.LOC_FACILITY_NAME).textContent();
		const number = await this.page.locator(this.LOC_FACILITY_NUMBER).textContent();
		return {
			name: name !== null ? name.trim() : '',
			number: number !== null ? number.trim() : '',
		};
	}

	/* ASSERTIONS */
	public async isMenuButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_MENU_BTN).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_MENU_BTN})[1]`).isVisible({ timeout: 5000 });
		}
	}

	// Method version for MVC UI (not V2)
	public async isMenuButtonVisibleMvc(): Promise<boolean> {
		return await this.page.locator(`(${this.LOC_MENU_BTN_MVC})[1]`).isVisible({ timeout: 5000 });
	}

	public async isSearchButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_SEARCH_BTN).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_SEARCH_BTN})[1]`).isVisible({ timeout: 5000 });
		}
	}

	public async isResetFiltersButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_RESET_FILTER_BTN).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_RESET_FILTER_BTN})[1]`).isVisible({ timeout: 5000 });
		}
	}
}
