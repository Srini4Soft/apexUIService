import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';
import { GridTableComponent } from './grid-table.com.js';

export class GridPagerComponent extends BasePage {
	private comGridTable: GridTableComponent;
	private LOC_PAGE_SIZE_SEL = '//amp-select[@data-test-id="amp-grid-pager-page-size-select"]';
	private LOC_PREV_PAGE_BTN = '//amp-button[@data-test-id="amp-grid-pager-previous-page-btn"]';
	private LOC_PAGES_LIST = '//ul[@data-test-id="amp-grid-pager-pages-menu"]';
	private LOC_NEXT_PAGE_BTN = '//amp-button[@data-test-id="amp-grid-pager-next-page-btn"]';
	private LOC_TOTAL_ROWS_LBL = '//*[@data-test-id="amp-grid-pager-total-count-label"]';

	constructor() {
		super();
		this.comGridTable = new GridTableComponent();
	}

	/**
	 * Returns the total number of records. The value is taken from the element next to Page Size. Example: "Showing 1 - 25 of 84" will return 84.
	 * @returns {number} - number of records
	 * */
	public async getFooterTotalRowsCount(parentElement?: Locator): Promise<number> {
		let totalText = '';
		if ((await this.comGridTable.getRowsCount(parentElement)) == 0) {
			return 0;
		}

		if (parentElement) {
			totalText = await parentElement.locator(this.LOC_TOTAL_ROWS_LBL).innerText();
		} else {
			totalText = await this.page.locator(`(${this.LOC_TOTAL_ROWS_LBL})[1]`).innerText();
		}

		const totalCount: number = Number(totalText.match(/[\d,]+$/)?.[0].replace(/,/g, ''));
		return totalCount;
	}

	public async setPageSize(value: number): Promise<void> {
		await this.page.locator(this.LOC_PAGE_SIZE_SEL).click();
		await this.page.locator(`//ng-dropdown-panel//div[@role="listbox"]//span[contains(text(),"${value}")]`).click();
	}

	/* ASSERTIONS */
	public async isPageSizeSelectorVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_PAGE_SIZE_SEL).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_PAGE_SIZE_SEL})[1]`).isVisible({ timeout: 5000 });
		}
	}

	public async isPreviousPageButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_PREV_PAGE_BTN).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_PREV_PAGE_BTN})[1]`).isVisible({ timeout: 5000 });
		}
	}

	public async isNextPageButtonVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_NEXT_PAGE_BTN).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_NEXT_PAGE_BTN})[1]`).isVisible({ timeout: 5000 });
		}
	}

	public async isPagesListVisible(parentElement?: Locator): Promise<boolean> {
		if (parentElement) {
			return await parentElement.locator(this.LOC_PAGES_LIST).isVisible({ timeout: 5000 });
		} else {
			return await this.page.locator(`(${this.LOC_PAGES_LIST})[1]`).isVisible({ timeout: 5000 });
		}
	}
}
