import { BasePage } from 'src/pages/base.page.js';

export class GridMenuColumnsComponent extends BasePage {
	private LOC_SELECT_ALL_CHB = '//div[contains(@id,"mat-menu-panel")]//form//amp-button[@icon="filter-checked"]';
	private LOC_UNSELECT_ALL_CHB = '//div[contains(@id,"mat-menu-panel")]//form//amp-button[@icon="filter-unchecked"]';
	private LOC_COLUMN_CHB =
		'//div[@id="columns"]//div[@cdkdrag]//amp-checkbox//label[contains(@class,"amp-checkbox--unselected")]//span[contains(@class,"text-nowrap")][normalize-space(text())="${tmp}"]';
	private LOC_SELECT_COLUMN_CHB =
		'//div[@id="columns"]//div[@cdkdrag]//amp-checkbox//label[contains(@class,"amp-checkbox--selected")]//span[contains(@class,"text-nowrap")]';
	private LOC_APPLY_BTN = '(//div[contains(@id,"mat-menu-panel")]//form//amp-button[@class="ng-star-inserted"])[1]';

	public async clickSelectAllCheckbox(): Promise<void> {
		await this.page.locator(this.LOC_SELECT_ALL_CHB).click();
	}

	public async clickUnselectAllCheckbox(): Promise<void> {
		await this.page.locator(this.LOC_UNSELECT_ALL_CHB).click();
	}

	public async clickColumnCheckbox(name: string): Promise<void> {
		await this.page.locator(this.LOC_COLUMN_CHB.replace('${tmp}', name)).click();
	}

	public async getSelectedColumnsList(): Promise<string[]> {
		const elements = await this.page.locator(this.LOC_SELECT_COLUMN_CHB).all();
		let columnNames: string[] = [];
		for (const element of elements) {
			const text = await element.textContent();
			columnNames.push(text ? text.trim() : '');
		}
		return columnNames;
	}

	public async clickApplyButton(): Promise<void> {
		await this.page.locator(this.LOC_APPLY_BTN).click();
	}
}
