import { expect } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class GridSaveViewComponent extends BasePage {
	private readonly LOC_SAVE_BTN = '//ngb-modal-window//amp-button[@category="success"]';
	private readonly LOC_LINK_NAME_BTN = '//ngb-modal-window//amp-input[@formcontrolname="name"]//input';

	public async fillLinkNameInput(name: string): Promise<void> {
		await this.page.locator(this.LOC_LINK_NAME_BTN).fill(name);
	}

	public async clickSaveButton(): Promise<void> {
		await expect(this.page.locator(this.LOC_SAVE_BTN), 'Is "Save" button visible?').toBeVisible();
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}
}
