import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class RtsDashboardPage extends BasePage {
	private LOC_COMMON_WIDGET_TITLE = (tmp: string) =>
		`//amp-dashboard-widget//amp-dashboard-tile//div[contains(text(),"${tmp}")]`;

	public async open(): Promise<void> {
		const url = URL.RTS_DASHBOARD;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */

	/* ASSERTIONS */
	public async isWidgetVisible(value: string): Promise<boolean> {
		const locator = this.LOC_COMMON_WIDGET_TITLE(value);
		return this.page.locator(locator).isVisible();
	}
}
