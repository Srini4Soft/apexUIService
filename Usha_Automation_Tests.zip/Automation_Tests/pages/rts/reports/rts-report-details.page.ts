import { BasePage } from 'src/pages/base.page.js';

export class RtsReportDetailsPage extends BasePage {
	private readonly LOC_REPORT_TABS = '//amp-report-details/form//amp-tabs';
	private readonly LOC_VIEW_REPORT_BTN = '//amp-button//span[contains(text(),"View Report")]';
	private readonly LOC_RETURN_BTN = '//amp-button//span[contains(text(),"Return")]';

	/* ACTIONS */

	/* ASSERTIONS */
	public async isReportTabsVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_REPORT_TABS).isVisible();
	}

	public async isViewReportButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_VIEW_REPORT_BTN).isVisible();
	}

	public async isReturnButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_RETURN_BTN).isVisible();
	}
}
