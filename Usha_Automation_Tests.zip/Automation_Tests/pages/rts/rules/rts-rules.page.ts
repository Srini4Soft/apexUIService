import { URL } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class RtsRulesPage extends BasePage {
	private readonly LOC_AUTOMATION_RULES_TAB = '//amp-tabs//a[@href="/v2/referrals/settings/rules/automationrules"]';
	private readonly LOC_VALIDATION_RULES_TAB = '//amp-tabs//a[@href="/v2/referrals/settings/rules/validationrules"]';
	private readonly LOC_NRI_VALIDATION_RULES_TAB =
		'//amp-tabs//a[@href="/v2/referrals/settings/rules/nrivalidationrules"]';
	private readonly LOC_CREATE_RULE_BUTTON = '//div[@id="ampReferralsSettingsHeaderActions"]//amp-button';

	public async open(): Promise<void> {
		const url = URL.RTS_RULES;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async openAutomationRulesTab() {
		await this.page.locator(this.LOC_AUTOMATION_RULES_TAB).click();
	}

	public async openValidationRulesTab() {
		await this.page.locator(this.LOC_VALIDATION_RULES_TAB).click();
	}

	public async openNriValidationRulesTab() {
		await this.page.locator(this.LOC_NRI_VALIDATION_RULES_TAB).click();
	}

	public async clickCreateRuleButton() {
		await this.page.locator(this.LOC_CREATE_RULE_BUTTON).click();
	}

	/* ASSERTIONS */
	public async isCreateRuleButtonVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_CREATE_RULE_BUTTON).isVisible();
	}
}
