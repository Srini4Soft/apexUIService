import { BasePage } from 'src/pages/base.page.js';

export class RtsReferralRelatedCases extends BasePage {
	private LOC_RELATED_CASES = (tmp: string) => `//amp-related-cases//amp-related-cases-list//li[${tmp}]`;

	/* ACTIONS */
	public async clickOnRelatedCasesLink(position: number): Promise<void> {
		await this.page.locator(this.LOC_RELATED_CASES(position.toString())).click();
	}
}
