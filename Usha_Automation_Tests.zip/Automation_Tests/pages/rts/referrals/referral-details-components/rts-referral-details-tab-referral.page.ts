import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class RtsReferralTabReferral extends BasePage {
	/* Main section */
	private LOC_OWNER_SEL = '//amp-select[@formcontrolname="ownerUserId"]';
	private LOC_CASE_STATUS_SEL = '//amp-select[@formcontrolname="caseStatusId"]';
	private LOC_BED_SEL = '//amp-select[@formcontrolname="tenantEntityBedId"]';
	private LOC_SOURCE_SEL = '//amp-select[@formcontrolname="caseSourceId"]';
	private LOC_SOURCE_CONTACT_SEL = '//amp-select[@formcontrolname="caseSourceContactId"]';
	private LOC_SOURCE_CONTACT_INP = '//amp-select[@formcontrolname="caseSourceContactId"]//input';
	private LOC_DAILY_DRUG_COST_SEL = '//amp-select[@formcontrolname="projectedDailyDrugCost"]';
	private LOC_DAILY_REHAB_COST_SEL = '//amp-select[@formcontrolname="projectedDailyRehabCost"]';
	private LOC_ADMISSION_DAT = '//amp-input[@formcontrolname="admissionDate"]//input';
	private LOC_PROSPECTIVE_ADMISSION_DAT = '//amp-input[@formcontrolname="prospectiveAdmissionDate"]//input';
	private LOC_HOSPITAL_DATES_DAT = '//amp-input[@formcontrolname="hospitalDates"]//input';
	private LOC_HOSPITAL_DATES_DATE_PICKER = '//amp-input[@formcontrolname="hospitalDates"]//input';
	/* Demographics section */
	private LOC_FIRST_NAME_INP = '//amp-input[@formcontrolname="firstName"]//input';
	private LOC_MIDDLE_NAME_INP = '//amp-input[@formcontrolname="middleName"]//input';
	private LOC_BIRTH_DAT = '//amp-input[@formcontrolname="birthDate"]//input';
	private LOC_GENDER_SELECT = '//amp-select[@formcontrolname="gender"]';
	private LOC_SSN_NAME_INP = '//amp-input[@formcontrolname="ssn"]//input';
	private LOC_MEDICARE_NUMBER_INP = '//amp-input[@formcontrolname="medicareNumber"]//input';
	private LOC_MEDICAID_NUMBER_INP = '//amp-input[@formcontrolname="medicaidNumber"]//input[@autocomplete="on"]';
	/* Payer section */
	private LOC_PAYER_CATEGORY_SEL = '//amp-select[@formcontrolname="payerCategoryId"]';

	/* ACTIONS */
	/* Main section */
	public async fillOwnerField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_OWNER_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillCaseStatusField(value: string) {
		const element: Locator = this.page.locator(this.LOC_CASE_STATUS_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillProspectiveAdmissionDateField(value: string) {
		const element: Locator = this.page.locator(this.LOC_PROSPECTIVE_ADMISSION_DAT);
		await this.setDateValue(element, value);
	}

	public async fillAdmissionDateField(value: string) {
		const element: Locator = this.page.locator(this.LOC_ADMISSION_DAT);
		await this.setDateValue(element, value);
	}

	public async fillBedField(value: string) {
		const element: Locator = this.page.locator(this.LOC_BED_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillSourceField(value: string) {
		const element: Locator = this.page.locator(this.LOC_SOURCE_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillSourceContactField(value: string) {
		// await this.page.locator(this.LOC_SOURCE_CONTACT_INP).click();
		const inputElement: Locator = this.page.locator(this.LOC_SOURCE_CONTACT_INP);
		await this.setInputValue(inputElement, value);
		await this.waitForPageLoad();

		const element: Locator = this.page.locator(this.LOC_SOURCE_CONTACT_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillDailyDrugCostField(value: string) {
		const element: Locator = this.page.locator(this.LOC_DAILY_DRUG_COST_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillDailyRehabCostField(value: string) {
		const element: Locator = this.page.locator(this.LOC_DAILY_REHAB_COST_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillHospitalDatesField(fromDate: string, toDate: string) {
		await this.page.locator(this.LOC_HOSPITAL_DATES_DATE_PICKER).click();
		await this.page.locator(this.LOC_HOSPITAL_DATES_DAT).pressSequentially(fromDate);
		await this.page.locator(this.LOC_HOSPITAL_DATES_DAT).pressSequentially(toDate);
		await this.pressKeyboardButton('Enter');
	}

	/* Demographics section */
	public async fillFirstNameField(value: string) {
		const element: Locator = this.page.locator(this.LOC_FIRST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillMiddleNameField(value: string) {
		const element: Locator = this.page.locator(this.LOC_MIDDLE_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillBirthDateField(value: string) {
		const element: Locator = this.page.locator(this.LOC_BIRTH_DAT);
		await this.setDateValue(element, value);
	}

	public async fillGenderField(value: string) {
		const element: Locator = this.page.locator(this.LOC_GENDER_SELECT);
		await this.setDropdownValue(element, value);
	}

	public async fillSsnField(value: string) {
		const element: Locator = this.page.locator(this.LOC_SSN_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillMedicareNumberField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MEDICARE_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	public async fillMedicaidNumberField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MEDICAID_NUMBER_INP);
		await this.setInputValue(element, value);
	}

	/* Payer section */
	public async fillPayerCategoryField(value: string) {
		const element: Locator = this.page.locator(this.LOC_PAYER_CATEGORY_SEL);
		await this.setDropdownValue(element, value);
	}
}
