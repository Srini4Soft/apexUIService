import { BasePage } from 'src/pages/base.page.js';

export class RtsReferralTabNotes extends BasePage {
	private LOC_NOTE_MESSAGE = '//amp-rts-veripay-case-notes//amp-discussion-message//span';

	public async getNotesMessages(): Promise<string[]> {
		const elementsLocator = this.page.locator(this.LOC_NOTE_MESSAGE);
		await elementsLocator.first().waitFor();
		return await elementsLocator.allTextContents();
	}
}
