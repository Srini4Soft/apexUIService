import { BasePage } from 'src/pages/base.page.js';
import { RtsReferralRelatedCases, RtsReferralTabNotes, RtsReferralTabReferral } from 'src/pages/index.js';

export class RtsReferralDetailsPage extends BasePage {
	public pageReferral: RtsReferralTabReferral;
	public pageRelatedCases: RtsReferralRelatedCases;
	public pageNotes: RtsReferralTabNotes;

	/* LOCATORS */
	private LOC_RELATED_CASES_BTN = '//amp-details-title//amp-button[@icon="related-cases"]';
	private LOC_REFERRAL_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/referral") + 1) = "/referral"]';
	private LOC_NOTES_TAB =
		'//amp-tabs//a[substring(@href, string-length(@href) - string-length("/notes") + 1) = "/notes"]';
	private LOC_FINISH_BTN = '//footer//button//span[normalize-space(text())="Finish"]';
	private LOC_SAVE_BTN = '//footer//button//span[normalize-space(text())="Save"]';

	constructor() {
		super();
		this.pageReferral = new RtsReferralTabReferral();
		this.pageRelatedCases = new RtsReferralRelatedCases();
		this.pageNotes = new RtsReferralTabNotes();
	}

	/* ACTIONS */
	public async clickReferralTab(): Promise<void> {
		await this.page.locator(this.LOC_REFERRAL_TAB).click();
	}

	public async clickNotesTab(): Promise<void> {
		await this.page.locator(this.LOC_NOTES_TAB).click();
	}

	public async clickRelatedCasesButton(): Promise<void> {
		if ((await this.page.locator(this.LOC_RELATED_CASES_BTN).getAttribute('disabled')) === null) {
			await this.page.locator(this.LOC_RELATED_CASES_BTN).click();
		}
	}

	public async clickFinishButton(): Promise<void> {
		await this.page.locator(this.LOC_FINISH_BTN).click();
		await this.waitForTimeout(5000);
	}

	public async clickSaveButton(): Promise<void> {
		await this.page.locator(this.LOC_SAVE_BTN).click();
	}

	//TODO: move to separate page
	// public async getNotesMessages(): Promise<string[]> {
	// 	const locator = '//amp-rts-veripay-case-notes//amp-discussion-message//span';
	// 	const elementsLocator = this.page.locator(locator);
	// 	await elementsLocator.first().waitFor();
	// 	return await elementsLocator.allTextContents();
	// }
}
