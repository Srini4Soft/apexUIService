import { Locator } from '@playwright/test';
import { BasePage } from 'src/pages/base.page.js';

export class RtsCreateReferralPage extends BasePage {
	private LOC_FACILITY_SEL = '//amp-select-tree[@formcontrolname="facilityId"]//amp-button';
	private LOC_OWNER_SEL = '//amp-select[@formcontrolname="ownerUserId"]//ng-select';
	private LOC_LAST_NAME_INP = '//amp-input[@formcontrolname="lastName"]//input';
	private LOC_FIRST_NAME_INP = '//amp-input[@formcontrolname="firstName"]//input';
	private LOC_DOB_INP = '//amp-input[@formcontrolname="birthDate"]//input';
	private LOC_SSN_INP = '//amp-input[@formcontrolname="ssn"]//input';
	private LOC_MEDICARE_INP = '//amp-input[@formcontrolname="medicareNumber"]//input';
	private LOC_MEDICAID_DRP = '//amp-input[@formcontrolname="medicaidNumber"]//amp-select';
	private LOC_MEDICAID_INP = '//amp-input[@formcontrolname="medicaidNumber"]//input[contains(@id, "amp-input")]';
	private LOC_CREATE_BTN = '//footer//amp-button[@category="success"]//button';
	private LOC_CANCEL_BTN = '//footer//amp-button[@category="subtle"]//button';
	private LOC_FOUND_RESIDENTS_BANNER = '//amp-found-residents//amp-inline-banner';

	/* ACTIONS */
	public async fillFacilityField(value: string) {
		const element: Locator = this.page.locator(this.LOC_FACILITY_SEL);
		await this.setFacilityDropdownValue(element, value);
	}

	public async fillOwnerField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_OWNER_SEL);
		await this.setDropdownValue(element, value);
	}

	public async fillLastNameField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_LAST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillFirstNameField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_FIRST_NAME_INP);
		await this.setInputValue(element, value);
	}

	public async fillDobField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_DOB_INP);
		await this.setDateValue(element, value);
	}

	public async fillSsnField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_SSN_INP);
		await this.setInputValue(element, value);
	}

	public async fillMedicareField(value: string): Promise<void> {
		const element: Locator = this.page.locator(this.LOC_MEDICARE_INP);
		await this.setInputValue(element, value);
	}

	public async fillMedicaidField(state: string, value: string): Promise<void> {
		const stateSelector: Locator = this.page.locator(this.LOC_MEDICAID_DRP);
		const number: Locator = this.page.locator(this.LOC_MEDICAID_INP);
		await this.setDropdownValue(stateSelector, state);
		await this.setInputValue(number, value);
	}

	public async clickCreateButton(): Promise<void> {
		await this.page.locator(this.LOC_CREATE_BTN).click();
		await this.waitForTimeout(5000);
	}

	public async clickCancelButton(): Promise<void> {
		await this.page.locator(this.LOC_CANCEL_BTN).click();
	}

	/* ASSERTIONS */
	public async isBannerVisible(): Promise<boolean> {
		return await this.page.locator(this.LOC_FOUND_RESIDENTS_BANNER).isVisible();
	}

	public async isCreateButtonEnabled(): Promise<boolean> {
		return await this.page.locator(this.LOC_CREATE_BTN).isEnabled();
	}
}
