import { URL } from 'src/common/enums/page-url.enum.js';
import log from 'src/common/utils/logger.js';
import { BasePage } from 'src/pages/base.page.js';

export class RtsReferralsPage extends BasePage {
	private LOC_CREATE_REFERRAL_BTN = '//amp-button[@data-test-id="amp-create-referral-case-btn"]';

	public async open(): Promise<void> {
		const url = URL.RTS_REFERRALS;
		log.info(`Open page: ${url}`);
		await this.page.goto(url);
		await this.page.waitForURL(`**${url}`);
	}

	/* ACTIONS */
	public async clickCreateReferralButton() {
		await this.page.locator(this.LOC_CREATE_REFERRAL_BTN).click();
	}

	/* ASSERTIONS */
	public async isCreateReferralButtonVisible() {
		return this.page.locator(this.LOC_CREATE_REFERRAL_BTN).isVisible();
	}
}
