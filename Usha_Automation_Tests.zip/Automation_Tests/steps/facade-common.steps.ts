import { BaseSteps } from './base.steps.js';
import { ProfileMenuSteps } from './components/profile-menu.steps.js';
import {
	ColumnFiltersSteps,
	ConditionComparisonSteps,
	CustomFilterSteps,
	DashboardSteps,
	FacilityFilterSteps,
	FormReaderSteps,
	GridSteps,
	NavigationStepsFacade,
	ShareLinkSteps,
	ToasterSteps,
} from './index.js';

export class CommonStepsFacade extends BaseSteps {
	public columnFilter: ColumnFiltersSteps;
	public conditionComparison: ConditionComparisonSteps;
	public customFilter: CustomFilterSteps;
	public dashboard: DashboardSteps;
	public facilityFilter: FacilityFilterSteps;
	public shareLink: ShareLinkSteps;
	public formReader: FormReaderSteps;
	public grid: GridSteps;
	public navigation: NavigationStepsFacade;
	public profileMenu: ProfileMenuSteps;
	public toaster: ToasterSteps;

	constructor() {
		super();
		this.columnFilter = new ColumnFiltersSteps();
		this.conditionComparison = new ConditionComparisonSteps();
		this.customFilter = new CustomFilterSteps();
		this.dashboard = new DashboardSteps();
		this.facilityFilter = new FacilityFilterSteps();
		this.shareLink = new ShareLinkSteps();
		this.formReader = new FormReaderSteps();
		this.grid = new GridSteps();
		this.navigation = new NavigationStepsFacade();
		this.profileMenu = new ProfileMenuSteps();
		this.toaster = new ToasterSteps();
	}
}
