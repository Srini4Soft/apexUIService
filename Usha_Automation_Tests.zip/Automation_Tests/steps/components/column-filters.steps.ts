import { test } from 'src/common/fixtures/test-fixture.js';
import log from 'src/common/utils/logger.js';
import {
	BaseFilter,
	BooleanFilter,
	CheckboxCustomFilter,
	CheckboxListFilter,
	DateRangeFilter,
	EnumerationFilter,
	MultiEnumerationFilter,
	NumberFilter,
	SelectTreeFilter,
	TextFilter,
} from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class ColumnFiltersSteps extends BaseSteps {
	private filterBase: BaseFilter;
	private filterBoolean: BooleanFilter;
	private filterDateRange: DateRangeFilter;
	private filterEnumeration: EnumerationFilter;
	private filterCheckboxCustom: CheckboxCustomFilter;
	private filterCheckboxList: CheckboxListFilter;
	private filterMultiEnumeration: MultiEnumerationFilter;
	private filterNumber: NumberFilter;
	private filterSelectTree: SelectTreeFilter;
	private filterText: TextFilter;

	constructor() {
		super();
		this.filterBase = new BaseFilter();
		this.filterBoolean = new BooleanFilter();
		this.filterDateRange = new DateRangeFilter();
		this.filterEnumeration = new EnumerationFilter();
		this.filterCheckboxCustom = new CheckboxCustomFilter();
		this.filterCheckboxList = new CheckboxListFilter();
		this.filterMultiEnumeration = new MultiEnumerationFilter();
		this.filterNumber = new NumberFilter();
		this.filterSelectTree = new SelectTreeFilter();
		this.filterText = new TextFilter();
	}

	public async applyFilter() {
		await test.step('Apply column filter', async () => {
			await this.filterBase.apply();
			await this.waitForPageLoad();
		});
	}

	public async clearFilter() {
		await test.step('Clear column filter', async () => {
			await this.filterBase.clear();
			await this.waitForPageLoad();
		});
	}

	public async fillCustomCheckboxFilter(name: string, value?: string) {
		await test.step(`Fill custom checkbox filter "${name}" with values: "${JSON.stringify(value)}"`, async () => {
			await this.filterCheckboxCustom.setCheckboxFilter(name, value);
		});
	}

	public async fillMultiEnumCheckboxFilter(name: string, values: string[]) {
		await test.step(`Fill multi checkbox filter "${name}" with values: "${JSON.stringify(values)}"`, async () => {
			if (values.length == 0) {
				log.info('Unselect all columns. Columns array is empty');
				await this.filterMultiEnumeration.unselectAllChecks(name);
			} else if (values.includes('All')) {
				log.info('Select all columns. Array has "All" item');
				await this.filterMultiEnumeration.unselectAllChecks(name);
				await this.filterMultiEnumeration.selectAllChecks(name);
			} else {
				await this.filterMultiEnumeration.unselectAllChecks(name);
				await this.filterMultiEnumeration.setCheckboxFilter(name, values);
			}
		});
	}

	public async fillEnumCheckboxFilter(name: string, value: string[]) {
		await test.step(`Fill checkbox filter "${name}" with values: "${JSON.stringify(value)}"`, async () => {
			await this.filterEnumeration.setCheckboxFilter(name, value);
		});
	}

	public async fillCheckboxListFilter(name: string, value: string[]) {
		await test.step(`Fill checkbox list filter "${name}" with values: "${JSON.stringify(value)}"`, async () => {
			await this.filterCheckboxList.setCheckboxFilter(name, value);
		});
	}

	public async fillEnumRadioFilter(name: string, value: string) {
		await test.step(`Fill radio filter "${name}" with value: "${value}"`, async () => {
			await this.filterEnumeration.clickRadioButtonItem(name, value);
		});
	}

	public async fillEnumDropdownFilter(name: string, value: string) {
		await test.step(`Fill dropdown filter "${name}" with value: "${value}"`, async () => {
			await this.filterEnumeration.selectDropdown(name, value);
		});
	}

	public async fillBooleanFilter(name: string, value: string) {
		await test.step(`Fill boolean filter "${name}" with value: "${value}"`, async () => {
			await this.filterBoolean.clickRadioButtonItem(name, value);
		});
	}

	public async fillTextFilter(name: string, condition: string, value?: string) {
		await test.step(`Fill text filter "${name}" with condition: "${condition}" and value: "${value}"`, async () => {
			await this.filterText.selectCondition(name, condition);
			await this.filterText.fillValue(name, value);
		});
	}

	public async fillNumberFilter(name: string, condition: string, value?: number, secondValue?: number) {
		await test.step(`Fill number filter "${name}" with condition: "${condition}", first: "${value}" and second value: "${secondValue}"`, async () => {
			await this.filterNumber.selectCondition(name, condition);
			await this.filterNumber.fillValue(name, value!);
			secondValue && (await this.filterNumber.fillSecondValue(name, secondValue));
		});
	}

	public async fillSelectTreeFilter(name: string, values: string[]) {
		await test.step(`Fill select tree filter "${name}" with values: "${JSON.stringify(values)}"`, async () => {
			if (values.length == 0) {
				await this.filterSelectTree.clickUnselectAllButton(name);
			} else if (values.includes('All')) {
				await this.filterSelectTree.clickSelectAllButton(name);
			} else {
				await this.filterSelectTree.clickUnselectAllButton(name);
				for (const value of values) {
					await this.filterSelectTree.fillSearchInput(name, value);
					await this.filterBase.waitForTimeout(1000);
					await this.filterSelectTree.clickTreeItemCheck(name, value);
				}
			}
		});
	}

	public async fillDateRangeCustomPeriodFilter(from: string, to: string) {
		await test.step(`Fill date range custom period filter from "${from}" to "${to}"`, async () => {
			await this.filterDateRange.clickOnInput('from');
			await this.filterDateRange.fillInput('from', this.formatDate(from));
			await this.filterDateRange.fillInput('to', this.formatDate(to));
			await this.filterBase.waitForTimeout(500);
		});
	}

	public async fillDateRangePeriodFilter(value: string) {
		await test.step(`Fill date range period filter with value: "${value}"`, async () => {
			await this.filterBase.waitForTimeout(500);
			await this.filterDateRange.clickOnTimePeriod(value);
		});
	}

	private formatDate(dateStr: string): string {
		const [month, day, year] = dateStr.split('/').map(Number);
		if (!month || !day || !year) {
			throw new Error(`Invalid date string: "${dateStr}". Expected format: "MM/DD/YYYY"`);
		}
		const formattedMonth = month.toString().padStart(2, '0');
		const formattedDay = day.toString().padStart(2, '0');
		return `${formattedMonth}/${formattedDay}/${year}`;
	}
}
