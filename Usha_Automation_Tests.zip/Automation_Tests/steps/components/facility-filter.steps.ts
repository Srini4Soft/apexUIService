import { test } from 'src/common/fixtures/test-fixture.js';
import { FacilityFilterComponent } from 'src/pages/components/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class FacilityFilterSteps extends BaseSteps {
	private comFacilityFilter: FacilityFilterComponent;

	constructor() {
		super();
		this.comFacilityFilter = new FacilityFilterComponent();
	}

	public async selectFirstPortfolio() {
		await test.step('Select first portfolio in facility filter', async () => {
			await this.comFacilityFilter.clickFacilityFilterBtn();
			await this.comFacilityFilter.clickUnselectAllBtn();
			await this.comFacilityFilter.clickSelectFirstPortfolioCheck();
			await this.comFacilityFilter.clickApplyFilterBtn();
			await this.waitForPageLoad();
		});
	}

	public async selectAllPortfolios() {
		await test.step('Select all portfolios in facility filter', async () => {
			await this.comFacilityFilter.clickFacilityFilterBtn();
			await this.comFacilityFilter.clearSearchInput();
			await this.comFacilityFilter.clickSelectAllBtn();
			await this.comFacilityFilter.clickApplyFilterBtn();
			await this.waitForPageLoad();
		});
	}

	public async selectPortfolioByName(portfolio: string) {
		await test.step(`Select "${portfolio}" portfolio in facility filter`, async () => {
			await this.comFacilityFilter.clickFacilityFilterBtn();
			await this.comFacilityFilter.clickUnselectAllBtn();
			await this.comFacilityFilter.setSearchStringValue(portfolio);
			await this.comFacilityFilter.clickSelectFirstPortfolioCheck();
			await this.comFacilityFilter.clickApplyFilterBtn();
			await this.waitForPageLoad();
		});
	}

	public async selectPortfolioByExactName(portfolio: string) {
		await test.step(`Select "${portfolio}" portfolio in facility filter`, async () => {
			await this.comFacilityFilter.clickFacilityFilterBtn();
			await this.comFacilityFilter.clickUnselectAllBtn();
			await this.comFacilityFilter.setSearchStringValue(portfolio);
			await this.comFacilityFilter.clickSelectPortfolioByNameCheck(portfolio);
			await this.comFacilityFilter.clickApplyFilterBtn();
			await this.waitForPageLoad();
		});
	}

	public async selectMultiplePortfolios(portfolios: string[]) {
		await test.step(`Select "${JSON.stringify(portfolios)}" portfolios in facility filter`, async () => {
			await this.comFacilityFilter.clickFacilityFilterBtn();
			await this.comFacilityFilter.clearSearchInput();
			await this.comFacilityFilter.clickUnselectAllBtn();
			for (const portfolio of portfolios) {
				await this.comFacilityFilter.setSearchStringValue(portfolio);
				await this.comFacilityFilter.clickSelectFirstPortfolioCheck();
				await this.comFacilityFilter.clearSearchInput();
			}
			await this.comFacilityFilter.clickApplyFilterBtn();
			await this.waitForPageLoad();
		});
	}
}
