import {
	IAddCaseNoteAction,
	IAddCasePayerAction,
	IAddCaseTagAction,
	IAddMedicaidApplicationAction,
	ICaseTrackingStatusTypeAction,
	ICompleteTaskAction,
	ICondition,
	ICreateTaskAction,
	ICreateWorkflowInstanceAction,
	IRemoveCasePayerAction,
	IRemoveCaseTagAction,
	IRequiredAction,
	ISetValueAutomationAction,
	ISetValueValidationAction,
	IWarningAction,
} from 'src/common/models/index.js';
import {
	AddCaseNoteAction,
	AddCasePayerAction,
	AddCaseTagAction,
	AddMedicaidApplicationAction,
	ChangeCaseTrackingStatusAction,
	CompleteTaskAction,
	CreateTaskAction,
	CreateWorkflowInstanceAction,
	RemoveCasePayerAction,
	RemoveCaseTagAction,
	RequiredAction,
	SelectRuleActionPage,
	SetValueAction,
	SetValueValidationAction,
	WarningAction,
} from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';
import { CustomFilterSteps } from './custom-filter.steps.js';

export class RuleActionsSteps extends BaseSteps {
	private stepsCustomFilter: CustomFilterSteps;
	private pageSelectRuleAction: SelectRuleActionPage;
	private pageAddCaseNoteAction: AddCaseNoteAction;
	private pageAddCasePayerAction: AddCasePayerAction;
	private pageAddCaseTagAction: AddCaseTagAction;
	private pageAddMedicaidApplicationAction: AddMedicaidApplicationAction;
	private pageChangeCaseTrackingStatusAction: ChangeCaseTrackingStatusAction;
	private pageCreateTaskAction: CreateTaskAction;
	private pageCreateWorkflowInstanceAction: CreateWorkflowInstanceAction;
	private pageCompleteTaskAction: CompleteTaskAction;
	private pageRemoveCasePayerAction: RemoveCasePayerAction;
	private pageRemoveCaseTagAction: RemoveCaseTagAction;
	private pageSetValueAction: SetValueAction;
	private pageSetValueValidationAction: SetValueValidationAction;
	private pageRequiredAction: RequiredAction;
	private pageWarningAction: WarningAction;

	constructor() {
		super();
		this.stepsCustomFilter = new CustomFilterSteps();
		this.pageSelectRuleAction = new SelectRuleActionPage();
		this.pageAddCaseNoteAction = new AddCaseNoteAction();
		this.pageAddCasePayerAction = new AddCasePayerAction();
		this.pageAddCaseTagAction = new AddCaseTagAction();
		this.pageAddMedicaidApplicationAction = new AddMedicaidApplicationAction();
		this.pageChangeCaseTrackingStatusAction = new ChangeCaseTrackingStatusAction();
		this.pageCreateTaskAction = new CreateTaskAction();
		this.pageCreateWorkflowInstanceAction = new CreateWorkflowInstanceAction();
		this.pageCompleteTaskAction = new CompleteTaskAction();
		this.pageRemoveCasePayerAction = new RemoveCasePayerAction();
		this.pageRemoveCaseTagAction = new RemoveCaseTagAction();
		this.pageSetValueAction = new SetValueAction();
		this.pageSetValueValidationAction = new SetValueValidationAction();
		this.pageRequiredAction = new RequiredAction();
		this.pageWarningAction = new WarningAction();
	}

	public async editActionCondition(condition: ICondition): Promise<void> {
		const locator = '//button//span[contains(text(),"Add Condition")]';
		await this.pageSelectRuleAction.clickOn(locator);
		await this.stepsCustomFilter.addConditionInput(
			condition.propertyName!,
			condition.comparisonPredicate!,
			condition.comparisonValue!
		);
		await this.stepsCustomFilter.apply();
		await this.pageCreateTaskAction.clickAddButton();
	}

	public async getActionCondition(): Promise<ICondition> {
		const locator = '//button//span[contains(text(),"Edit condition")]';
		await this.pageSelectRuleAction.clickOn(locator);
		return await this.stepsCustomFilter.getConditionData();
	}

	public async selectActionType(value: string): Promise<void> {
		await this.pageSelectRuleAction.selectAction(value);
	}

	public async addCaseNoteAction(data: IAddCaseNoteAction): Promise<void> {
		if (data.message) {
			await this.pageAddCaseNoteAction.fillMessageField(data.message);
		}

		if (data.isAggregateMessage) {
			await this.pageAddCaseNoteAction.setIsAggregateMessageCheckbox(data.isAggregateMessage);
		}

		await this.pageAddCaseNoteAction.clickAddButton();
	}

	public async addCasePayerAction(data: IAddCasePayerAction): Promise<void> {
		if (data.allowMultipleExecution) {
			await this.pageAddCasePayerAction.setAllowMultipleExecutionCheckbox(data.allowMultipleExecution);
		}

		if (data.payerRole) {
			await this.pageAddCasePayerAction.fillPayerRoleField(data.payerRole);
		}

		if (data.payerCategory) {
			await this.pageAddCasePayerAction.fillPayerCategoryField(data.payerCategory);
		}

		if (data.effectiveDateInput) {
			await this.pageAddCasePayerAction.fillEffectiveDateInputField(data.effectiveDateInput);
		}

		if (data.effectiveDateDropDown) {
			await this.pageAddCasePayerAction.fillEffectiveDateDropdownField(data.effectiveDateDropDown);
		}

		if (data.effectiveDateProperty) {
			await this.pageAddCasePayerAction.fillEffectiveDatePropertyField(data.effectiveDateProperty);
		}

		await this.pageAddCasePayerAction.clickAddButton();
	}

	public async addAddCaseTagAction(data: IAddCaseTagAction): Promise<void> {
		if (data.scope) {
			await this.pageAddCaseTagAction.fillScopeField(data.scope);
		}

		if (data.lookupId) {
			await this.pageAddCaseTagAction.fillTagField(data.lookupId);
		}

		await this.pageAddCaseTagAction.clickAddButton();
	}

	public async addMedicaidApplicationAction(data: IAddMedicaidApplicationAction): Promise<void> {
		await this.pageAddMedicaidApplicationAction.clickAddButton();
	}

	public async changeCaseTrackingStatusAction(data: ICaseTrackingStatusTypeAction): Promise<void> {
		if (data.caseTrackingStatusType) {
			await this.pageChangeCaseTrackingStatusAction.fillTrackingStatus(data.caseTrackingStatusType);
		}

		await this.pageChangeCaseTrackingStatusAction.clickAddButton();
	}

	public async createTaskAction(data: ICreateTaskAction): Promise<void> {
		if (data.title) {
			await this.pageCreateTaskAction.fillTitleField(data.title);
		}

		if (data.lookupTaskCategoryId) {
			await this.pageCreateTaskAction.fillCategoryField(data.lookupTaskCategoryId);
		}

		await this.pageCreateTaskAction.clickAddButton();
	}

	public async createWorkflowInstanceAction(data: ICreateWorkflowInstanceAction): Promise<void> {
		if (data.workflowDefinitionId) {
			await this.pageCreateWorkflowInstanceAction.fillWorkflowDefinitionField(data.workflowDefinitionId);
		}

		await this.pageCreateWorkflowInstanceAction.clickAddButton();
	}

	public async completeTaskAction(data: ICompleteTaskAction): Promise<void> {
		if (data.scope) {
			await this.pageCompleteTaskAction.fillScopeField(data.scope);
		}

		if (data.targetValuePath) {
			await this.pageCompleteTaskAction.fillRelatedEntity(data.targetValuePath);
		}

		await this.pageCompleteTaskAction.clickAddButton();
	}

	public async removeCasePayerAction(data: IRemoveCasePayerAction): Promise<void> {
		if (data.payerPeriod) {
			await this.pageRemoveCasePayerAction.fillPrimaryPayer(data.payerPeriod);
		}

		if (data.payerCategory) {
			await this.pageRemoveCasePayerAction.fillPayerCategory(data.payerCategory);
		}

		await this.pageRemoveCasePayerAction.clickAddButton();
	}

	public async removeCaseTagAction(data: IRemoveCaseTagAction): Promise<void> {
		if (data.scope) {
			await this.pageRemoveCaseTagAction.fillScope(data.scope);
		}

		if (data.lookupId) {
			await this.pageRemoveCaseTagAction.fillTag(data.lookupId);
		}

		await this.pageRemoveCaseTagAction.clickAddButton();
	}

	public async setValueAutomationAction(data: ISetValueAutomationAction): Promise<void> {
		if (data.targetValuePath) {
			await this.pageSetValueAction.fillTargetField(data.targetValuePath);
		}

		if (data.valueSourceType) {
			await this.pageSetValueAction.fillSourceType(data.valueSourceType);
		}

		if (data.dateOperator) {
			await this.pageSetValueAction.fillDateOperator(data.dateOperator);
		}

		if (data.value) {
			await this.pageSetValueAction.fillDateValue(data.value);
		}

		await this.pageCreateWorkflowInstanceAction.clickAddButton();
	}

	public async setValueValidationAction(data: ISetValueValidationAction): Promise<void> {
		if (data.type) {
			await this.pageSetValueValidationAction.fillFieldType(data.type);
		}

		if (data.valueSourceType) {
			await this.pageSetValueValidationAction.fillSourceType(data.valueSourceType);
		}

		if (data.dateOperator) {
			await this.pageSetValueValidationAction.fillDateOperator(data.dateOperator);
		}

		if (data.value) {
			await this.pageSetValueValidationAction.fillDateValue(data.value);
		}

		await this.pageCreateWorkflowInstanceAction.clickAddButton();
	}

	public async requiredAction(data: IRequiredAction): Promise<void> {
		if (data.message) {
			await this.pageRequiredAction.fillRequiredMessage(data.message);
		}

		await this.pageRequiredAction.clickAddButton();
	}

	public async warningAction(data: IWarningAction): Promise<void> {
		if (data.message) {
			await this.pageWarningAction.fillWarningMessage(data.message);
		}

		await this.pageWarningAction.clickAddButton();
	}
}
