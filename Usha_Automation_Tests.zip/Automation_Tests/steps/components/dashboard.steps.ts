import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { DashboardComponent } from 'src/pages/components/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class DashboardSteps extends BaseSteps {
	private comDashboard: DashboardComponent;

	constructor() {
		super();
		this.comDashboard = new DashboardComponent();
	}

	/* ACTIONS */
	public async selectDashboardByName(dashboard: string) {
		await this.comDashboard.selectDashboardByName(dashboard);
		await this.waitForPageLoad();
	}

	public async selectDashboardByPositionNumber(position: number = 1) {
		await this.comDashboard.selectDashboardByPositionNumber(position);
		await this.waitForPageLoad();
	}

	/**	ASSERTIONS	*/
	public async verifyDashboardSettingsButtonIsVisible() {
		expect(await this.comDashboard.isSettingsButtonVisible(), ErrorMessages.NO_BUTTON('Dashboard Settings')).toBe(true);
	}

	/** MVC ACTIONS */
	public async selectDashboardByNameMvc(dashboard: string) {
		await this.comDashboard.selectDashboardByName(dashboard);
		await this.waitForPageLoad();
	}

	public async selectDashboardByPositionNumberMvc(position: number = 1) {
		await this.comDashboard.selectDashboardByPositionNumberMvc(position);
		await this.waitForPageLoad();
	}

	/**	MVC ASSERTIONS	*/
	public async verifyDashboardSettingsButtonIsVisibleMvc() {
		expect(await this.comDashboard.isSettingsButtonVisibleMvc(), ErrorMessages.NO_BUTTON('Settings')).toBe(true);
	}
}
