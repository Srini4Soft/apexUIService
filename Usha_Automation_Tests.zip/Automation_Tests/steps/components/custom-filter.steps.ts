import { test } from 'src/common/fixtures/test-fixture.js';
import { ICondition } from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { GridCustomFilterComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class CustomFilterSteps extends BaseSteps {
	private comCustomFilter: GridCustomFilterComponent;

	constructor() {
		super();
		this.comCustomFilter = new GridCustomFilterComponent();
	}

	public async getExpression(): Promise<string> {
		let expression: string = '';
		await test.step('Get expression from custom filter', async () => {
			await this.comCustomFilter.clickShowExpressionButton();
			expression = await this.comCustomFilter.getExpressionValue();
			log.info(`Custom filter expression value: ${expression}`);
		});

		return expression;
	}

	public async setExpression(expression: string) {
		await test.step(`Set custom filter expression: "${expression}"`, async () => {
			log.info(`Custom filter expression for filter: ${expression}`);
			await this.comCustomFilter.clickShowExpressionButton();
			await this.comCustomFilter.fillExpressionValue(expression);
			await this.comCustomFilter.clickApplyExpressionButton();
		});
	}

	public async apply() {
		await test.step('Apply custom filter', async () => {
			await this.comCustomFilter.clickApplyButton();
			await this.comCustomFilter.waitForPageLoad();
		});
	}

	public async close() {
		await test.step('Close custom filter', async () => {
			await this.comCustomFilter.clickCloseButton();
		});
	}

	public async addConditionSelect(columnName: string[], condition: string, filterValue: string) {
		await test.step(`Add custom filter condition for column "${columnName}". Add condition "${condition}" and select value "${filterValue}"`, async () => {
			await this.comCustomFilter.clickAddConditionButton();
			await this.selectFilteredColumn(columnName);
			await this.selectCondition(condition);
			await this.comCustomFilter.clickFilterValueSelect();
			await this.comCustomFilter.selectDropdownValue(filterValue);
			await this.apply();
		});
	}

	public async addConditionInput(columnName: string[], condition: string, filterValue: string) {
		await test.step(`Add custom filter condition for column "${columnName}". Add condition "${condition}" and input value "${filterValue}"`, async () => {
			await this.comCustomFilter.clickAddConditionButton();
			await this.selectFilteredColumn(columnName);
			await this.selectCondition(condition);
			await this.comCustomFilter.fillFilterValueInput(filterValue);
		});
	}

	public async getConditionData(): Promise<ICondition> {
		let condition: ICondition = {};
		condition.comparisonValue = await this.comCustomFilter.getFilterValue();
		return condition;
	}

	private async selectFilteredColumn(path: string[]) {
		await test.step('Select filtered column', async () => {
			await this.comCustomFilter.clickColumnTitleSelect();

			for (const part of path) {
				let elementFound = false;

				while (!elementFound) {
					const elements = await this.comCustomFilter.getVisibleTreeElements();

					for (const element of elements) {
						const textContent = await element.textContent();
						if (textContent?.trim() === part) {
							elementFound = true;
							if (path[path.length - 1] === part) {
								await this.comCustomFilter.clickColumnFilterItem(part);
							} else {
								let viewBox = await element.locator('//*[name()="svg"]').getAttribute('viewBox');
								if (viewBox?.includes('320')) {
									await this.comCustomFilter.clickExpandItemIcon(part);
								}
							}

							break;
						}
					}

					if (!elementFound) {
						const lastElement = elements[elements.length - 1];
						if (lastElement) {
							await lastElement.scrollIntoViewIfNeeded();
							await this.comCustomFilter.waitForTimeout(500);
						} else {
							throw new Error(`Element "${part}" not found in the tree`);
						}
					}
				}
			}
		});
	}

	private async selectCondition(condition: string) {
		await test.step('Select custom filter condition', async () => {
			await this.comCustomFilter.clickConditionSelect();
			await this.comCustomFilter.selectDropdownValue(condition);
		});
	}
}
