import { test } from '@playwright/test';
import { ConditionComparisonComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class ConditionComparisonSteps extends BaseSteps {
	private comConditionComparison: ConditionComparisonComponent;

	constructor() {
		super();
		this.comConditionComparison = new ConditionComparisonComponent();
	}

	public getWindowLocator() {
		return this.comConditionComparison.getWindowLocator();
	}

	public async compareListConditions(firstView: string, secondView: string) {
		await test.step(`Compare view "${firstView} with "${secondView}"`, async () => {
			await this.comConditionComparison.keyboardType(firstView);
			await this.comConditionComparison.selectDropdownValue(firstView);
			await this.comConditionComparison.clickSecondLinkSelector();
			await this.comConditionComparison.keyboardType(secondView);
			await this.comConditionComparison.selectDropdownValue(secondView);
			await this.comConditionComparison.clickCompareButton();
			await this.waitForPageLoad();
		});
	}

	public async openAllCasesChangesTab() {
		await test.step('Open "All Cases Changes" tab', async () => {
			await this.comConditionComparison.clickAllCasesChangeButton();
			await this.waitForPageLoad();
		});
	}

	public async openAddedCasesTab() {
		await test.step('Open "Added Cases" tab', async () => {
			await this.comConditionComparison.clickAddedCasesButton();
			await this.waitForPageLoad();
		});
	}

	public async openRemovedCasesTab() {
		await test.step('Open "Removed Cases" tab', async () => {
			await this.comConditionComparison.clickRemovedCasesButton();
			await this.waitForPageLoad();
		});
	}

	public async getAllCasesChangesBadgeText(): Promise<number> {
		let number = 0;
		await test.step('Get number of records from badge on the "All Cases Change" tab', async () => {
			number = Number(await this.comConditionComparison.getAllCasesChangeBadgeText());
		});
		return number;
	}

	public async getAddedCasesBadgeText() {
		let number = 0;
		await test.step('Get number of records from badge on the "Added Cases" tab', async () => {
			number = Number(await this.comConditionComparison.getAddedCasesBadgeText());
		});
		return number;
	}

	public async getRemovedCasesBadgeText() {
		let number = 0;
		await test.step('Get number of records from badge on the "Removed Cases" tab', async () => {
			number = Number(await this.comConditionComparison.getRemovedCasesBadgeText());
		});
		return number;
	}
}
