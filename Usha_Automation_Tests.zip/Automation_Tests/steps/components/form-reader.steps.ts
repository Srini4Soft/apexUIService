import { Locator } from '@playwright/test';
import log from 'src/common/utils/logger.js';
import { FormComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

enum Tag {
	INPUT = 'amp-input',
	SELECT = 'amp-select',
	SELECT_TREE = 'amp-select-tree',
	CHECKBOX = 'amp-checkbox',
}

export class FormReaderSteps extends BaseSteps {
	private comForm: FormComponent;

	constructor() {
		super();
		this.comForm = new FormComponent();
	}

	public async getFormData(): Promise<Record<string, unknown>> {
		const INPUT_PART = '//input[@id]';
		const TEXTAREA_PART = '//textarea[@id]';
		const SELECT_PART = '//ng-select//span[contains(@class,"amp-select__option") or contains(@class,"ng-value-label")]';
		const SELECT_BADGE_PART = '//ng-select//amp-badge//span[contains(@class,"amp-badge__title")]';
		const SELECT_CUSTOM_TMP_PART = '//ng-select//amp-custom-option-template//span/span';
		const PAYER_OPTIONS_TMP_PART = '//ng-select//amp-payer-option-template//div';
		const CHECKBOX_PART = 'label';
		const result: Record<string, unknown> = {};
		const formFields: Locator[] = await this.comForm.getListOfFields();

		for (const field of formFields) {
			const formControlName = await field.getAttribute('formcontrolname');
			const isHidden = await this.isElementHidden(field);
			if (isHidden) {
				log.info(`Skip hidden field "${formControlName}"`);
				continue;
			}

			/** Fix //*[@formcontrolname='thirtyDayExempted'] checkbox on veripay/cases/details form.
			 * Element doesn't have 'amp-checkbox--selected' class and isn't displayed */
			if (formControlName == 'thirtyDayExempted') {
				continue;
			}

			if (formControlName) {
				let value: unknown;
				const tagName = await field.evaluate((el) => el.tagName.toLowerCase());
				switch (tagName) {
					case Tag.INPUT:
						if ((await field.locator(INPUT_PART).count()) > 0) {
							value = (await field.locator(INPUT_PART).inputValue()).trim();
						} else {
							value = (await field.locator(TEXTAREA_PART).inputValue()).trim();
						}

						break;

					case Tag.SELECT:
						const hasBadge = (await field.locator('amp-badge').count()) > 0;
						const hasCustomTemplate = (await field.locator('amp-custom-option-template').count()) > 0;
						const hasPayerOptionsTemplate = (await field.locator('amp-payer-option-template').count()) > 0;
						const selectedOptionLocator = field.locator(
							hasBadge
								? SELECT_BADGE_PART
								: hasCustomTemplate
								? SELECT_CUSTOM_TMP_PART
								: hasPayerOptionsTemplate
								? PAYER_OPTIONS_TMP_PART
								: SELECT_PART
						);
						if ((await selectedOptionLocator.count()) > 0) {
							const selectedOption = selectedOptionLocator.first();
							value = (await selectedOption.textContent())?.toString().trim();
						} else {
							value = '';
						}

						break;

					case Tag.CHECKBOX:
						const isChecked = await field
							.locator(CHECKBOX_PART)
							.evaluate((el) => el.classList.contains('amp-checkbox--selected'));
						value = isChecked;
						break;
				}

				log.info(`Got field: "${formControlName}", <${tagName}>, value: "${value}"`);
				result[formControlName] = value;
			}
		}

		return result;
	}

	public async isFieldInteractive(fieldName: string): Promise<boolean> {
		let isDisabled: boolean = false;
		const field: Locator = this.comForm.getField(fieldName);
		if ((await field.count()) === 0) {
			return false;
		}

		if ((await field.isVisible()) === false) {
			return false;
		}

		const tagName = await field.evaluate((el) => el.tagName.toLowerCase());
		const disabledClass = this.getDisabledClassForTag(tagName);
		if (disabledClass) {
			let classCheckLocator: Locator;
			switch (tagName) {
				case Tag.INPUT:
				case Tag.SELECT:
				case Tag.SELECT_TREE:
					classCheckLocator = field.locator('//ancestor::' + tagName + '/div');
					break;

				case Tag.CHECKBOX:
					classCheckLocator = field.locator('//ancestor::' + tagName + '/label');
					break;

				default:
					classCheckLocator = field;
					break;
			}

			isDisabled = await classCheckLocator.evaluate(
				(el, disabledClass) => el.classList.contains(disabledClass),
				disabledClass
			);
		}

		return !isDisabled;
	}

	private async isElementHidden(field: Locator): Promise<boolean> {
		return await field.evaluate((el) => {
			// Check if the element itself has the class
			if (el.classList.contains('amp-form-control--hidden')) {
				return true;
			}
			// Check if any ancestor has the class
			let parent = el.parentElement;
			while (parent) {
				if (parent.classList.contains('amp-form-control--hidden')) {
					return true;
				}
				parent = parent.parentElement;
			}
			return false;
		});
	}

	private getDisabledClassForTag(tagName: string): string | null {
		switch (tagName) {
			case Tag.INPUT:
				return 'amp-input--disabled';
			case Tag.SELECT:
				return 'amp-select--disabled';
			case Tag.SELECT_TREE:
				return 'amp-select-tree--disabled';
			case Tag.CHECKBOX:
				return 'amp-checkbox--disabled';
			default:
				return null;
		}
	}
}
