import { RuleActions, ValidationRuleActions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import {
	IAddCaseNoteAction,
	IAddCasePayerAction,
	IAddCaseTagAction,
	IAddMedicaidApplicationAction,
	IAutomationRule,
	ICaseTrackingStatusTypeAction,
	ICompleteTaskAction,
	ICondition,
	ICreateTaskAction,
	ICreateWorkflowInstanceAction,
	IRemoveCasePayerAction,
	IRemoveCaseTagAction,
	IRequiredAction,
	ISetValueAutomationAction,
	ISetValueValidationAction,
	IWarningAction,
} from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { AutomationRulePage } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';
import { CustomFilterSteps, RuleActionsSteps } from '../index.js';

export class AutomationRuleSteps extends BaseSteps {
	private pageManageRule: AutomationRulePage;
	private stepsCustomFilter: CustomFilterSteps;
	private stepsRuleActionsSteps: RuleActionsSteps;

	constructor() {
		super();
		this.pageManageRule = new AutomationRulePage();
		this.stepsCustomFilter = new CustomFilterSteps();
		this.stepsRuleActionsSteps = new RuleActionsSteps();
	}

	public async fillCreateRuleForm(data: IAutomationRule) {
		await test.step('Fill and apply "Create New Rule" form', async () => {
			log.info(`Create rule with following data: ${JSON.stringify(data)}`);
			if (data.name) {
				await this.pageManageRule.fillNameInput(data.name);
			}

			if (data.targetProperties) {
				await this.pageManageRule.fillTargetProperties(data.targetProperties);
			}

			if (data.isEnabled) {
				await this.pageManageRule.setIsEnabledCheckbox(data.isEnabled);
			}

			if (data.isGlobal) {
				await this.pageManageRule.setIsGlobalCheckbox(data.isGlobal);
			}

			if (data.condition) {
				await this.stepsCustomFilter.addConditionInput(
					data.condition.propertyName!,
					data.condition.comparisonPredicate!,
					data.condition.comparisonValue!
				);
			}
		});
	}

	public async getRuleId(): Promise<string> {
		return await this.pageManageRule.getRuleId();
	}

	public async clickCreateButton(): Promise<void> {
		await this.pageManageRule.clickCreateButton();
		await this.waitForPageLoad();
	}

	public async clickSaveButton(): Promise<void> {
		await this.pageManageRule.clickSaveButton();
		await this.waitForPageLoad();
	}

	public async addActionOnSuccess(): Promise<void> {
		await this.pageManageRule.clickAddActionOnSuccessButton();
		await this.waitForPageLoad();
	}

	public async deleteActionOnSuccess(): Promise<void> {
		await this.pageManageRule.clickDeleteActionOnSuccessButton();
	}

	public async editActionCondition(condition: ICondition): Promise<void> {
		await this.stepsRuleActionsSteps.editActionCondition(condition);
		await this.waitForPageLoad();
	}

	public async getActionCondition(): Promise<ICondition> {
		return await this.stepsRuleActionsSteps.getActionCondition();
	}

	public async actionAddCaseNote(data: IAddCaseNoteAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.ADD_CASE_NOTE);
		await this.stepsRuleActionsSteps.addCaseNoteAction(data);
		await this.waitForPageLoad();
	}

	public async actionAddCasePayer(data: IAddCasePayerAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.ADD_CASE_PAYER);
		await this.stepsRuleActionsSteps.addCasePayerAction(data);
		await this.waitForPageLoad();
	}

	public async actionAddCaseTag(data: IAddCaseTagAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.ADD_CASE_TAG);
		await this.stepsRuleActionsSteps.addAddCaseTagAction(data);
		await this.waitForPageLoad();
	}

	public async actionAddMedicaidApplication(data: IAddMedicaidApplicationAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.ADD_MEDICAID_APPLICATION);
		await this.stepsRuleActionsSteps.addMedicaidApplicationAction(data);
		await this.waitForPageLoad();
	}

	public async actionChangeCaseTrackingStatus(data: ICaseTrackingStatusTypeAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.CHANGE_CASE_TRACKING_STATUS);
		await this.stepsRuleActionsSteps.changeCaseTrackingStatusAction(data);
		await this.waitForPageLoad();
	}

	public async actionCreateTask(data: ICreateTaskAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.CREATE_TASK);
		await this.stepsRuleActionsSteps.createTaskAction(data);
		await this.waitForPageLoad();
	}

	public async actionCompleteTask(data: ICompleteTaskAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.COMPLETE_TASK);
		await this.stepsRuleActionsSteps.completeTaskAction(data);
		await this.waitForPageLoad();
	}

	public async actionCreateWorkflowInstance(data: ICreateWorkflowInstanceAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.CREATE_WORKFLOW_INSTANCE);
		await this.stepsRuleActionsSteps.createWorkflowInstanceAction(data);
		await this.waitForPageLoad();
	}

	public async actionRemoveCasePayer(data: IRemoveCasePayerAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.REMOVE_CASE_PAYER);
		await this.stepsRuleActionsSteps.removeCasePayerAction(data);
		await this.waitForPageLoad();
	}

	public async actionRemoveCaseTag(data: IRemoveCaseTagAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.REMOVE_CASE_TAG);
		await this.stepsRuleActionsSteps.removeCaseTagAction(data);
		await this.waitForPageLoad();
	}

	public async actionSetValueAutomation(data: ISetValueAutomationAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(RuleActions.SET_VALUE_AUTO);
		await this.stepsRuleActionsSteps.setValueAutomationAction(data);
		await this.waitForPageLoad();
	}

	public async actionSetValueValidation(data: ISetValueValidationAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.SET_VALUE);
		await this.stepsRuleActionsSteps.setValueValidationAction(data);
		await this.waitForPageLoad();
	}

	public async actionRequired(data: IRequiredAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.REQUIRED);
		await this.stepsRuleActionsSteps.requiredAction(data);
		await this.waitForPageLoad();
	}

	public async actionNotRequired(): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.NOT_REQUIRED);
		await this.waitForPageLoad();
	}

	public async actionHidden(): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.HIDDEN);
		await this.waitForPageLoad();
	}

	public async actionReadonly(): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.READONLY);
		await this.waitForPageLoad();
	}

	public async actionWarning(data: IWarningAction): Promise<void> {
		await this.stepsRuleActionsSteps.selectActionType(ValidationRuleActions.WARNING);
		await this.stepsRuleActionsSteps.warningAction(data);
		await this.waitForPageLoad();
	}
}
