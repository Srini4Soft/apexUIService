import { ShareLinkComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class ShareLinkSteps extends BaseSteps {
	private comShareLink: ShareLinkComponent;

	constructor() {
		super();
		this.comShareLink = new ShareLinkComponent();
	}

	public async getShortLink(): Promise<string> {
		await this.comShareLink.clickShortLinkButton();
		const link = await this.comShareLink.getShortLink();
		await this.comShareLink.closeShareWindow();
		return link;
	}
}
