import { test } from '@playwright/test';
import { ProfileMenuComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class ProfileMenuSteps extends BaseSteps {
	private comProfileMenu: ProfileMenuComponent;

	constructor() {
		super();
		this.comProfileMenu = new ProfileMenuComponent();
	}

	public async openProfileMenu() {
		await test.step('Open user profile menu', async () => {
			await this.comProfileMenu.clickOpenProfileMenuButton();
		});
	}

	public async viewAllLinks() {
		await test.step('Open "My Links" page', async () => {
			await this.openProfileMenu();
			await this.comProfileMenu.clickMyLinksMenuItem();
			await this.comProfileMenu.clickViewAllLinksMenuItem();
			await this.waitForPageLoad();
		});
	}
}
