import { expect, Locator, test } from '@playwright/test';
import { ErrorMessages, SortingOrder } from 'src/common/enums/index.js';
import log from 'src/common/utils/logger.js';
import {
	GridMenuColumnsComponent,
	GridMenuComponent,
	GridPagerComponent,
	GridSaveViewComponent,
	GridTableComponent,
	GridToolbarComponent,
	ToasterComponent,
} from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class GridSteps extends BaseSteps {
	private comGridMenuColumns: GridMenuColumnsComponent;
	private comGridMenu: GridMenuComponent;
	private comGridPager: GridPagerComponent;
	private comGridSaveView: GridSaveViewComponent;
	private comGridTable: GridTableComponent;
	private comGridToolbar: GridToolbarComponent;
	private comToaster: ToasterComponent;

	constructor() {
		super();
		this.comGridMenuColumns = new GridMenuColumnsComponent();
		this.comGridMenu = new GridMenuComponent();
		this.comGridPager = new GridPagerComponent();
		this.comGridSaveView = new GridSaveViewComponent();
		this.comGridTable = new GridTableComponent();
		this.comGridToolbar = new GridToolbarComponent();
		this.comToaster = new ToasterComponent();
	}

	// MENU STEPS
	public async exportToCSV(): Promise<void> {
		await test.step('Export grid to CSV', async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickExportToCSVButton();
			await this.waitForPageLoad();
		});
	}

	public async resetView(): Promise<void> {
		await test.step('Reset grid view', async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickResetViewButton();
			await this.waitForPageLoad();
		});
	}

	public async printView(): Promise<void> {
		await test.step('Print view', async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickPrintViewButton();
		});
	}

	public async saveView(name: string): Promise<void> {
		await test.step(`Save grid view with name "${name}"`, async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickSaveViewButton();
			await this.comGridSaveView.fillLinkNameInput(name);
			await this.comGridSaveView.clickSaveButton();
			await this.waitForPageLoad();
			await this.comToaster.close();
		});
	}

	public async applyView(name: string): Promise<void> {
		await test.step(`Apply grid view with name "${name}"`, async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.fillViewSearchInput(name);
			await this.comGridMenu.clickViewByName(name);
			await expect(this.comGridToolbar.getGridTitleLocator()).toHaveText(name, { timeout: 5000 });
			await this.waitForPageLoad();
		});
	}

	public async updateView(oldName: string, newName: string): Promise<void> {
		await test.step(`Update grid view link name from "${oldName}" to "${newName}"`, async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickUpdateViewButton();
			await this.comGridMenu.updateViewLink(oldName, newName);
			await this.waitForPageLoad();
		});
	}

	public async openCompareListConditions(): Promise<void> {
		await test.step('Open compare list conditions form', async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickCompareListConditionsButton();
		});
	}

	public async openGridMenu(): Promise<void> {
		await test.step('Open grid menu', async () => {
			await this.comGridToolbar.clickMenuButton();
		});
	}

	public async clickDynamicGridMenuItem(name: string): Promise<void> {
		await test.step(`Click on the grid menu item "${name}"`, async () => {
			await this.comGridMenu.clickDynamicMenuItem(name);
			await this.waitForPageLoad();
		});
	}

	// MENU COLUMNS SETTINGS

	public async openCustomFilter(): Promise<void> {
		await test.step('Open custom filter', async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickCustomFilterButton();
		});
	}

	/**
	 * Selects the columns to display on the grid.
	 *
	 * This method accepts an array of column names to be displayed. If the array is empty,
	 * the method will disable all columns. If the array contains the element "All",
	 * the method will enable all columns. Otherwise, the method will enable only
	 * the columns specified in the array.
	 *
	 * @param {string[]} columns Array of column names to include.
	 *                             Can be empty to disable all columns or contain "All" to enable all columns.
	 *
	 * @returns {string[]} An array of column names that were selected.
	 */
	public async selectColumnsToDisplay(columns: string[]): Promise<string[]> {
		let columnNames: string[] = [];
		await test.step(`Select grid columns to display: ${JSON.stringify(columns)}`, async () => {
			await this.comGridToolbar.clickMenuButton();
			await this.comGridMenu.clickColumnsSettingsButton();
			if (columns.length == 0) {
				log.info('Unselect all columns. Columns array is empty');
				await this.comGridMenuColumns.clickUnselectAllCheckbox();
			} else if (columns.includes('All')) {
				log.info('Select all columns');
				await this.comGridMenuColumns.clickSelectAllCheckbox();
			} else {
				log.info(`Select specific columns: ${columns.toString()}`);
				await this.comGridMenuColumns.clickUnselectAllCheckbox();
				for (const column of columns) {
					await this.comGridMenuColumns.clickColumnCheckbox(column);
				}
			}

			columnNames = await this.comGridMenuColumns.getSelectedColumnsList();
			log.info(`Selected ${columnNames.length} columns to display. Columns: "${columnNames}"`);
			await this.comGridMenuColumns.clickApplyButton();
			await this.waitForPageLoad();
		});

		await this.waitForPageLoad();
		return columnNames;
	}

	// TOOLBAR STEPS

	/**
	 * Searches the table for rows that match the given query.
	 *
	 * @param {string} text Search substring.
	 *
	 * @returns {Promise<void>}
	 */
	public async search(text: string): Promise<void> {
		await test.step(`Search text in the table: ${text}`, async () => {
			log.info(`Search text in the table: ${text}`);
			await this.waitForPageLoad();
			await this.comGridToolbar.clickSearchButton();
			await this.comGridToolbar.fillSearchInput(text);
			await this.comGridToolbar.pressKeyboardButton('Enter');
			await this.waitForPageLoad();
		});
	}

	public async resetGridFilters(): Promise<void> {
		await test.step('Reset all grid filters', async () => {
			log.info('Reset grid filters');
			await this.comGridToolbar.clickResetFiltersButton();
			await this.waitForPageLoad();
		});
	}

	// TABLE STEPS

	/**
	 * Returns list of displayed column names in the table.
	 *
	 * @returns {string[]} List of displayed column names.
	 */
	public async getColumnNames(): Promise<string[]> {
		let columnNames: string[] = [];
		await test.step('Get list of displayed column names', async () => {
			log.info('Get list of displayed column names');
			columnNames = await this.comGridTable.getColumnNames();
			log.info(`Table has ${columnNames.length} displayed columns. Columns: ${columnNames}`);
		});

		return columnNames;
	}

	/**
	 * Returns a collection containing the values ​​of all cells in specific column.
	 *
	 * @param {string} column Column name.
	 *
	 * @returns {string[][]} An array of arrays of text node values ​​for each cell in the column.
	 */
	public async getColumnTextValues(column: string, index?: number): Promise<string[][]> {
		let cellValues: string[][] = [];
		await test.step(`Get cell text values from "${column}" column`, async () => {
			log.info(`Get the data from the column "${column}"`);
			cellValues = await this.comGridTable.getColumnTextValues(column, index);
			log.info(`Data received from column: "${column}". Cell values: "${JSON.stringify(cellValues)}"`);
		});

		return cellValues;
	}

	public async getTasksColumnIconValues(column: string): Promise<string[][][]> {
		let cellValues: string[][][] = [];
		await test.step('Get cell icon values from "Tasks" column', async () => {
			log.info(`Get the data about icons from the column "${column}"`);
			cellValues = await this.comGridTable.getTasksColumnIconValues(column);
			log.info(`Data received from column: "${column}". Cell values: "${JSON.stringify(cellValues)}"`);
		});

		return cellValues;
	}

	public async getColumnIconValues(column: string): Promise<string[][]> {
		let cellValues: string[][] = [];
		await test.step(`Get cell icon values from "${column}" column`, async () => {
			log.info(`Get the data about icons from the column "${column}"`);
			cellValues = await this.comGridTable.getColumnIconValues(column);
			log.info(`Data received from column: "${column}". Cell values: "${JSON.stringify(cellValues)}"`);
		});

		return cellValues;
	}

	public async sortColumn(column: string, order?: SortingOrder): Promise<void> {
		await test.step(`Sort "${column}" column`, async () => {
			if (!order) {
				await this.comGridTable.clickSortColumnButton(column);
				await this.waitForPageLoad();
				return;
			}

			let currentOrder = await this.comGridTable.getCurrentSortOrder(column);
			while (currentOrder !== order) {
				await this.comGridTable.clickSortColumnButton(column);
				await this.waitForPageLoad();
				currentOrder = await this.comGridTable.getCurrentSortOrder(column);
			}
		});
	}

	public async getRowsCount(): Promise<number> {
		let rowsNumber = 0;
		await test.step('Get rows count in the table', async () => {
			rowsNumber = await this.comGridTable.getRowsCount();
			log.info(`Found ${rowsNumber} rows in the table`);
		});

		return rowsNumber;
	}

	public async openFirstRecord(): Promise<void> {
		await test.step('Click on first record ID in the table', async () => {
			await this.comGridTable.clickOnFirstRecordId();
			await this.waitForPageLoad();
		});
	}

	public async openColumnFilter(column: string, type: string = 'filter-column-filled'): Promise<void> {
		await test.step(`Open filter with type "${type}" for "${column}" column`, async () => {
			await this.comGridTable.clickColumnFilterButton(column, type);
		});
	}

	public async performRowAction(rowNumber: number, action: string): Promise<void> {
		await test.step(`Perform "${action}" action for row number ${rowNumber}`, async () => {
			await this.comGridTable.clickRowActionMenuButton(rowNumber);
			await this.comGridTable.clickActionMenuItem(action);
			await this.comGridTable.confirmActionDialog();
			await this.waitForPageLoad();
		});
	}

	public async confirmActionDialog(): Promise<void> {
		await this.comGridTable.confirmActionDialog();
	}

	public async selectRow(rowNumber: number): Promise<void> {
		await test.step(`Select row number "${rowNumber}"`, async () => {
			await this.comGridTable.clickRowSelectCheckBox(rowNumber);
		});
	}

	public async clickOnColumnCell(rowNumber: number = 1, column: string) {
		await test.step(`Click on the column ("${column}") cell in row "${rowNumber}"`, async () => {
			await this.comGridTable.clickOnColumnCell(rowNumber, column);
			await this.waitForPageLoad();
		});
	}

	// PAGER STEPS
	public async getTotalRecordCount(parentElement?: Locator): Promise<number> {
		let result = 0;
		await test.step('Get total records count in the table', async () => {
			await this.comGridPager.waitForTimeout(1000);
			result = await this.comGridPager.getFooterTotalRowsCount(parentElement);
			log.info(`There are a total of ${result} records in the table`);
		});

		return result;
	}

	public async setPageSize(size: number): Promise<void> {
		await test.step(`Set grid page size to "${size}"`, async () => {
			await this.comGridPager.setPageSize(size);
		});
	}

	/*	ASSERTIONS	*/
	public async verifyMenuButtonIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that grid menu button is visible', async () => {
			expect(await this.comGridToolbar.isMenuButtonVisible(parentElement), ErrorMessages.NO_TOOLBAR_MENU_BTN).toBe(
				true
			);
		});
	}

	public async verifyMenuButtonIsVisibleMvc(): Promise<void> {
		await test.step('Assert that grid menu button is visible', async () => {
			expect(await this.comGridToolbar.isMenuButtonVisibleMvc(), ErrorMessages.NO_TOOLBAR_MENU_BTN).toBe(true);
		});
	}

	public async verifySearchButtonIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that grid search button is visible', async () => {
			expect(await this.comGridToolbar.isSearchButtonVisible(parentElement), ErrorMessages.NO_TOOLBAR_SEARCH_BTN).toBe(
				true
			);
		});
	}

	public async verifyPageSizeSelectorIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that page size selector is visible', async () => {
			expect(
				await this.comGridPager.isPageSizeSelectorVisible(parentElement),
				ErrorMessages.NO_PAGER_PAGE_SIZE_SELECTOR
			).toBe(true);
		});
	}

	public async verifySelectAllButtonIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that select all records checkbox is visible', async () => {
			if ((await this.comGridTable.getRowsCount(parentElement)) > 0) {
				expect(
					await this.comGridTable.isSelectAllButtonVisible(parentElement),
					ErrorMessages.NO_TABLE_SELECT_ALL_BTN
				).toBe(true);
			}
		});
	}

	public async verifyPreviousPageButtonIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that previous page button is visible', async () => {
			if ((await this.comGridPager.getFooterTotalRowsCount(parentElement)) > 25) {
				expect(
					await this.comGridPager.isPreviousPageButtonVisible(parentElement),
					ErrorMessages.NO_PAGER_PREVIOUS_PAGE_BTN
				).toBe(true);
			}
		});
	}

	public async verifyPagesListIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that pages list is visible', async () => {
			if ((await this.comGridPager.getFooterTotalRowsCount(parentElement)) > 25) {
				expect(await this.comGridPager.isPagesListVisible(parentElement), ErrorMessages.NO_PAGER_LIST_OF_PAGES).toBe(
					true
				);
			}
		});
	}

	public async verifyNextPageButtonIsVisible(parentElement?: Locator): Promise<void> {
		await test.step('Assert that total rows label is visible', async () => {
			if ((await this.comGridPager.getFooterTotalRowsCount(parentElement)) > 25) {
				expect(
					await this.comGridPager.isNextPageButtonVisible(parentElement),
					ErrorMessages.NO_PAGER_NEXT_PAGE_BTN
				).toBe(true);
			}
		});
	}

	public async verifyDynamicGridMenuItemIsVisible(itemName: string, parentElement?: Locator): Promise<void> {
		await test.step('Assert that total rows label is visible', async () => {
			expect
				.soft(
					await this.comGridMenu.isMenuItemVisible(itemName, parentElement),
					`Menu item "${itemName}" is not visible`
				)
				.toBe(true);
		});
	}
}
