import { ToasterComponent } from 'src/pages/components/index.js';
import { BaseSteps } from '../base.steps.js';

export class ToasterSteps extends BaseSteps {
	private comToaster: ToasterComponent;

	constructor() {
		super();
		this.comToaster = new ToasterComponent();
	}

	public async close() {
		await this.comToaster.close();
	}

	public async getMessage(): Promise<string> {
		const message = await this.comToaster.getMessage();
		return message.trim();
	}
}
