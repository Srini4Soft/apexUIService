import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { CensusDashboardPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class CensusUiAssertions extends BaseSteps {
	private pageDashboard: CensusDashboardPage;

	constructor() {
		super();
		this.pageDashboard = new CensusDashboardPage();
	}

	/** DASHBOARD PAGE */
	public async verifyWidgetTitleIsVisible(value: string) {
		expect(await this.pageDashboard.isWidgetTitleVisible(value), ErrorMessages.NO_WIDGET(value)).toBe(true);
	}

	public async verifyExpandCollapseButtonIsVisible() {
		expect(await this.pageDashboard.isExpandCollapseButtonVisible(), ErrorMessages.NO_BUTTON('Expand/Collapse')).toBe(
			true
		);
	}

	public async verifyMonthButtonIsVisible() {
		expect(await this.pageDashboard.isMonthButtonVisible(), ErrorMessages.NO_BUTTON('Select Month')).toBe(true);
	}

	public async verifyWeekButtonIsVisible() {
		expect(await this.pageDashboard.isWeekButtonVisible(), ErrorMessages.NO_BUTTON('Select Week')).toBe(true);
	}

	public async verifyDayButtonIsVisible() {
		expect(await this.pageDashboard.isDayButtonVisible(), ErrorMessages.NO_BUTTON('Select Day')).toBe(true);
	}

	public async verifyPreviousPeriodButtonIsVisible() {
		expect(await this.pageDashboard.isPreviousPeriodButtonVisible(), ErrorMessages.NO_BUTTON('Previous Day')).toBe(
			true
		);
	}

	public async verifyNextPeriodButtonIsVisible() {
		expect(await this.pageDashboard.isNextPeriodButtonVisible(), ErrorMessages.NO_BUTTON('Next Day')).toBe(true);
	}

	public async verifyCalendarButtonIsVisible() {
		expect(await this.pageDashboard.isCalendarButtonVisible(), ErrorMessages.NO_BUTTON('Calendar')).toBe(true);
	}
}
