import {
	CensusApiRequestsPage,
	CensusAutomationRulesPage,
	CensusChangesPage,
	CensusDashboardPage,
	CensusDataDiscrepanciesPage,
	CensusResidentsPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class CensusNavigationSteps extends BaseSteps {
	public async openApiRequestsPage(): Promise<void> {
		await new CensusApiRequestsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openAutomationRulesPage(): Promise<void> {
		await new CensusAutomationRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openChangesPage(): Promise<void> {
		await new CensusChangesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openResidentsPage(): Promise<void> {
		await new CensusResidentsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDashboardPage(): Promise<void> {
		await new CensusDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDataDiscrepanciesPage(): Promise<void> {
		await new CensusDataDiscrepanciesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
