import { BaseSteps } from 'src/steps/base.steps.js';
import { CensusUiAssertions } from './census-ui-assertions.steps.js';

export class CensusStepsFacade extends BaseSteps {
	public uiAssertions: CensusUiAssertions;

	constructor() {
		super();
		this.uiAssertions = new CensusUiAssertions();
	}
}
