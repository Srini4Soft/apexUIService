import { test } from 'src/common/fixtures/test-fixture.js';
import { IVeripayCaseDetails } from 'src/common/models/veripay-case-details.interface.js';
import log from 'src/common/utils/logger.js';
import { VeripayCaseDetailsPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayCaseDetailsSteps extends BaseSteps {
	private pageCaseDetails: VeripayCaseDetailsPage;

	constructor() {
		super();
		this.pageCaseDetails = new VeripayCaseDetailsPage();
	}

	/* ACTIONS */
	public async reloadPage() {
		await this.pageCaseDetails.reloadPage();
		await this.waitForPageLoad();
	}

	public getReferralName(): Promise<string> {
		return this.pageCaseDetails.getReferralName();
	}

	public async openNotesTab() {
		await test.step('Open "Notes" tab in case details', async () => {
			await this.pageCaseDetails.clickOnNotesTab();
			await this.waitForPageLoad();
		});
	}

	public async openDocumentsTab() {
		await test.step('Open "Documents" tab in case details', async () => {
			await this.pageCaseDetails.clickOnDocumentsTab();
			await this.waitForPageLoad();
		});
	}

	public async openMedicaidAppsTab() {
		await test.step('Open "Medicaid Applications" tab in case details', async () => {
			await this.pageCaseDetails.clickOnMedicaidAppsTab();
			await this.waitForPageLoad();
		});
	}

	public async openTasksTab() {
		await test.step('Open "Tasks" tab in case details', async () => {
			await this.pageCaseDetails.clickOnTasksTab();
			await this.waitForPageLoad();
		});
	}

	public async saveReferralDetailsForm() {
		await test.step('Press "Save" button', async () => {
			await this.pageCaseDetails.clickSaveButton();
			await this.waitForPageLoad();
		});
	}

	public async selectCaseTerm(serialNumber: number) {
		await this.pageCaseDetails.selectCaseTerm(serialNumber);
	}

	public async addPayer(data: IVeripayCaseDetails) {
		await this.pageCaseDetails.clickAddPayerButton();

		if (data.effectiveDate) {
			await this.pageCaseDetails.fillPayerEffectiveDate(data.effectiveDate);
		}

		if (data.payerCategoryId) {
			await this.pageCaseDetails.fillPayerCategory(data.payerCategoryId);
		}
	}

	public async addPreadmissionScreening(data: IVeripayCaseDetails) {
		if (data.authorizationNumber) {
			await this.pageCaseDetails.fillAuthorizationNumber(data.authorizationNumber);
		}
	}

	/* DOCUMENTS TAB */
	public async uploadFile(filePath: string) {
		await this.pageCaseDetails.addFileToUpload(filePath);
		await this.pageCaseDetails.startUpload();
	}

	/* GET VALUES */
	public async getTrackingStatus(): Promise<string> {
		return this.pageCaseDetails.getTrackingStatus();
	}

	public async getActiveCaseTerms(): Promise<string[]> {
		let result: string[] = [];
		let elements = await this.pageCaseDetails.getActiveCaseTerms();
		for (const element of elements) {
			let nestedTag = element.locator('//span[@class="amp-tag__title"]');
			if (nestedTag) {
				const text = await nestedTag.textContent();
				if (text) {
					result.push(text.trim());
				}
			}
		}

		return result;
	}

	public async getCaseId(): Promise<string> {
		const extractedNumber = this.pageCaseDetails.getUrl().match(/\/details\/(\d+)\//)?.[1] ?? '';
		log.info(`New Case ID: ${extractedNumber}`);
		return extractedNumber;
	}

	public async getCurrentNotes(): Promise<string[]> {
		await this.openNotesTab();
		return await this.pageCaseDetails.getNotesMessages();
	}

	public async getValidationMessages(): Promise<string[]> {
		return await this.pageCaseDetails.getValidationMessages();
	}

	public async getPayersNumber(): Promise<number> {
		return await this.pageCaseDetails.getPayersNumber();
	}

	public async getMedicaidAppsNumber(): Promise<number> {
		await this.openMedicaidAppsTab();
		return await this.pageCaseDetails.getMedicaidAppsNumber();
	}

	public async getLocRequestedNumber(): Promise<number> {
		await this.openMedicaidAppsTab();
		return await this.pageCaseDetails.getLocRequestedNumber();
	}

	public async getTaskList(): Promise<{ title: string; status: string }[]> {
		await this.openTasksTab();
		return await this.pageCaseDetails.getTaskInfo();
	}

	/*	ASSERTIONS	*/
	public async isFieldDisplayed(element: string): Promise<boolean> {
		return await this.pageCaseDetails.isFieldDisplayed(element);
	}

	public async isFieldReadonly(element: string): Promise<boolean> {
		return await this.pageCaseDetails.isFieldReadonly(element);
	}

	public async isFieldRequired(element: string): Promise<boolean> {
		return await this.pageCaseDetails.isFieldRequired(element);
	}
}
