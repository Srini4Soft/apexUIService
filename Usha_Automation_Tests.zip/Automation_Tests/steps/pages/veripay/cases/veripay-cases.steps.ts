import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { IVeripayCase } from 'src/common/models/index.js';
import { VeripayCasesPage, VeripayCreateCasePage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayCasesSteps extends BaseSteps {
	private pageCases: VeripayCasesPage;
	private pageCreateCase: VeripayCreateCasePage;

	constructor() {
		super();
		this.pageCases = new VeripayCasesPage();
		this.pageCreateCase = new VeripayCreateCasePage();
	}

	/* ACTIONS */
	public async openCreateNewCaseForm(): Promise<void> {
		await this.pageCases.clickCreateCaseButton();
	}

	public async fillCreateCaseForm(data: IVeripayCase) {
		await test.step('Fill "New Veripay Case" form with provided data', async () => {
			if (data.facilityId) {
				await this.pageCreateCase.fillFacility(data.facilityId);
				// await this.pageCreateCase.fillFacilitySearchInput(data.facilityId);
				// await this.pageCreateCase.clickFacilityItem(data.facilityId);
			}

			if (data.ownerUserId) {
				await this.pageCreateCase.fillOwner(data.ownerUserId);
			}

			if (data.ssn) {
				await this.pageCreateCase.fillSsn(data.ssn);
			}

			if (data.lastName) {
				await this.pageCreateCase.fillLastName(data.lastName);
			}
		});
	}

	public async createCase(data: IVeripayCase) {
		await this.pageCases.clickCreateCaseButton();
		await this.fillCreateCaseForm(data);
		await this.pageCreateCase.clickContinueButton();
		await this.waitForPageLoad();
		expect(await this.pageCreateCase.isBannerVisible(), ErrorMessages.NO_BANNER('No resident was found')).toBe(true);
		await this.pageCreateCase.clickContinueButton();
		await this.waitForPageLoad();
	}

	/* ASSERTIONS */
}
