import { VeripayReportsPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayReportsSteps extends BaseSteps {
	private pageReports: VeripayReportsPage;

	constructor() {
		super();
		this.pageReports = new VeripayReportsPage();
	}

	/* ACTIONS */
	public async openReport(position: number = 1) {
		await this.pageReports.clickOnReport(position);
		await this.waitForPageLoad();
	}

	/* ASSERTIONS */
}
