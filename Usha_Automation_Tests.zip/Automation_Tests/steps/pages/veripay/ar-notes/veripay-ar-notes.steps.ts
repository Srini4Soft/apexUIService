import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayArNotesSteps extends BaseSteps {
	/* ACTIONS */
	/* ASSERTIONS */
}
