import {
	VeripayArNotesPage,
	VeripayCaseAssetsPage,
	VeripayCaseDetailsPage,
	VeripayCaseIncomesPage,
	VeripayCaseMedicaidAppsPage,
	VeripayCasePayersPage,
	VeripayCasesPage,
	VeripayDashboardPage,
	VeripayReportsPage,
	VeripayRulesPage,
	VeripayTasksPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayNavigationSteps extends BaseSteps {
	public async openArNotesPage(): Promise<void> {
		await new VeripayArNotesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCaseAssetsPage(): Promise<void> {
		await new VeripayCaseAssetsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCaseIncomesPage(): Promise<void> {
		await new VeripayCaseIncomesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCasesPage(): Promise<void> {
		await new VeripayCasesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCaseDetailsPage(): Promise<void> {
		await new VeripayCaseDetailsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCaseMedicaidAppsPage(): Promise<void> {
		await new VeripayCaseMedicaidAppsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCasePayersPage(): Promise<void> {
		await new VeripayCasePayersPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDashboardPage(): Promise<void> {
		await new VeripayDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openReportsPage(): Promise<void> {
		await new VeripayReportsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openRulesPage(): Promise<void> {
		await new VeripayRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openTasksPage(): Promise<void> {
		await new VeripayTasksPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
