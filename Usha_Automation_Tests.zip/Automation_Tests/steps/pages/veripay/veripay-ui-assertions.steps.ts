import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import {
	VeripayArNotesPage,
	VeripayCasesPage,
	VeripayReportDetailsPage,
	VeripayReportsPage,
	VeripayRulesPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VeripayUiAssertions extends BaseSteps {
	private pageArNotes: VeripayArNotesPage;
	private pageCases: VeripayCasesPage;
	private pageReports: VeripayReportsPage;
	private pageReportDetails: VeripayReportDetailsPage;
	private pageRules: VeripayRulesPage;

	constructor() {
		super();
		this.pageArNotes = new VeripayArNotesPage();
		this.pageCases = new VeripayCasesPage();
		this.pageReports = new VeripayReportsPage();
		this.pageReportDetails = new VeripayReportDetailsPage();
		this.pageRules = new VeripayRulesPage();
	}

	/** A/R NOTES PAGE */
	public async verifyARNotesResidentSearchIsVisible() {
		expect(await this.pageArNotes.isResidentSearchVisible(), ErrorMessages.NO_ELEMENT('Resident Search')).toBe(true);
	}

	/** CASES PAGE */
	public async verifyCreateCaseButtonIsVisible() {
		expect(await this.pageCases.isCreateCaseButtonVisible(), ErrorMessages.NO_BUTTON('Create Case')).toBe(true);
	}

	/** REPORT PAGE */
	public async verifyReportsListIsVisible() {
		expect(await this.pageReports.isReportsListVisible(), ErrorMessages.NO_ELEMENT('Reports list')).toBe(true);
	}

	public async verifyReportConfigurationViewIsVisible() {
		expect(
			await this.pageReportDetails.isReportConfigurationViewVisible(),
			ErrorMessages.NO_ELEMENT('Report configuration view')
		).toBe(true);
	}

	public async verifyViewReportButtonIsVisible() {
		expect(await this.pageReportDetails.isViewReportButtonVisible(), ErrorMessages.NO_BUTTON('View Report')).toBe(true);
	}

	public async verifyReportDetailsReturnButtonIsVisible() {
		expect(await this.pageReportDetails.isReturnButtonVisible(), ErrorMessages.NO_BUTTON('Return')).toBe(true);
	}

	/** RULES PAGE */
	public async verifyCreateRuleButtonIsVisible() {
		expect(await this.pageRules.isCreateRuleButtonDisplayed(), ErrorMessages.NO_BUTTON('Create Rule')).toBe(true);
	}
}
