import { BaseSteps } from 'src/steps/base.steps.js';
import {
	VeripayArNotesSteps,
	VeripayCaseDetailsSteps,
	VeripayCasesSteps,
	VeripayReportsSteps,
	VeripayRulesSteps,
	VeripayUiAssertions,
} from 'src/steps/index.js';

export class VeripayStepsFacade extends BaseSteps {
	public arNotesSteps: VeripayArNotesSteps;
	public caseDetailsSteps: VeripayCaseDetailsSteps;
	public casesSteps: VeripayCasesSteps;
	public reportsSteps: VeripayReportsSteps;
	public rulesSteps: VeripayRulesSteps;
	public uiAssertions: VeripayUiAssertions;

	constructor() {
		super();
		this.arNotesSteps = new VeripayArNotesSteps();
		this.caseDetailsSteps = new VeripayCaseDetailsSteps();
		this.casesSteps = new VeripayCasesSteps();
		this.reportsSteps = new VeripayReportsSteps();
		this.rulesSteps = new VeripayRulesSteps();
		this.uiAssertions = new VeripayUiAssertions();
	}
}
