import { ValidationRuleActions } from 'src/common/enums/index.js';
import { RuleActions } from 'src/common/enums/rule-actions.enum.js';
import {
	IAddCaseNoteAction,
	IAddCasePayerAction,
	IAddCaseTagAction,
	IAddMedicaidApplicationAction,
	IAutomationRule,
	ICaseTrackingStatusTypeAction,
	ICompleteTaskAction,
	ICondition,
	ICreateTaskAction,
	ICreateWorkflowInstanceAction,
	IRemoveCasePayerAction,
	IRemoveCaseTagAction,
	IRequiredAction,
	ISetValueAutomationAction,
	ISetValueValidationAction,
	IValidationRule,
	IWarningAction,
} from 'src/common/models/index.js';
import { VeripayRulesPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';
import { AutomationRuleSteps } from 'src/steps/index.js';

export class VeripayRulesSteps extends BaseSteps {
	private pageRules: VeripayRulesPage;
	private stepsAutomationRule: AutomationRuleSteps;

	constructor() {
		super();
		this.pageRules = new VeripayRulesPage();
		this.stepsAutomationRule = new AutomationRuleSteps();
	}

	/* ACTIONS */
	public async openAutomationRulesTab() {
		await this.pageRules.clickOnAutomationRulesTab();
		await this.waitForPageLoad();
	}

	public async openValidationRulesTab() {
		await this.pageRules.clickOnValidationRulesTab();
		await this.waitForPageLoad();
	}

	public async openCreateRuleForm() {
		await this.pageRules.clickOnCreateRuleButton();
		await this.waitForPageLoad();
	}

	public async createRule(data: IAutomationRule): Promise<void> {
		await this.pageRules.clickOnCreateRuleButton();
		await this.stepsAutomationRule.fillCreateRuleForm(data);
		await this.stepsAutomationRule.clickCreateButton();
	}

	public async createAutomationRuleWithAction(
		ruleData: IAutomationRule,
		action: RuleActions,
		actionData: unknown
	): Promise<string> {
		await this.pageRules.clickOnCreateRuleButton();
		await this.stepsAutomationRule.fillCreateRuleForm(ruleData);
		await this.addAction(action, actionData);
		await this.stepsAutomationRule.clickCreateButton();
		return this.stepsAutomationRule.getRuleId();
	}

	public async createValidationRuleWithAction(
		ruleData: IValidationRule,
		action: ValidationRuleActions,
		actionData?: unknown
	): Promise<string> {
		await this.pageRules.clickOnCreateRuleButton();
		await this.stepsAutomationRule.fillCreateRuleForm(ruleData);
		await this.addValidationAction(action, actionData);
		await this.stepsAutomationRule.clickCreateButton();
		return this.stepsAutomationRule.getRuleId();
	}

	public async deleteSuccessAction(): Promise<void> {
		await this.stepsAutomationRule.deleteActionOnSuccess();
	}

	public async editActionCondition(condition: ICondition): Promise<void> {
		await this.stepsAutomationRule.editActionCondition(condition);
	}

	public async getActionCondition(): Promise<ICondition> {
		return await this.stepsAutomationRule.getActionCondition();
	}

	/** Adds an action to an open rule form. Saves the form after adding. */
	public async addNewAction(action: RuleActions, actionData: unknown): Promise<void> {
		await this.addAction(action, actionData);
		await this.stepsAutomationRule.clickSaveButton();
	}

	private async addAction(action: RuleActions, actionData?: unknown): Promise<void> {
		await this.stepsAutomationRule.addActionOnSuccess();
		switch (action) {
			case RuleActions.ADD_CASE_NOTE:
				await this.stepsAutomationRule.actionAddCaseNote(actionData as IAddCaseNoteAction);
				break;

			case RuleActions.ADD_CASE_PAYER:
				await this.stepsAutomationRule.actionAddCasePayer(actionData as IAddCasePayerAction);
				break;

			case RuleActions.ADD_CASE_TAG:
				await this.stepsAutomationRule.actionAddCaseTag(actionData as IAddCaseTagAction);
				break;

			case RuleActions.ADD_MEDICAID_APPLICATION:
				await this.stepsAutomationRule.actionAddMedicaidApplication(actionData as IAddMedicaidApplicationAction);
				break;

			case RuleActions.CHANGE_CASE_TRACKING_STATUS:
				await this.stepsAutomationRule.actionChangeCaseTrackingStatus(actionData as ICaseTrackingStatusTypeAction);
				break;

			case RuleActions.CREATE_TASK:
				await this.stepsAutomationRule.actionCreateTask(actionData as ICreateTaskAction);
				break;

			case RuleActions.COMPLETE_TASK:
				await this.stepsAutomationRule.actionCompleteTask(actionData as ICompleteTaskAction);
				break;

			case RuleActions.CREATE_WORKFLOW_INSTANCE:
				await this.stepsAutomationRule.actionCreateWorkflowInstance(actionData as ICreateWorkflowInstanceAction);
				break;

			case RuleActions.REMOVE_CASE_PAYER:
				await this.stepsAutomationRule.actionRemoveCasePayer(actionData as IRemoveCasePayerAction);
				break;

			case RuleActions.REMOVE_CASE_TAG:
				await this.stepsAutomationRule.actionRemoveCaseTag(actionData as IRemoveCaseTagAction);
				break;

			case RuleActions.SET_VALUE_AUTO:
				await this.stepsAutomationRule.actionSetValueAutomation(actionData as ISetValueAutomationAction);
				break;
		}
	}

	private async addValidationAction(action: ValidationRuleActions, actionData?: unknown): Promise<void> {
		await this.stepsAutomationRule.addActionOnSuccess();
		switch (action) {
			case ValidationRuleActions.HIDDEN:
				await this.stepsAutomationRule.actionHidden();
				break;

			case ValidationRuleActions.READONLY:
				await this.stepsAutomationRule.actionReadonly();
				break;

			case ValidationRuleActions.REQUIRED:
				await this.stepsAutomationRule.actionRequired(actionData as IRequiredAction);
				break;

			case ValidationRuleActions.NOT_REQUIRED:
				await this.stepsAutomationRule.actionNotRequired();
				break;

			case ValidationRuleActions.SET_VALUE:
				await this.stepsAutomationRule.actionSetValueValidation(actionData as ISetValueValidationAction);
				break;

			case ValidationRuleActions.WARNING:
				await this.stepsAutomationRule.actionWarning(actionData as IWarningAction);
				break;
		}
	}

	/* ASSERTIONS */
}
