import { expect } from '@playwright/test';
import { IRule } from 'src/common/models/rule.interface.js';
import { ManageNotificationRulePage, NotificationRulesPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class SettingsNotificationRulesSteps extends BaseSteps {
	private pageNotificationRules: NotificationRulesPage;
	private pageManageRule: ManageNotificationRulePage;

	constructor() {
		super();
		this.pageNotificationRules = new NotificationRulesPage();
		this.pageManageRule = new ManageNotificationRulePage();
	}

	/* ACTIONS */
	public async clickCreateRuleButton() {
		await this.pageNotificationRules.clickOnCreateRuleButton();
	}

	public async fillRuleForm(data: IRule) {
		if (data.ruleName) {
			await this.pageManageRule.fillName(data.ruleName);
		}

		if (data.facilities) {
			await this.pageManageRule.clickApplyFacilitiesButton();
		}

		if (data.eventTypes) {
			await this.pageManageRule.fillEventTypes(data.eventTypes);
		}

		if (data.enabled !== undefined) {
			await this.pageManageRule.fillEnabled(data.enabled);
		}

		if (data.global !== undefined) {
			await this.pageManageRule.fillGlobal(data.global);
		}

		if (data.skipSending !== undefined) {
			await this.pageManageRule.fillSkipSending(data.skipSending);
		}

		if (data.groups) {
			await this.pageManageRule.fillGroups(data.groups);
		}

		if (data.facilityContactTypes) {
			await this.pageManageRule.fillFacilityContactTypes(data.facilityContactTypes);
		}

		if (data.users) {
			await this.pageManageRule.fillUsers(data.users);
		}

		if (data.emails) {
			await this.pageManageRule.fillEmails(data.emails);
		}

		if (data.recipientUsers !== undefined) {
			await this.pageManageRule.fillRecipientUsers(data.recipientUsers);
		}

		if (data.sendSingleEmail !== undefined) {
			await this.pageManageRule.fillSendSingleEmail(data.sendSingleEmail);
		}

		if (data.includeInitiator !== undefined) {
			await this.pageManageRule.fillIncludeInitiator(data.includeInitiator);
		}

		if (data.excludeInitiator !== undefined) {
			await this.pageManageRule.fillExcludeInitiator(data.excludeInitiator);
		}

		if (data.digestOfNotifications !== undefined) {
			await this.pageManageRule.fillDigestOfNotifications(data.digestOfNotifications);
		}

		if (data.recipientGroupType) {
			await this.pageManageRule.fillRecipientGroupType(data.recipientGroupType);
		}

		if (data.eventsThreshold) {
			await this.pageManageRule.fillEventsThreshold(data.eventsThreshold);
		}

		if (data.schedule !== undefined) {
			await this.pageManageRule.fillSchedule(data.schedule);
		}

		if (data.actions) {
			await this.pageManageRule.clickActionsButton();
			await this.pageManageRule.fillActionMethod(data.actions.method);
			await this.pageManageRule.fillActionTemplate(data.actions.template);
			await this.pageManageRule.clickApplyActionButton();
		}

		await this.pageManageRule.waitForTimeout(3000);
	}

	public async createRule(rule: IRule): Promise<void> {
		await this.pageNotificationRules.clickOnCreateRuleButton();
		await this.waitForPageLoad();
		await this.fillRuleForm(rule);
		await this.pageManageRule.clickFinishButton();
		await this.waitForPageLoad();
	}

	/* ASSERTIONS */
	public async verifyFinishButtonIsDisabled() {
		expect(await this.pageManageRule.isFinishButtonDisabled(), '"Finish" button is enabled').toBe(true);
	}

	public async verifySaveButtonIsDisabled() {
		expect(await this.pageManageRule.isSaveButtonDisabled(), '"Save" button is enabled').toBe(true);
	}
}
