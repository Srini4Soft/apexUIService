import {
	NotificationRulesPage,
	SettingsDashboardPage,
	SettingsEventLogPage,
	SettingsManageEntitiesPage,
	SettingsMappingListPage,
	SettingsMissingMappingsPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class SettingsNavigationSteps extends BaseSteps {
	public async openDashboardPage(): Promise<void> {
		await new SettingsDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openEventLogPage(): Promise<void> {
		await new SettingsEventLogPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openMappingListPage(): Promise<void> {
		await new SettingsMappingListPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openMissingMappingsPage(): Promise<void> {
		await new SettingsMissingMappingsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openNotificationRulesPage(): Promise<void> {
		await new NotificationRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openManageEntitiesPage(): Promise<void> {
		await new SettingsManageEntitiesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
