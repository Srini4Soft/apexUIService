import { BaseSteps } from 'src/steps/base.steps.js';
import {
	SettingsManageEntitiesSteps,
	SettingsMappingListSteps,
	SettingsNotificationRulesSteps,
	SettingsUiAssertions,
} from 'src/steps/index.js';

export class SettingsStepsFacade extends BaseSteps {
	public manageEntitiesSteps: SettingsManageEntitiesSteps;
	public mappingListSteps: SettingsMappingListSteps;
	public notificationRulesSteps: SettingsNotificationRulesSteps;
	public uiAssertions: SettingsUiAssertions;

	constructor() {
		super();
		this.manageEntitiesSteps = new SettingsManageEntitiesSteps();
		this.mappingListSteps = new SettingsMappingListSteps();
		this.notificationRulesSteps = new SettingsNotificationRulesSteps();
		this.uiAssertions = new SettingsUiAssertions();
	}
}
