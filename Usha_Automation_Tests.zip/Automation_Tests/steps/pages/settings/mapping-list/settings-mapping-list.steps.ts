import { test } from 'src/common/fixtures/test-fixture.js';
import { IMapping } from 'src/common/models/mapping.interface.js';
import { ManageMappingPage, SettingsMappingListPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class SettingsMappingListSteps extends BaseSteps {
	private pageMappingList: SettingsMappingListPage;
	private pageManageMapping: ManageMappingPage;

	constructor() {
		super();
		this.pageMappingList = new SettingsMappingListPage();
		this.pageManageMapping = new ManageMappingPage();
	}

	/* ACTIONS */
	public async clickCreateMappingButton(): Promise<void> {
		await this.pageMappingList.clickOnCreateButton();
		await this.waitForPageLoad();
	}

	public async fillCreateMappingForm(data: IMapping): Promise<void> {
		await test.step('Fill "New/Edit Mapping" form', async () => {
			if (data.mappingTypeId) {
				await this.pageManageMapping.fillMappingType(data.mappingTypeId);
			}

			if (data.sourceSystemId) {
				await this.pageManageMapping.fillSourceSystem(data.sourceSystemId);
			}

			if (data.input) {
				await this.pageManageMapping.fillInput(data.input);
			}

			if (data.output) {
				await this.pageManageMapping.fillOutput(data.output);
			}

			if (data.description) {
				await this.pageManageMapping.fillDescription(data.description);
			}

			if (data.startDate) {
				await this.pageManageMapping.fillStartDate(data.startDate);
			}

			if (data.endDate) {
				await this.pageManageMapping.fillEndDate(data.endDate);
			}

			if (data.organizationType) {
				await this.pageManageMapping.fillOrganizationType(data.organizationType);
			}

			if (data.organizationId) {
				await this.pageManageMapping.fillOrganization(data.organizationId);
			}

			if (data.isDisabled !== undefined) {
				await this.pageManageMapping.fillIsDisabled(data.isDisabled);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManageMapping.fillIsGlobal(data.isGlobal);
			}

			if (data.tenantEntityId && (data.isGlobal === false || data.isGlobal === undefined)) {
				await this.pageManageMapping.fillTenantEntity(data.tenantEntityId);
			}
		});
	}

	public async createMapping(data: IMapping): Promise<void> {
		await this.pageMappingList.clickOnCreateButton();
		await this.waitForPageLoad();
		await this.fillCreateMappingForm(data);
		await this.pageManageMapping.clickSaveButton();
		await this.waitForPageLoad();
	}

	public async updateMapping(data: IMapping): Promise<void> {
		await this.fillCreateMappingForm(data);
		await this.pageManageMapping.clickSaveButton();
		await this.waitForPageLoad();
	}

	public async closeMappingForm(): Promise<void> {
		await this.pageManageMapping.clickCancelButton();
		await this.waitForPageLoad();
	}

	public async copyMapping(tenant: string) {
		await test.step('Fill "Copy Mapping" form', async () => {
			await this.pageManageMapping.fillTenantEntity(tenant);
			await this.pageManageMapping.clickCopyMappingButton();
			await this.waitForPageLoad();
		});
	}
}
