import { test } from 'src/common/fixtures/test-fixture.js';
import { ILookup, IPayer, IPerson } from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { ManageLookupPage, ManagePayerPage, ManagePersonPage, SettingsManageEntitiesPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class SettingsManageEntitiesSteps extends BaseSteps {
	private pageManageEntities: SettingsManageEntitiesPage;
	private pageManagePerson: ManagePersonPage;
	private pageManageLookup: ManageLookupPage;
	private pageManagePayer: ManagePayerPage;

	constructor() {
		super();
		this.pageManageEntities = new SettingsManageEntitiesPage();
		this.pageManagePerson = new ManagePersonPage();
		this.pageManageLookup = new ManageLookupPage();
		this.pageManagePayer = new ManagePayerPage();
	}

	/* ACTIONS */
	// Tabs navigation
	public async openPeoplePage(timeout?: number): Promise<void> {
		await this.pageManageEntities.openPeoplePage();
		await this.waitForPageLoad(timeout);
	}

	public async openPeopleTab(): Promise<void> {
		await this.pageManageEntities.clickOnPeopleTab();
		await this.waitForPageLoad();
	}

	public async openLookupsTab(): Promise<void> {
		await this.pageManageEntities.clickOnLookupsTab();
		await this.waitForPageLoad();
	}

	public async openPayersPage(timeout?: number): Promise<void> {
		await this.pageManageEntities.openPayersPage();
		await this.waitForPageLoad(timeout);
	}

	public async openPayersTab(): Promise<void> {
		await this.pageManageEntities.clickOnPayersTab();
		await this.waitForPageLoad();
	}

	/* PERSON PAGE ACTIONS */
	public async fillCreatePersonForm(data: IPerson): Promise<void> {
		await test.step('Fill "Create Person" form', async () => {
			log.info(`Fill "Create Person" form with following data: ${JSON.stringify(data)}`);
			if (data.type) {
				await this.pageManagePerson.fillType(data.type);
			}

			if (data.lastName) {
				await this.pageManagePerson.fillLastName(data.lastName);
			}

			if (data.firstName) {
				await this.pageManagePerson.fillFirstName(data.firstName);
			}

			if (data.middleName) {
				await this.pageManagePerson.fillMiddleName(data.middleName);
			}

			if (data.gender) {
				await this.pageManagePerson.fillGender(data.gender);
			}

			if (data.birthDate) {
				await this.pageManagePerson.fillBirthDate(data.birthDate);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManagePerson.fillIsGlobal(data.isGlobal);
			}

			if (data.facilityIds && data.isGlobal === false) {
				await this.pageManagePerson.fillFacility(data.facilityIds);
			}

			if (data.employeeStartDate) {
				await this.pageManagePerson.fillEmployeeStartDate(data.employeeStartDate);
			}

			if (data.location) {
				await this.pageManagePerson.fillLocation(data.location);
			}

			if (data.organizations) {
				await this.pageManagePerson.clickAddOrganizationButton();

				log.info(
					`Fill "Organization" with "${data.organizations.organizationId}" and "Position with "${data.organizations.lookupPositionId}"`
				);
				await this.pageManagePerson.fillOrganization(data.organizations.organizationId);
				if (data.organizations.lookupPositionId !== undefined && data.organizations.lookupPositionId !== '') {
					await this.pageManagePerson.fillPosition(data.organizations.lookupPositionId);
				}
			}
		});
	}

	public async fillEditPersonForm(data: IPerson): Promise<void> {
		await test.step('Fill "Edit Person" form', async () => {
			log.info(`Fill "Create Person" form with following data: ${JSON.stringify(data)}`);
			if (data.lastName) {
				await this.pageManagePerson.fillLastName(data.lastName);
			}

			if (data.firstName) {
				await this.pageManagePerson.fillFirstName(data.firstName);
			}

			if (data.middleName) {
				await this.pageManagePerson.fillMiddleName(data.middleName);
			}

			if (data.gender) {
				await this.pageManagePerson.fillGender(data.gender);
			}

			if (data.birthDate) {
				await this.pageManagePerson.fillBirthDate(data.birthDate);
			}

			if (data.isApproved !== undefined) {
				await this.pageManagePerson.fillIsApproved(data.isApproved);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManagePerson.fillIsGlobal(data.isGlobal);
			}

			if (data.facilityIds && data.isGlobal === false) {
				await this.pageManagePerson.fillFacility(data.facilityIds);
			}

			if (data.speciality) {
				await this.pageManagePerson.fillDoctorSpeciality(data.speciality);
			}

			if (data.npi) {
				await this.pageManagePerson.fillNpi(data.npi);
			}

			if (data.addressLine1) {
				await this.pageManagePerson.fillAddressLineOne(data.addressLine1);
			}

			if (data.addressLine2) {
				await this.pageManagePerson.fillAddressLineTwo(data.addressLine2);
			}

			if (data.city) {
				await this.pageManagePerson.fillCity(data.city);
			}

			if (data.stateId) {
				await this.pageManagePerson.fillState(data.stateId);
			}

			if (data.zipCode) {
				await this.pageManagePerson.fillZipCode(data.zipCode);
			}

			if (data.countyId) {
				await this.pageManagePerson.fillCounty(data.countyId);
			}

			if (data.email) {
				await this.pageManagePerson.fillEmail(data.email);
			}

			if (data.workPhoneNumber) {
				await this.pageManagePerson.fillWorkNumber(data.workPhoneNumber);
			}

			if (data.workPhoneNumberExt) {
				await this.pageManagePerson.fillWorkNumberExt(data.workPhoneNumberExt);
			}

			if (data.mobilePhoneNumber) {
				await this.pageManagePerson.fillMobileNumber(data.mobilePhoneNumber);
			}

			if (data.homePhoneNumber) {
				await this.pageManagePerson.fillHomeNumber(data.homePhoneNumber);
			}

			if (data.faxNumber) {
				await this.pageManagePerson.fillFaxNumber(data.faxNumber);
			}

			if (data.userId) {
				await this.pageManagePerson.fillUser(data.userId);
			}

			if (data.employeeStartDate) {
				await this.pageManagePerson.fillEmployeeStartDate(data.employeeStartDate);
			}

			if (data.location) {
				await this.pageManagePerson.fillLocation(data.location);
			}

			if (data.organizations) {
				await this.pageManagePerson.clickAddOrganizationButton();

				log.info(
					`Fill "Organization" with "${data.organizations.organizationId}" and "Position with "${data.organizations.lookupPositionId}"`
				);
				await this.pageManagePerson.fillOrganization(data.organizations.organizationId);
				if (data.organizations.lookupPositionId !== undefined && data.organizations.lookupPositionId !== '') {
					await this.pageManagePerson.fillPosition(data.organizations.lookupPositionId);
				}
			}
		});
	}

	public async createPerson(data: IPerson): Promise<void> {
		await this.pageManageEntities.clickOnCreateButton();
		await this.waitForPageLoad();
		await this.fillCreatePersonForm(data);
		await this.submitPersonForm();
	}

	public async editPerson(data: IPerson): Promise<void> {
		await this.fillEditPersonForm(data);
		await this.submitPersonForm();
	}

	public async submitPersonForm(): Promise<void> {
		await test.step('Press "Create" button', async () => {
			await this.pageManagePerson.clickCreateButton();
			await this.waitForPageLoad();
		});
	}

	/* PERSON PAGE ACTIONS */
	public async fillCreateLookupForm(data: ILookup): Promise<void> {
		await test.step('Fill "Create Lookup" form', async () => {
			log.info(`Fill "Create Lookup" form with following data: ${JSON.stringify(data)}`);
			if (data.name) {
				await this.pageManageLookup.fillName(data.name);
			}

			if (data.lookupNamespaceId) {
				await this.pageManageLookup.fillType(data.lookupNamespaceId);
			}

			if (data.code) {
				await this.pageManageLookup.fillCode(data.code);
			}

			if (data.isApproved !== undefined) {
				await this.pageManageLookup.fillIsApproved(data.isApproved);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManageLookup.fillIsGlobal(data.isGlobal);
			}

			if (data.facilityIds && data.isGlobal === false) {
				//TODO: rework
				await this.pageManageLookup.clickFacilitySelect();
				await this.pageManageLookup.clickFacilityUnselectAll();
				await this.pageManageLookup.fillFacilitySearchInput(data.facilityIds);
				await this.pageManageLookup.clickFacilityItem(data.facilityIds);
				await this.pageManageLookup.clickFacilityApplyButton();
			}

			if (data.displayColorId) {
				await this.pageManageLookup.fillDisplayColor(data.displayColorId);
			}
		});
	}

	public async fillEditLookupForm(data: ILookup): Promise<void> {
		await test.step('Fill "Edit Lookup" form', async () => {
			log.info(`Fill "Edit Lookup" form with following data: ${JSON.stringify(data)}`);
			if (data.name) {
				await this.pageManageLookup.fillName(data.name);
			}

			if (data.code) {
				await this.pageManageLookup.fillCode(data.code);
			}

			if (data.isApproved !== undefined) {
				await this.pageManageLookup.fillIsApproved(data.isApproved);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManageLookup.fillIsGlobal(data.isGlobal);
			}

			if (data.facilityIds && data.isGlobal === false) {
				//TODO: rework
				await this.pageManageLookup.clickFacilitySelect();
				await this.pageManageLookup.clickFacilityUnselectAll();
				await this.pageManageLookup.fillFacilitySearchInput(data.facilityIds);
				await this.pageManageLookup.clickFacilityItem(data.facilityIds);
				await this.pageManageLookup.clickFacilityApplyButton();
			}

			if (data.displayColorId) {
				await this.pageManageLookup.fillDisplayColor(data.displayColorId);
			}
		});
	}

	public async createLookup(data: ILookup): Promise<void> {
		await this.pageManageEntities.clickOnCreateButton();
		await this.waitForPageLoad();
		await this.fillCreateLookupForm(data);
		await this.pageManageLookup.clickSaveButton();
		await this.waitForPageLoad();
	}

	public async editLookup(data: ILookup): Promise<void> {
		await this.fillEditLookupForm(data);
		await this.pageManageLookup.clickFinishButton();
		await this.waitForPageLoad();
	}

	/* PAYER PAGE ACTIONS */
	public async fillCreatePayerForm(data: IPayer): Promise<void> {
		await test.step('Fill "Create Payer" form', async () => {
			log.info(`Fill "Create Payer" form with following data: ${JSON.stringify(data)}`);
			if (data.payerCategoryId) {
				await this.pageManagePayer.fillPayerCategory(data.payerCategoryId);
			}

			if (data.name) {
				await this.pageManagePayer.fillName(data.name);
			}

			if (data.primaryPayerId) {
				await this.pageManagePayer.fillPrimaryPayer(data.primaryPayerId);
			}

			if (data.description) {
				await this.pageManagePayer.fillDescription(data.description);
			}

			if (data.isGlobal !== undefined) {
				await this.pageManagePayer.fillIsGlobal(data.isGlobal);
			}

			if (data.canBePrimary !== undefined) {
				await this.pageManagePayer.fillCanBePrimary(data.canBePrimary);
			}

			if (data.canBeAncillary !== undefined) {
				await this.pageManagePayer.fillCanBeAncillary(data.canBeAncillary);
			}

			if (data.canBeCoinsurance !== undefined) {
				await this.pageManagePayer.fillCanBeCoinsurance(data.canBeCoinsurance);
			}

			if (data.eligibilityProviderKey) {
				await this.pageManagePayer.fillEligibilityProviderKey(data.eligibilityProviderKey);
			}

			if (data.primaryStateId) {
				await this.pageManagePayer.fillState(data.primaryStateId);
			}

			if (data.dischargeBillingType) {
				await this.pageManagePayer.fillDischargeBillingType(data.dischargeBillingType);
			}

			if (data.requiresAuthorization !== undefined) {
				await this.pageManagePayer.fillRequiresAuthorization(data.requiresAuthorization);
			}

			if (data.simplifiedAuthorization !== undefined && data.requiresAuthorization === true) {
				await this.pageManagePayer.fillSimplified(data.simplifiedAuthorization);
			}

			if (data.verificationDefaultStartType) {
				await this.pageManagePayer.fillVerificationDefaultStartType(data.verificationDefaultStartType);
			}

			if (data.isPending !== undefined) {
				await this.pageManagePayer.fillIsPending(data.isPending);
			}

			if (data.reviewedOn) {
				await this.pageManagePayer.fillReviewedOn(data.reviewedOn);
			}
		});
	}

	public async createPayer(data: IPayer): Promise<void> {
		await this.pageManageEntities.clickOnCreateButton();
		await this.waitForPageLoad();
		await this.fillCreatePayerForm(data);
		await this.submitPayerForm();
	}

	public async submitPayerForm(): Promise<void> {
		await test.step('Press "Create" button', async () => {
			await this.pageManagePayer.clickSaveButton();
			await this.waitForPageLoad();
		});
	}
}
