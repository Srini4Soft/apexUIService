import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { NotificationRulesPage, SettingsManageEntitiesPage, SettingsMappingListPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class SettingsUiAssertions extends BaseSteps {
	private pageMappingList: SettingsMappingListPage;
	private pageNotificationRules: NotificationRulesPage;
	private pageManageEntities: SettingsManageEntitiesPage;

	constructor() {
		super();
		this.pageMappingList = new SettingsMappingListPage();
		this.pageNotificationRules = new NotificationRulesPage();
		this.pageManageEntities = new SettingsManageEntitiesPage();
	}

	/** MAPPING LIST PAGE */
	public async verifyCreateMappingButtonIsVisible() {
		expect(await this.pageMappingList.isCreateMappingButtonVisible(), ErrorMessages.NO_BUTTON('Create Mapping')).toBe(
			true
		);
	}

	/** NOTIFICATION RULES PAGE */
	public async verifyCreateNotificationRuleButtonIsVisible() {
		expect(await this.pageNotificationRules.isCreateRuleButtonDisplayed(), ErrorMessages.NO_BUTTON('Create Rule')).toBe(
			true
		);
	}

	/** MANAGE ENTITIES PAGE */
	public async verifyCreateEntityButtonIsVisible() {
		expect(await this.pageManageEntities.isCreateEntityButtonVisible(), ErrorMessages.NO_BUTTON('Create Lookup')).toBe(
			true
		);
	}
}
