import { BaseSteps } from 'src/steps/base.steps.js';

export class BiStepsFacade extends BaseSteps {
	constructor() {
		super();
	}
}
