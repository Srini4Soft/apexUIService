import {
	BiArPage,
	BiArTrendPage,
	BiCashReceiptsTrendPage,
	BiCashVsPriorRevenuePage,
	BiCashVsRevenuePage,
	BiCashVsRevenueTrendPage,
	BiCollectedPage,
	BiCollectedTrendPage,
	BiDashboardPage,
	BiDsoDebitBalancePage,
	BiDsoNetBalancePage,
	BiRevenueTrendPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class BiNavigationSteps extends BaseSteps {
	public async openArPage(): Promise<void> {
		await new BiArPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openArTrendPage(): Promise<void> {
		await new BiArTrendPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCashReceiptsTrendPage(): Promise<void> {
		await new BiCashReceiptsTrendPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCashVsPriorRevenuePage(): Promise<void> {
		await new BiCashVsPriorRevenuePage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCashVsRevenuePage(): Promise<void> {
		await new BiCashVsRevenuePage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCashVsRevenueTrendPage(): Promise<void> {
		await new BiCashVsRevenueTrendPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCollectedTrendPage(): Promise<void> {
		await new BiCollectedTrendPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openCollectedPage(): Promise<void> {
		await new BiCollectedPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDashboardPage(): Promise<void> {
		await new BiDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDsoDebitBalancePage(): Promise<void> {
		await new BiDsoDebitBalancePage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDsoNetBalancePage(): Promise<void> {
		await new BiDsoNetBalancePage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openRevenueTrendPage(): Promise<void> {
		await new BiRevenueTrendPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
