import { BaseSteps } from 'src/steps/base.steps.js';
import { VerificationsUiAssertions } from 'src/steps/index.js';

export class VerificationsStepsFacade extends BaseSteps {
	public uiAssertions: VerificationsUiAssertions;

	constructor() {
		super();
		this.uiAssertions = new VerificationsUiAssertions();
	}
}
