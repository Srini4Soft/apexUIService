import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { ReverificationRulesPage, VerificationDeltasPage, VerificationListPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VerificationsUiAssertions extends BaseSteps {
	private pageDeltas: VerificationDeltasPage;
	private pageVerificationList: VerificationListPage;
	private pageReverificationRules: ReverificationRulesPage;

	constructor() {
		super();
		this.pageDeltas = new VerificationDeltasPage();
		this.pageVerificationList = new VerificationListPage();
		this.pageReverificationRules = new ReverificationRulesPage();
	}

	/** DELTAS PAGE */
	public async verifySelectViewDropdownIsVisible() {
		expect(await this.pageDeltas.isSelectViewDropdownVisible(), ErrorMessages.NO_ELEMENT('Select view dropdown')).toBe(
			true
		);
	}

	/** VERIFICATION LIST PAGE */
	public async verifyEligibilityButtonIsVisible() {
		expect(
			await this.pageVerificationList.isEligibilityButtonVisible(),
			ErrorMessages.NO_BUTTON('Verify Eligibility')
		).toBe(true);
	}

	/** REVERIFICATION RULES PAGE */
	public async verifyCreateRuleButtonIsVisible() {
		expect(await this.pageReverificationRules.isCreateRuleButtonVisible(), ErrorMessages.NO_BUTTON('Create Rule')).toBe(
			true
		);
	}
}
