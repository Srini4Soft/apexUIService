import {
	ReverificationRulesPage,
	VerificationDeltasPage,
	VerificationListPage,
	VerificationsBatchesPage,
	VerificationsDashboardPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class VerificationsNavigationSteps extends BaseSteps {
	public async openBatchesPage(): Promise<void> {
		await new VerificationsBatchesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDashboardPage(): Promise<void> {
		await new VerificationsDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openVerificationDeltasPage(): Promise<void> {
		await new VerificationDeltasPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openVerificationListPage(): Promise<void> {
		await new VerificationListPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openReverificationRulesPage(): Promise<void> {
		await new ReverificationRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
