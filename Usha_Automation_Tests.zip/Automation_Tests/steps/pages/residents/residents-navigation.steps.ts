import {
	ResidentsCensusDeltaPage,
	ResidentsDashboardPage,
	ResidentsGlobalResidentsPage,
	ResidentsMasterDataPage,
	ResidentsRulesPage,
	ResidentsSubmissionQueuePage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class ResidentsNavigationSteps extends BaseSteps {
	public async openCensusDeltaPage(): Promise<void> {
		await new ResidentsCensusDeltaPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openDashboardPage(): Promise<void> {
		await new ResidentsDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openGlobalResidentsPage(): Promise<void> {
		await new ResidentsGlobalResidentsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openMasterDataPage(): Promise<void> {
		await new ResidentsMasterDataPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openRulesPage(): Promise<void> {
		await new ResidentsRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openSubmissionQueuePage(): Promise<void> {
		await new ResidentsSubmissionQueuePage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
