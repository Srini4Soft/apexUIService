import { test } from 'src/common/fixtures/test-fixture.js';
import { ResidentsDetailsPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class ResidentsDetailsSteps extends BaseSteps {
	private pageResidentDetails: ResidentsDetailsPage;

	constructor() {
		super();
		this.pageResidentDetails = new ResidentsDetailsPage();
	}

	/* ACTIONS */
	public async reloadPage() {
		await this.pageResidentDetails.reloadPage();
		await this.waitForPageLoad();
	}

	public async openDocumentsTab() {
		await test.step('Open "Documents" tab in case details', async () => {
			await this.pageResidentDetails.clickOnDocumentsTab();
			await this.waitForPageLoad();
		});
	}

	/* DOCUMENTS TAB */
	public async uploadFile(filePath: string) {
		await this.pageResidentDetails.addFileToUpload(filePath);
		await this.pageResidentDetails.startUpload();
	}
}
