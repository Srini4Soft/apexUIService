import { BaseSteps } from 'src/steps/base.steps.js';

export class ResidentsCensusDeltaSteps extends BaseSteps {
	/* ACTIONS */

	public async fillSources(from: string, to: string) {
		if (from !== undefined || from !== '') {
			await this.pageResidentsCensusDelta.fillFromSource(from);
			await this.page.keyboard.press('Enter');
			await this.waitForPageLoad();
		}
		if (to !== undefined || to !== '') {
			await this.pageResidentsCensusDelta.fillToSource(to);
			await this.page.keyboard.press('Enter');
			await this.waitForPageLoad();
		}
	}

	/* ASSERTIONS */
}
