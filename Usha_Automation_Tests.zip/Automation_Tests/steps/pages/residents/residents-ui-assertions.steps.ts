import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import {
	ResidentsCensusDeltaPage,
	ResidentsDashboardPage,
	ResidentsGlobalResidentsPage,
	ResidentsMasterDataPage,
	ResidentsRulesPage,
	ResidentsSubmissionQueuePage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class ResidentsUiAssertions extends BaseSteps {
	protected pageCensusDelta: ResidentsCensusDeltaPage;
	protected pageDashboard: ResidentsDashboardPage;
	protected pageGlobalResidents: ResidentsGlobalResidentsPage;
	protected pageMasterData: ResidentsMasterDataPage;
	protected pageRules: ResidentsRulesPage;
	protected pageSubmissionQueue: ResidentsSubmissionQueuePage;

	constructor() {
		super();
		this.pageCensusDelta = new ResidentsCensusDeltaPage();
		this.pageDashboard = new ResidentsDashboardPage();
		this.pageGlobalResidents = new ResidentsGlobalResidentsPage();
		this.pageMasterData = new ResidentsMasterDataPage();
		this.pageRules = new ResidentsRulesPage();
		this.pageSubmissionQueue = new ResidentsSubmissionQueuePage();
	}

	/** CENSUS DELTA PAGE */
	public async verifySectionIsVisible(value: string) {
		expect(await this.pageCensusDelta.isSectionVisible(value), ErrorMessages.NO_ELEMENT(value)).toBe(true);
	}

	/** DASHBOARD PAGE */
	public async verifyWidgetTitleIsVisible(value: string) {
		expect(await this.pageDashboard.isWidgetTitleVisible(value), ErrorMessages.NO_WIDGET(value)).toBe(true);
	}

	/** GLOBAL RESIDENTS PAGE */
	public async verifyCreateGlobalResidentButtonIsVisible() {
		expect(
			await this.pageGlobalResidents.isCreateGlobalResidentButtonVisible(),
			ErrorMessages.NO_BUTTON('Create Global Resident')
		).toBe(true);
	}

	/** MASTER DATA PAGE */
	public async verifyCreateResidentButtonIsVisible() {
		expect(await this.pageMasterData.isCreateResidentButtonVisible(), ErrorMessages.NO_BUTTON('Create Resident')).toBe(
			true
		);
	}

	/** RULES PAGE */
	public async verifyCreateRuleButtonIsVisible() {
		expect(await this.pageRules.isCreateRuleButtonVisible(), ErrorMessages.NO_BUTTON('Create Rule')).toBe(true);
	}
}
