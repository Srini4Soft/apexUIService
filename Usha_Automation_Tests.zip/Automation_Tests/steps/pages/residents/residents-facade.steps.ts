import { BaseSteps } from 'src/steps/base.steps.js';
import { ResidentsCensusDeltaSteps, ResidentsDetailsSteps, ResidentsUiAssertions } from 'src/steps/index.js';

export class ResidentsStepsFacade extends BaseSteps {
	public residentsDetailsSteps: ResidentsDetailsSteps;
	public censusDeltaSteps: ResidentsCensusDeltaSteps;
	public uiAssertions: ResidentsUiAssertions;

	constructor() {
		super();
		this.residentsDetailsSteps = new ResidentsDetailsSteps();
		this.censusDeltaSteps = new ResidentsCensusDeltaSteps();
		this.uiAssertions = new ResidentsUiAssertions();
	}
}
