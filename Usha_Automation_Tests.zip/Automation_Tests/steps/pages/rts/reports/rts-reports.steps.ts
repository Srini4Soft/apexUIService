import { RtsReportsPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class RtsReportsSteps extends BaseSteps {
	private pageRtsReports: RtsReportsPage;

	constructor() {
		super();
		this.pageRtsReports = new RtsReportsPage();
	}

	/* ACTIONS */
	public async openReport(number: number = 1): Promise<void> {
		await this.pageRtsReports.openReport(number);
		await this.waitForPageLoad();
	}

	/* ASSERTIONS */
}
