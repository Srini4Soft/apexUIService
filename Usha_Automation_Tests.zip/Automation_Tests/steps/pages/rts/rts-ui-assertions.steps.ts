import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import {
	RtsDashboardPage,
	RtsReferralsPage,
	RtsReportDetailsPage,
	RtsReportsPage,
	RtsRulesPage,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class RtsUiAssertions extends BaseSteps {
	private pageRtsDashboard: RtsDashboardPage;
	private pageRtsReferrals: RtsReferralsPage;
	private pageRtsReports: RtsReportsPage;
	private pageRtsReportDetails: RtsReportDetailsPage;
	private pageRtsRules: RtsRulesPage;

	constructor() {
		super();
		this.pageRtsDashboard = new RtsDashboardPage();
		this.pageRtsReferrals = new RtsReferralsPage();
		this.pageRtsReports = new RtsReportsPage();
		this.pageRtsReportDetails = new RtsReportDetailsPage();
		this.pageRtsRules = new RtsRulesPage();
	}

	/** DASHBOARD PAGE */
	public async verifyWidgetIsVisible(title: string) {
		expect(await this.pageRtsDashboard.isWidgetVisible(title), ErrorMessages.NO_WIDGET('New Leads')).toBe(true);
	}

	/** REFERRALS PAGE */
	public async verifyCreateReferralButtonIsVisible() {
		expect(
			await this.pageRtsReferrals.isCreateReferralButtonVisible(),
			ErrorMessages.NO_BUTTON('Create Referral')
		).toBe(true);
	}

	/** REPORTS PAGE */
	public async verifyReportsListIsVisible() {
		expect(await this.pageRtsReports.isReportsListVisible(), ErrorMessages.NO_ELEMENT('Reports List')).toBe(true);
	}

	public async verifyReportsTabIsVisible() {
		expect(await this.pageRtsReportDetails.isReportTabsVisible(), ErrorMessages.NO_ELEMENT('Report tabs')).toBe(true);
	}

	public async verifyViewReportButtonIsVisible() {
		expect(await this.pageRtsReportDetails.isViewReportButtonVisible(), ErrorMessages.NO_BUTTON('View Report')).toBe(
			true
		);
	}

	public async verifyReturnButtonIsVisible() {
		expect(await this.pageRtsReportDetails.isReturnButtonVisible(), ErrorMessages.NO_BUTTON('Return')).toBe(true);
	}

	/** RULES PAGE */
	public async verifyCreateRuleButtonIsVisible() {
		expect(await this.pageRtsRules.isCreateRuleButtonVisible(), ErrorMessages.NO_BUTTON('Create Rule')).toBe(true);
	}
}
