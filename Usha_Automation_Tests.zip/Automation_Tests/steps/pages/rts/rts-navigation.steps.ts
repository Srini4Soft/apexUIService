import { RtsDashboardPage, RtsLeadsPage, RtsReferralsPage, RtsReportsPage, RtsRulesPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class RtsNavigationSteps extends BaseSteps {
	public async openDashboardPage(): Promise<void> {
		await new RtsDashboardPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openReferralsPage(): Promise<void> {
		await new RtsReferralsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openReportsPage(): Promise<void> {
		await new RtsReportsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openRulesPage(): Promise<void> {
		await new RtsRulesPage().open();
		await this.comPageLoader.waitForPageLoad();
	}

	public async openLeadsPage(): Promise<void> {
		await new RtsLeadsPage().open();
		await this.comPageLoader.waitForPageLoad();
	}
}
