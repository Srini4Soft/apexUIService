import { BaseSteps } from 'src/steps/base.steps.js';
import {
	RtsDashboardSteps,
	RtsReferralsSteps,
	RtsReportsSteps,
	RtsRulesSteps,
	RtsUiAssertions,
} from 'src/steps/index.js';

export class RtsStepsFacade extends BaseSteps {
	public dashboardSteps: RtsDashboardSteps;
	public referralsSteps: RtsReferralsSteps;
	public reportsSteps: RtsReportsSteps;
	public rulesSteps: RtsRulesSteps;
	public uiAssertions: RtsUiAssertions;

	constructor() {
		super();
		this.dashboardSteps = new RtsDashboardSteps();
		this.referralsSteps = new RtsReferralsSteps();
		this.reportsSteps = new RtsReportsSteps();
		this.rulesSteps = new RtsRulesSteps();
		this.uiAssertions = new RtsUiAssertions();
	}
}
