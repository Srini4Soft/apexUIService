import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { IReferralCreate, IReferralDetails } from 'src/common/models/index.js';
import {
	RtsCreateReferralPage,
	RtsReferralDetailsPage,
	RtsReferralsPage,
	RtsReferralTabNotes,
} from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';

export class RtsReferralsSteps extends BaseSteps {
	private pageCreateReferral: RtsCreateReferralPage;
	private pageReferrals: RtsReferralsPage;
	private pageReferralDetails: RtsReferralDetailsPage;
	private pageNotes: RtsReferralTabNotes;

	constructor() {
		super();
		this.pageCreateReferral = new RtsCreateReferralPage();
		this.pageReferrals = new RtsReferralsPage();
		this.pageReferralDetails = new RtsReferralDetailsPage();
		this.pageNotes = new RtsReferralTabNotes();
	}

	public async fillNewReferralForm(data: IReferralCreate): Promise<void> {
		await this.pageReferrals.clickCreateReferralButton();
		if (data.facilityId) {
			await this.pageCreateReferral.fillFacilityField(data.facilityId);
		}

		if (data.ownerUserId) {
			await this.pageCreateReferral.fillOwnerField(data.ownerUserId);
		}

		if (data.lastName) {
			await this.pageCreateReferral.fillLastNameField(data.lastName);
		}

		if (data.firstName) {
			await this.pageCreateReferral.fillFirstNameField(data.firstName);
		}

		if (data.birthDate) {
			await this.pageCreateReferral.fillDobField(data.birthDate);
		}

		if (data.ssn) {
			await this.pageCreateReferral.fillSsnField(data.ssn);
		}

		if (data.medicareNumber) {
			await this.pageCreateReferral.fillMedicareField(data.medicareNumber);
		}

		if (data.medicaidNumber) {
			await this.pageCreateReferral.fillMedicaidField(data.medicaidNumber.state, data.medicaidNumber.number);
		}

		await this.pageCreateReferral.pressKeyboardButton('Tab');
		await this.waitForPageLoad();
	}

	public async createReferral(data: IReferralCreate): Promise<void> {
		await this.fillNewReferralForm(data);
		expect(await this.pageCreateReferral.isBannerVisible(), ErrorMessages.NO_BANNER('No resident was found')).toBe(
			true
		);
		await this.pageCreateReferral.clickCreateButton();
		await this.waitForPageLoad();
	}

	public async fillReferralDetailsForm(data: IReferralDetails): Promise<void> {
		await this.pageReferralDetails.clickReferralTab();

		if (data.ownerUserId) {
			await this.pageReferralDetails.pageReferral.fillOwnerField(data.ownerUserId);
		}

		if (data.caseStatusId) {
			await this.pageReferralDetails.pageReferral.fillCaseStatusField(data.caseStatusId);
		}

		if (data.prospectiveAdmissionDate) {
			await this.pageReferralDetails.pageReferral.fillProspectiveAdmissionDateField(data.prospectiveAdmissionDate);
		}

		if (data.admissionDate) {
			await this.pageReferralDetails.pageReferral.fillAdmissionDateField(data.admissionDate);
		}

		if (data.tenantEntityBedId) {
			await this.pageReferralDetails.pageReferral.fillBedField(data.tenantEntityBedId);
		}

		if (data.caseSourceId) {
			await this.pageReferralDetails.pageReferral.fillSourceField(data.caseSourceId);
		}

		if (data.caseSourceContactId) {
			await this.pageReferralDetails.pageReferral.fillSourceContactField(data.caseSourceContactId);
			await this.waitForPageLoad();
		}

		if (data.projectedDailyDrugCost) {
			await this.pageReferralDetails.pageReferral.fillDailyDrugCostField(data.projectedDailyDrugCost);
		}

		if (data.projectedDailyRehabCost) {
			await this.pageReferralDetails.pageReferral.fillDailyRehabCostField(data.projectedDailyRehabCost);
		}

		if (data.hospitalDates) {
			await this.pageReferralDetails.pageReferral.fillHospitalDatesField(data.hospitalDates[0], data.hospitalDates[1]);
		}

		if (data.firstName) {
			await this.pageReferralDetails.pageReferral.fillFirstNameField(data.firstName);
		}

		if (data.middleName) {
			await this.pageReferralDetails.pageReferral.fillMiddleNameField(data.middleName);
		}

		if (data.birthDate) {
			await this.pageReferralDetails.pageReferral.fillBirthDateField(data.birthDate);
		}

		if (data.gender) {
			await this.pageReferralDetails.pageReferral.fillGenderField(data.gender);
		}

		if (data.ssn) {
			await this.pageReferralDetails.pageReferral.fillSsnField(data.ssn);
		}

		if (data.medicareNumber) {
			await this.pageReferralDetails.pageReferral.fillMedicareNumberField(data.medicareNumber);
		}

		if (data.medicaidNumber) {
			await this.pageReferralDetails.pageReferral.fillMedicaidNumberField(data.medicaidNumber);
		}

		if (data.payerCategoryId) {
			await this.pageReferralDetails.pageReferral.fillPayerCategoryField(data.payerCategoryId);
		}
	}

	public async createReferralWithDetails(data: IReferralDetails): Promise<void> {
		await this.fillReferralDetailsForm(data);
		await this.pageReferralDetails.clickFinishButton();
		await this.waitForPageLoad();
	}

	public async finishReferralDetailsForm() {
		await this.pageReferralDetails.clickFinishButton();
		await this.waitForPageLoad();
	}

	public async saveReferralDetailsForm() {
		await this.pageReferralDetails.clickSaveButton();
		await this.waitForPageLoad();
	}

	public async reloadPage() {
		await this.pageReferralDetails.reloadPage();
		await this.waitForPageLoad();
	}

	public getReferralId(): string {
		const url: string = this.pageReferralDetails.getUrl();
		return url.match(/\/details\/(\d+)\//)?.[1] ?? '';
	}

	public async isCreateButtonEnabled(): Promise<boolean> {
		return await this.pageCreateReferral.isCreateButtonEnabled();
	}

	public async openRelatedCase(position: number = 1): Promise<void> {
		await this.pageReferralDetails.clickRelatedCasesButton();
		await this.waitForPageLoad();
		await this.pageReferralDetails.pageRelatedCases.clickOnRelatedCasesLink(position);
		await this.waitForPageLoad();
	}

	public async getNotes(): Promise<string[]> {
		await this.pageReferralDetails.clickNotesTab();
		await this.waitForPageLoad();
		return await this.pageReferralDetails.pageNotes.getNotesMessages();
	}
}
