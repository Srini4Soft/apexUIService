import { BaseSteps } from 'src/steps/base.steps.js';

export class RtsDashboardSteps extends BaseSteps {
	/**	ACTIONS	*/
	/* ASSERTIONS */
}
