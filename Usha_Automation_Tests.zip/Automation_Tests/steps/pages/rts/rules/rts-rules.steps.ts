import { RuleActions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import {
	IAddCaseNoteAction,
	IAddCasePayerAction,
	IAddCaseTagAction,
	IAddMedicaidApplicationAction,
	IAutomationRule,
	ICompleteTaskAction,
	ICreateTaskAction,
	ICreateWorkflowInstanceAction,
} from 'src/common/models/index.js';
import { RtsRulesPage } from 'src/pages/index.js';
import { BaseSteps } from 'src/steps/base.steps.js';
import { AutomationRuleSteps } from 'src/steps/index.js';

export class RtsRulesSteps extends BaseSteps {
	private pageRules: RtsRulesPage;
	private stepsAutomationRule: AutomationRuleSteps;

	constructor() {
		super();
		this.pageRules = new RtsRulesPage();
		this.stepsAutomationRule = new AutomationRuleSteps();
	}

	/* ACTIONS */
	public async openAutomationRulesTab(): Promise<void> {
		await test.step('Open "Automation Rules" tab', async () => {
			await this.pageRules.openAutomationRulesTab();
			await this.waitForPageLoad();
		});
	}

	public async openValidationRulesTab(): Promise<void> {
		await test.step('Open "Validation Rules" tab', async () => {
			await this.pageRules.openValidationRulesTab();
			await this.waitForPageLoad();
		});
	}

	public async openNriValidationRulesTab(): Promise<void> {
		await test.step('Open "Nri Validation Rules" tab', async () => {
			await this.pageRules.openNriValidationRulesTab();
			await this.waitForPageLoad();
		});
	}

	public async createRule(data: IAutomationRule): Promise<void> {
		await this.pageRules.clickCreateRuleButton();
		await this.stepsAutomationRule.fillCreateRuleForm(data);
		await this.stepsAutomationRule.clickCreateButton();
	}

	public async createRuleWithAction(
		ruleData: IAutomationRule,
		action: RuleActions,
		actionData: unknown
	): Promise<void> {
		await this.pageRules.clickCreateRuleButton();
		await this.stepsAutomationRule.fillCreateRuleForm(ruleData);
		await this.stepsAutomationRule.addActionOnSuccess();
		switch (action) {
			case RuleActions.ADD_CASE_NOTE:
				await this.stepsAutomationRule.actionAddCaseNote(actionData as IAddCaseNoteAction);
				break;
			case RuleActions.ADD_CASE_PAYER:
				await this.stepsAutomationRule.actionAddCasePayer(actionData as IAddCasePayerAction);
				break;
			case RuleActions.ADD_CASE_TAG:
				await this.stepsAutomationRule.actionAddCaseTag(actionData as IAddCaseTagAction);
				break;
			case RuleActions.ADD_MEDICAID_APPLICATION:
				await this.stepsAutomationRule.actionAddMedicaidApplication(actionData as IAddMedicaidApplicationAction);
				break;
			case RuleActions.CREATE_TASK:
				await this.stepsAutomationRule.actionCreateTask(actionData as ICreateTaskAction);
				break;
			case RuleActions.COMPLETE_TASK:
				await this.stepsAutomationRule.actionCompleteTask(actionData as ICompleteTaskAction);
				break;
			case RuleActions.CREATE_WORKFLOW_INSTANCE:
				await this.stepsAutomationRule.actionCreateWorkflowInstance(actionData as ICreateWorkflowInstanceAction);
				break;
		}

		await this.stepsAutomationRule.clickCreateButton();
	}

	/* ASSERTIONS */
}
