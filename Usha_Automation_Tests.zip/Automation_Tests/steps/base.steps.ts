import { PageLoaderComponent } from 'src/pages/components/index.js';

export abstract class BaseSteps {
	protected comPageLoader: PageLoaderComponent;

	constructor() {
		this.comPageLoader = new PageLoaderComponent();
	}

	public async waitForPageLoad(timeout?: number): Promise<void> {
		await this.comPageLoader.waitForPageLoad(timeout);
	}
}
