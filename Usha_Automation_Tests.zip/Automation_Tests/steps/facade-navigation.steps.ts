import { BaseSteps } from './base.steps.js';
import {
	BiNavigationSteps,
	CensusNavigationSteps,
	ResidentsNavigationSteps,
	RtsNavigationSteps,
	SettingsNavigationSteps,
	VerificationsNavigationSteps,
	VeripayNavigationSteps,
} from './index.js';

export class NavigationStepsFacade extends BaseSteps {
	public bi: BiNavigationSteps;
	public census: CensusNavigationSteps;
	public residents: ResidentsNavigationSteps;
	public rts: RtsNavigationSteps;
	public settings: SettingsNavigationSteps;
	public verifications: VerificationsNavigationSteps;
	public veripay: VeripayNavigationSteps;

	constructor() {
		super();
		this.bi = new BiNavigationSteps();
		this.census = new CensusNavigationSteps();
		this.residents = new ResidentsNavigationSteps();
		this.rts = new RtsNavigationSteps();
		this.settings = new SettingsNavigationSteps();
		this.verifications = new VerificationsNavigationSteps();
		this.veripay = new VeripayNavigationSteps();
	}
}
