import { BaseSteps } from './base.steps.js';
import {
	BiStepsFacade,
	CensusStepsFacade,
	ResidentsStepsFacade,
	RtsStepsFacade,
	SettingsStepsFacade,
	VerificationsStepsFacade,
	VeripayStepsFacade,
} from './index.js';

export class SectionStepsFacade extends BaseSteps {
	public bi: BiStepsFacade;
	public census: CensusStepsFacade;
	public residents: ResidentsStepsFacade;
	public rts: RtsStepsFacade;
	public settings: SettingsStepsFacade;
	public verifications: VerificationsStepsFacade;
	public veripay: VeripayStepsFacade;

	constructor() {
		super();
		this.bi = new BiStepsFacade();
		this.census = new CensusStepsFacade();
		this.residents = new ResidentsStepsFacade();
		this.rts = new RtsStepsFacade();
		this.settings = new SettingsStepsFacade();
		this.verifications = new VerificationsStepsFacade();
		this.veripay = new VeripayStepsFacade();
	}
}
