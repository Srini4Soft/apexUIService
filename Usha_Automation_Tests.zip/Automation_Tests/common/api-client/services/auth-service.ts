import { APIRequestContext, APIResponse } from '@playwright/test';
import log from 'src/common/utils/logger.js';
import { LoginInfo } from '../models/login-info.model.js';

export class AuthService {
	constructor(private request: APIRequestContext, private loginInfo: LoginInfo) {}

	public async getToken(): Promise<string> {
		log.info('Request token...');

		const formData = {
			client_id: this.loginInfo.clientId,
			client_secret: this.loginInfo.clientSecret,
			grant_type: 'password',
			username: this.loginInfo.username,
			password: this.loginInfo.password,
			scope: this.loginInfo.scope,
		};

		let response: APIResponse;

		try {
			response = await this.request.post(this.loginInfo.loginURL + 'connect/token', {
				form: formData,
			});
		} catch (error) {
			log.error('Network error while requesting token: ', error);
			throw error;
		}

		log.info(`Server response: ${response.status()} - ${response.statusText()}`);

		if (!response.ok()) {
			log.error('The server returned a failure status when receiving a token.');
			try {
				const errorBody = await response.text();
				log.error('Response body:', errorBody);
			} catch (error) {
				log.error('Failed to read response body.');
			}
			throw new Error(`Failed to get token. HTTP ${response.status()} - ${response.statusText()}`);
		}

		const data = await response.json();
		log.info('Token received successfully.');
		return data.access_token;
	}
}
