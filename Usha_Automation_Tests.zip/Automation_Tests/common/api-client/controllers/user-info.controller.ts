import log from 'src/common/utils/logger.js';
import { RequestModel } from '../models/request.model.js';
import { BaseController } from './base.controller.js';

interface UserInfoResponse {
	isSuccess: boolean;
	data: {
		user: {
			userId: number;
			domain?: string | null;
			username: string;
		};
		landingPageUrl?: string | null;
	};
	error?: any;
}

export class UserInfoController extends BaseController {
	public async getUserId(): Promise<number> {
		const request: RequestModel = {
			method: 'GET',
			url: this.loginInfo.baseURL + 'security/user-info',
		};

		let responseBody: UserInfoResponse;
		try {
			responseBody = await this.sendRequest<UserInfoResponse>(request);
		} catch (error) {
			log.error('Error while requesting user-info:', error);
			throw error;
		}

		if (!responseBody.isSuccess) {
			log.error('isSuccess=false in user-info response:', responseBody);
			throw new Error('Failed to receive user-info (isSuccess=false).');
		}

		if (!responseBody.data || !responseBody.data.user) {
			log.error('Incorrect structure of user-info response:', responseBody);
			throw new Error('Could not find user data in user-info response.');
		}

		const userId = responseBody.data.user.userId;
		log.info('Received userId:', userId);

		return userId;
	}
}
