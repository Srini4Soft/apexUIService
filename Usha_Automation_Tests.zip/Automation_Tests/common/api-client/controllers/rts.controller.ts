import { RequestModel } from '../models/request.model.js';
import { BaseController } from './base.controller.js';

export class RtsController extends BaseController {
	public async deleteReferral(referralId: number): Promise<void> {
		const request: RequestModel = {
			method: 'DELETE',
			url: this.loginInfo.baseURL + `referrals/referrals/details/${referralId}/referral`,
		};

		await this.sendRequest<void>(request);
	}
}
