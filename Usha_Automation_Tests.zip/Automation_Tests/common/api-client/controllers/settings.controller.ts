import { RequestModel } from '../models/request.model.js';
import { BaseController } from './base.controller.js';

export class SettingsController extends BaseController {
	public async deleteLookups(lookupIds: number[]): Promise<void> {
		const request: RequestModel<number[]> = {
			method: 'DELETE',
			url: this.loginInfo.baseURL + 'settings/lookups/list',
			body: lookupIds,
		};

		await this.sendRequest<void, number[]>(request);
	}

	public async deletePeople(peopleIds: number[]): Promise<void> {
		const request: RequestModel<number[]> = {
			method: 'DELETE',
			url: this.loginInfo.baseURL + 'settings/people/list',
			body: peopleIds,
		};

		await this.sendRequest<void, number[]>(request);
	}
}
