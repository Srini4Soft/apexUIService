import { APIRequestContext, APIResponse } from '@playwright/test';
import log from 'src/common/utils/logger.js';
import { apiRequestData, loginInfoDeploy } from 'src/playwright.config.js';
import { LoginInfo } from '../models/login-info.model.js';
import { RequestModel } from '../models/request.model.js';
import { AuthService } from '../services/auth-service.js';

export abstract class BaseController {
	protected loginInfo: LoginInfo;
	protected authService: AuthService;

	constructor(protected request: APIRequestContext) {
		this.loginInfo = {
			baseURL: apiRequestData.apiURL ?? '',
			loginURL: loginInfoDeploy.URL ?? '',
			clientId: apiRequestData.client_id ?? '',
			clientSecret: apiRequestData.client_secret ?? '',
			username: apiRequestData.username ?? '',
			password: apiRequestData.password ?? '',
			scope: apiRequestData.scope ?? '',
		};

		this.authService = new AuthService(request, this.loginInfo);
	}

	protected async sendRequest<TResponse = any, TBody = any>(requestModel: RequestModel<TBody>): Promise<TResponse> {
		let token: string;
		try {
			token = await this.authService.getToken();
		} catch (error) {
			log.error('Failed to obtain token, request will not be sent.');
			throw error;
		}

		const headers: Record<string, string> = {
			...requestModel.headers,
			Authorization: `Bearer ${token}`,
		};

		if (requestModel.body && !headers['Content-Type']) {
			headers['Content-Type'] = 'application/json';
		}

		log.info('Sending a request:', {
			method: requestModel.method,
			url: requestModel.url,
			headers,
			body: requestModel.body,
		});

		let response: APIResponse;
		try {
			switch (requestModel.method) {
				case 'POST':
					response = await this.request.post(requestModel.url, {
						headers,
						data: requestModel.body,
					});
					break;
				case 'PUT':
					response = await this.request.put(requestModel.url, {
						headers,
						data: requestModel.body,
					});
					break;
				case 'DELETE':
					response = await this.request.delete(requestModel.url, {
						headers,
						data: requestModel.body,
					});
					break;
				case 'PATCH':
					response = await this.request.patch(requestModel.url, {
						headers,
						data: requestModel.body,
					});
					break;
				default:
					response = await this.request.get(requestModel.url, {
						headers,
					});
					break;
			}
		} catch (error) {
			log.error('Network error or other problem sending request:', error);
			throw error;
		}

		log.info(`Response: ${response.status()} - ${response.statusText()}`);

		let responseBody: TResponse | string | null = null;
		try {
			responseBody = (await response.json()) as TResponse;
			log.info('Response body:', responseBody);
		} catch (error) {
			try {
				const textBody = await response.text();
				responseBody = textBody;
				log.info('Response body:', textBody);
			} catch (innerError) {
				log.warn('Failed to read response body:', innerError);
			}
		}

		if (!response.ok()) {
			log.error('Request failed.:', response.status(), response.statusText());
			throw new Error(
				`HTTP error: ${response.status()} - ${response.statusText()}\nBody: ${JSON.stringify(responseBody)}`
			);
		}

		return responseBody as TResponse;
	}
}
