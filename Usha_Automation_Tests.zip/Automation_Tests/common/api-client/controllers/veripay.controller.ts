import { IVeripayCase } from 'src/common/models/veripay-case.interface.js';
import log from 'src/common/utils/logger.js';
import { ICreateCaseResponse } from '../models/create-case-response.model.js';
import { RequestModel } from '../models/request.model.js';
import { BaseController } from './base.controller.js';
import { FacilityFilterController } from './facility-filter.controller.js';
import { UserInfoController } from './user-info.controller.js';

export class VeripayController extends BaseController {
	public async deleteRule(ruleId: string): Promise<void> {
		const request: RequestModel = {
			method: 'DELETE',
			url: this.loginInfo.baseURL + `rules/delete/${ruleId}`,
		};

		await this.sendRequest<void>(request);
	}

	public async deleteCase(caseId: string): Promise<void> {
		const request: RequestModel = {
			method: 'DELETE',
			url: this.loginInfo.baseURL + `veripay/cases/details/${caseId}/case`,
		};

		await this.sendRequest<void>(request);
	}

	public async createCase(newCase: IVeripayCase): Promise<number> {
		let ownerUserId: number;
		if (typeof newCase.ownerUserId === 'number') {
			ownerUserId = newCase.ownerUserId;
			log.info('Use passed ownerUserId:', ownerUserId);
		} else {
			const userInfoController = new UserInfoController(this.request);
			ownerUserId = await userInfoController.getUserId();
			log.info('OwnerUserId is retrieved from UserInfoController:', ownerUserId);
		}

		let facilityId: number;
		if (typeof newCase.facilityId === 'number') {
			facilityId = newCase.facilityId;
			log.info('Use passed facilityId:', facilityId);
		} else {
			const facilityName = newCase.facilityId!;
			const facilityFilterController = new FacilityFilterController(this.request);
			facilityId = await facilityFilterController.getFacilityIdByName(facilityName);
			log.info(`FacilityId=${facilityId} is retrieved for facilityName="${facilityName}"`);
		}

		const requestBody = {
			facilityId: facilityId,
			lastName: newCase.lastName,
			ssn: newCase.ssn,
			ownerUserId: ownerUserId,
		};

		const request: RequestModel<typeof requestBody> = {
			method: 'POST',
			url: this.loginInfo.baseURL + 'veripay/cases/create/new',
			body: requestBody,
			headers: {
				'Content-Type': 'application/json',
			},
		};

		log.info('Submitting a request to create a case:', requestBody);

		const response = await this.sendRequest<ICreateCaseResponse>(request);

		if (!response.isSuccess) {
			log.error('API response isSuccess=false when creating a case:', response);
			throw new Error('API response isSuccess=false when creating a case.');
		}

		log.info('The case was created successfully:', JSON.stringify(response));
		return response.data;
	}
}
