import log from 'src/common/utils/logger.js';
import { RequestModel } from '../models/request.model.js';
import { BaseController } from './base.controller.js';

interface FacilityFilterResponse {
	isSuccess: boolean;
	data: {
		facilities: FacilityNode[];
	};
	error?: any;
}

interface FacilityNode {
	id: number;
	name: string;
	code?: string | null;
	selected: boolean;
	children?: FacilityNode[];
}

export class FacilityFilterController extends BaseController {
	private async fetchFacilities(): Promise<FacilityNode[]> {
		const request: RequestModel = {
			method: 'GET',
			url: this.loginInfo.baseURL + 'facility-filter',
		};

		let response: FacilityFilterResponse;
		try {
			response = await this.sendRequest<FacilityFilterResponse>(request);
		} catch (error) {
			log.error('Error while requesting facility-filter:', error);
			throw error;
		}

		if (!response.isSuccess) {
			log.error('isSuccess=false in facility-filter response:', response);
			throw new Error('Failed to get list of facilities (isSuccess=false).');
		}

		if (!response.data || !Array.isArray(response.data.facilities)) {
			log.error('The facility-filter response does not have a facilities field or it is not an array:', response);
			throw new Error('Incorrect structure of facility-filter response.');
		}

		log.info('Number of facilities received:', response.data.facilities.length);
		return response.data.facilities;
	}

	public async getFacilityIdByName(facilityName: string): Promise<number> {
		const facilities = await this.fetchFacilities();

		function findFacilityIdByName(nodes: FacilityNode[], targetName: string): number | null {
			for (const node of nodes) {
				if (node.name === targetName) {
					return node.id;
				}
				if (node.children && node.children.length > 0) {
					const foundInChildren = findFacilityIdByName(node.children, targetName);
					if (foundInChildren !== null) {
						return foundInChildren;
					}
				}
			}
			return null;
		}

		const facilityId = findFacilityIdByName(facilities, facilityName);

		if (facilityId === null) {
			log.error(`Facility with name="${facilityName}" not found.`);
			throw new Error(`Facility "${facilityName}" not found in the list of facility-filter.`);
		}

		log.info(`Found facilityId=${facilityId} for name="${facilityName}"`);
		return facilityId;
	}

	public async getAllFacilities(): Promise<FacilityNode[]> {
		return await this.fetchFacilities();
	}
}
