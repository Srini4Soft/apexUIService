export interface RequestModel<T = any> {
	url: string;
	method: 'GET' | 'POST' | 'DELETE' | 'PUT' | 'PATCH';
	body?: T;
	headers?: Record<string, string>;
}
