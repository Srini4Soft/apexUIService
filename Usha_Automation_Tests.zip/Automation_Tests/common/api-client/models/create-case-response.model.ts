export interface ICreateCaseResponse {
	isSuccess: boolean;
	data: number;
	error?: any;
}
