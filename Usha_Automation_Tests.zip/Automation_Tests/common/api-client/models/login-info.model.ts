export interface LoginInfo {
	baseURL: string;
	loginURL: string;
	clientId: string;
	clientSecret: string;
	username: string;
	password: string;
	scope: string;
}
