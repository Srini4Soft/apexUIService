import { APIRequestContext } from '@playwright/test';
import { FacilityFilterController } from './controllers/facility-filter.controller.js';
import { RtsController } from './controllers/rts.controller.js';
import { SettingsController } from './controllers/settings.controller.js';
import { UserInfoController } from './controllers/user-info.controller.js';
import { VeripayController } from './controllers/veripay.controller.js';

export class ApiClient {
	public facilityFilter: FacilityFilterController;
	public rts: RtsController;
	public settings: SettingsController;
	public userInfo: UserInfoController;
	public veripay: VeripayController;

	constructor(private request: APIRequestContext) {
		this.facilityFilter = new FacilityFilterController(request);
		this.rts = new RtsController(request);
		this.settings = new SettingsController(request);
		this.userInfo = new UserInfoController(request);
		this.veripay = new VeripayController(request);
	}
}
