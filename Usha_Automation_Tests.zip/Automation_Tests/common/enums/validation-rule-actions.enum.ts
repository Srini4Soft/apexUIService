export enum ValidationRuleActions {
	HIDDEN = 'Hidden',
	READONLY = 'Readonly',
	REQUIRED = 'Required',
	NOT_REQUIRED = 'Not Required',
	SET_VALUE = 'Set Value',
	WARNING = 'Warning',
}
