export enum SortingOrder {
	ASCENDING = 'sort-up',
	DESCENDING = 'sort-down',
}
