export enum PageSize {
	SIZE_10 = 10,
	SIZE_25 = 25,
	SIZE_50 = 50,
	SIZE_100 = 100,
	SIZE_500 = 500,
}
