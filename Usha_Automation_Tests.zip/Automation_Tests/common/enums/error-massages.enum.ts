export const ErrorMessages = {
	COMPARE_VALUES: (actual: string, expected: string) =>
		`Actual value "${actual}" should match the expected value "${expected}"`,
	BLANK_VALUE: (tmp: string) => `${tmp} is blank`,
	NO_MATCH_PATTERN: (tmp: string) => `${tmp} does not match pattern`,
	NO_BANNER: (tmp: string) => `Banner "${tmp}" is not displayed`,

	// PAGE LOAD
	PAGE_STUCK: 'The page loads longer than the time specified in the test',

	// GRID
	NO_COLUMN: (tmp: string) => `Grid does not contain column: '${tmp}'`,
	EXTRA_COLUMN: (tmp: string) => `Grid contains an extra column: '${tmp}'`,
	GRID_SAME_COLUMNS: 'The grid should display the required columns',
	GRID_IS_EMPTY: 'The table does not contain any records',
	GRID_IS_NOT_EMPTY: 'The table contains records',
	NO_CREATE_BTN: 'Create button should be visible',
	NO_TOOLBAR: 'Toolbar should be visible',
	NO_TOOLBAR_MENU_BTN: 'Toolbar menu button should be visible',
	NO_TOOLBAR_SEARCH_BTN: 'Toolbar search button should be visible',
	NO_TOOLBAR_RESET_BTN: 'Toolbar reset filters button should be visible',
	NO_TOOLBAR_TITLE: 'Toolbar title button should be visible',
	NO_TABLE: 'Table should be visible',
	NO_TABLE_SELECT_ALL_BTN: 'Table select all button should be visible',
	NO_PAGER: 'Pager should be visible',
	NO_PAGER_PAGE_SIZE_SELECTOR: 'Page size selector should be visible',
	NO_PAGER_PREVIOUS_PAGE_BTN: 'Pager previous page button should be visible',
	NO_PAGER_LIST_OF_PAGES: 'Pager pages list should be visible',
	NO_PAGER_NEXT_PAGE_BTN: 'Pager next page button should be visible',

	// CONSOLE
	ERRORS_IN_CONSOLE: 'There are errors in console',

	// GRID FILTERS
	ROWS_NUMBER_DIFFER: 'The number of records in the table should differ',
	ROWS_NUMBER_SAME: 'The number of records in the table should be the same',
	ROWS_NUMBER_LESS_THEN_BEFORE: 'The number of records should be less than before filtering',
	ROWS_NUMBER_ONE: 'The number of records must be equal to one',
	CELL_VALUE_EXPECTED: 'The cell should contain the expected value',

	// BREADCRUMBS
	NO_BREADCRUMBS_ELEMENT: 'Breadcrumbs element is not visible',
	NO_BREADCRUMBS_ITEM: 'Breadcrumbs item is not visible',

	// TIME PERIOD
	NO_IN_TIME_PERIOD: 'The date must be within the expected period',

	// ELEMENTS
	NO_ELEMENT: (tmp: string) => `Element '${tmp}' is not visible`,
	NO_BUTTON: (tmp: string) => `Button '${tmp}' is not visible`,
	NO_WIDGET: (tmp: string) => `Widget '${tmp}' is not visible`,
	NOT_ENABLED: (tmp: string) => `Element '${tmp}' is disabled`,
};
