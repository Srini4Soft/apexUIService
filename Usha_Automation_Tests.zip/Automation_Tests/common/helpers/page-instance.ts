import { Page } from '@playwright/test';

/**
 * Singleton wrapper for managing the Playwright Page instance.
 */
export class PageInstance {
	private static instance: PageInstance;
	private page!: Page;

	private constructor() {}

	/**
	 * Retrieves the singleton instance of PageInstance.
	 * @returns The singleton PageInstance.
	 */
	public static getInstance(): PageInstance {
		return (PageInstance.instance ??= new PageInstance());
	}

	/**
	 * Sets the Playwright page instance.
	 * @param page - The Playwright Page instance to set.
	 */
	public setPage(page: Page): void {
		this.page = page;
	}

	/**
	 * Gets the Playwright page instance. Throws an error if the page is not set.
	 * @returns The Playwright Page instance.
	 */
	public getPage(): Page {
		if (!this.page) {
			throw new Error('Page is not set!');
		}
		return this.page;
	}

	/**
	 * Closes the Playwright page instance.
	 */
	public async closePage(): Promise<void> {
		if (this.page) {
			await this.page.close();
		}
	}
}
