import { test as baseTest, expect, Page } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import log from 'src/common/utils/logger.js';
import { loginInfoDeploy } from 'src/playwright.config.js';

const users: string[] = ['AlexVovk1', 'AlexVovk2'];
const AUTH_DIR = '.auth';
const WAIT_MULTIPLIER = 8000;

export * from '@playwright/test';

// Utility to resolve auth file path
const getAuthFilePath = (id: number, outputDir: string): string => {
	return path.resolve(outputDir, `${AUTH_DIR}/${id}.json`);
};

// Utility to check if auth file exists
const authFileExists = (authFile: string): boolean => {
	return fs.existsSync(authFile);
};

// Perform login and save the state
const loginAndSaveState = async (page: Page, username: string, authFile: string): Promise<void> => {
	log.info(`Open login page "${loginInfoDeploy.URL}" and save the login state`);
	log.info(`Login as "${username}"`);
	log.info(`Run tests against "${loginInfoDeploy.baseURL}" environment`);

	await page.goto(loginInfoDeploy.URL);
	await page.locator('//input[@id="Username"]').fill(username);
	await page.locator('//input[@id="Password"]').fill(loginInfoDeploy.password);
	await page.locator('//button[@type="submit"]').click();
	await page.waitForLoadState('load');

	await expect(page.locator('amp-spinner')).toBeHidden();
	await expect(page.locator('amp-spinner:visible')).toHaveCount(0);

	await page.context().storageState({ path: authFile });
};

export const test = baseTest.extend<{}, { workerStorageState: string }>({
	storageState: ({ workerStorageState }, use) => use(workerStorageState),

	workerStorageState: [
		async ({ browser }, use) => {
			const id: number = test.info().parallelIndex;
			const authFile = getAuthFilePath(id, test.info().project.outputDir);

			if (authFileExists(authFile)) {
				await use(authFile);
				return;
			}

			const username = users[id];
			if (username) {
				const page = await browser.newPage({ storageState: undefined });
				await page.waitForTimeout(id * WAIT_MULTIPLIER);

				await loginAndSaveState(page, username, authFile);

				await page.close();
				await use(authFile);
			} else {
				throw new Error(`No username found for id: ${id}`);
			}
		},
		{ scope: 'worker' },
	],
});
