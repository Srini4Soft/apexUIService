import fsPromises from 'fs/promises';
import path from 'path';
import log from './logger.js';

export class CsvUtils {
	static async getHeaderColumns(csvFilePath: string): Promise<string[]> {
		try {
			await fsPromises.access(csvFilePath);
			const raw = await fsPromises.readFile(csvFilePath, 'utf8');
			const firstLine = raw.split(/\r?\n/, 1)[0]!.replace(/^\uFEFF/, '');
			const quotedMatches = [...firstLine.matchAll(/"([^"]*)"/g)];
			const headers = quotedMatches.length
				? quotedMatches.map((m) => m[1]!.trim())
				: firstLine.split(',').map((h) => h.trim());
			return headers;
		} catch (err: unknown) {
			const filename = path.basename(csvFilePath);
			if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
				log.error(`File not found: ${csvFilePath}`);
			} else {
				log.error(`Failed to read or parse ${filename}:`, err);
			}

			throw err;
		}
	}

	static async getRowCount(csvFilePath: string): Promise<number> {
		try {
			await fsPromises.access(csvFilePath);
			const raw = await fsPromises.readFile(csvFilePath, 'utf8').then(
				(buf) => buf.replace(/^\uFEFF/, '') // убираем BOM
			);

			let rows = 0;
			let inQuotes = false;

			for (let i = 0; i < raw.length; i++) {
				const ch = raw[i];
				if (ch === '"') {
					if (inQuotes && raw[i + 1] === '"') {
						i++;
					} else {
						inQuotes = !inQuotes;
					}
					continue;
				}

				if (!inQuotes && (ch === '\n' || ch === '\r')) {
					rows++;
					if (ch === '\r' && raw[i + 1] === '\n') i++;
				}
			}

			if (raw.length && !raw.endsWith('\n') && !raw.endsWith('\r')) rows++;

			log.info(`Found ${rows} rows in CSV file`);
			return rows;
		} catch (err: unknown) {
			const filename = path.basename(csvFilePath);
			if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
				log.error(`File not found: ${csvFilePath}`);
			} else {
				log.error(`Failed to count rows in ${filename}:`, err);
			}
			throw err;
		}
	}
}
