export interface ILookup {
	name?: string;
	lookupNamespaceId?: string;
	code?: string;
	isApproved?: boolean;
	isGlobal?: boolean;
	facilityIds?: string;
	displayColorId?: string;
}
