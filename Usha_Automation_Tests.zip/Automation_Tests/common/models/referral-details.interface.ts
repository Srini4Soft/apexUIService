export interface IReferralDetails {
	/* REFERRAL TAB */
	// Main section
	ownerUserId?: string;
	receivedDate?: string;
	caseStatusId?: string;
	prospectiveAdmissionDate?: string;
	tenantEntityBedId?: string;
	isReadmission?: boolean;
	admissionDate?: string;
	caseSourceId?: string;
	caseSourceContactId?: string;
	hospitalDates?: [string, string];
	projectedDailyDrugCost?: string;
	projectedDailyRehabCost?: string;
	// Demographics section
	firstName?: string;
	lastName?: string;
	middleName?: string;
	birthDate?: string;
	gender?: string;
	ssn?: string;
	medicareNumber?: string;
	medicaidNumber?: string;
	// Payer Info section
	payerCategoryId?: string;
	/* TAB */
}
