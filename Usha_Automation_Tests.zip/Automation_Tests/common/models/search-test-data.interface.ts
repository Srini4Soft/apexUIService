export interface ISearchTestData {
	columnDefinitionName: string;
	searchValue?: string;
}
