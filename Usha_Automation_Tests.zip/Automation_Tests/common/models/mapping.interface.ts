export interface IMapping {
	mappingTypeId?: string;
	sourceSystemId?: string;
	input?: string;
	output?: string;
	description?: string;
	startDate?: string;
	endDate?: string;
	organizationType?: string;
	organizationId?: string;
	isDisabled?: boolean;
	isGlobal?: boolean;
	tenantEntityId?: string;
}
