export interface ICreateTaskAction {
	title: string;
	lookupTaskCategoryId: string;
}
