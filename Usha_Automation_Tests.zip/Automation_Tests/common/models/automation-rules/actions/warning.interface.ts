export interface IWarningAction {
	message?: string;
}
