export interface IRequiredAction {
	message?: string;
	targetElement?: string;
	targetModal?: string;
	overriddenGroupIds?: string;
	overriddenUserIds?: string;
}
