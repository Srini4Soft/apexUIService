export interface ICompleteTaskAction {
	scope?: string;
	targetValuePath?: string[];
}
