export interface ISetValueValidationAction {
	type?: string;
	valueSourceType?: string;
	dateOperator?: string;
	value?: string;
}
