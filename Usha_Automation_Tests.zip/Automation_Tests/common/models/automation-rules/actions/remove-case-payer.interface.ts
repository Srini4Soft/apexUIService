export interface IRemoveCasePayerAction {
	payerPeriod?: string;
	payerCategory?: string;
}
