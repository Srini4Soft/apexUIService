export interface ICaseTrackingStatusTypeAction {
	caseTrackingStatusType: string;
}
