export interface IAddCaseNoteAction {
	message: string;
	isAggregateMessage: boolean;
}
