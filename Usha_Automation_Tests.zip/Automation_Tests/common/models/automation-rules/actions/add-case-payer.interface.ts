export interface IAddCasePayerAction {
	allowMultipleExecution?: boolean;
	payerRole?: string;
	payerCategory: string;
	effectiveDateInput?: string;
	effectiveDateDropDown?: string;
	effectiveDateProperty?: string;
}
