export interface IAddCaseTagAction {
	scope: string;
	lookupId: string;
}
