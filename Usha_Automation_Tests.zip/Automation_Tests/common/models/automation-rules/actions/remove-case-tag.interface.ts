export interface IRemoveCaseTagAction {
	scope?: string;
	lookupId?: string;
}
