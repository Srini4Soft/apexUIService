export interface ICreateWorkflowInstanceAction {
	workflowDefinitionId: string;
}
