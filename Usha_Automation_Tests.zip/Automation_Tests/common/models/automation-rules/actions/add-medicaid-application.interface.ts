export interface IAddMedicaidApplicationAction {
	allowMultipleExecution?: boolean;
	changePreviusStatusToStatusId?: string;
}
