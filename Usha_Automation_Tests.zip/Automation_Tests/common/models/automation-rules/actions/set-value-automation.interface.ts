export interface ISetValueAutomationAction {
	targetValuePath?: string[];
	valueSourceType?: string;
	dateOperator?: string;
	value?: string;
}
