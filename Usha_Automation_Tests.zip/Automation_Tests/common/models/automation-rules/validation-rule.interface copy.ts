export interface IValidationRule {
	name?: string;
	targetProperties?: string[];
	entityTypeId?: string;
	order?: number;
	isEnabled?: boolean;
	isGlobal?: boolean;
	condition?: {
		propertyName?: string[];
		comparisonPredicate?: string;
		value?: boolean;
		field?: boolean;
		comparisonValue?: string;
	};
}
