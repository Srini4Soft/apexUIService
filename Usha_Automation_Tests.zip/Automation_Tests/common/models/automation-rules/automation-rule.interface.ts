export interface IAutomationRule {
	name?: string;
	entityTypeId?: string;
	targetProperties?: string[];
	order?: number;
	isEnabled?: boolean;
	isGlobal?: boolean;
	condition?: {
		propertyName?: string[];
		comparisonPredicate?: string;
		value?: boolean;
		field?: boolean;
		comparisonValue?: string;
	};
}
