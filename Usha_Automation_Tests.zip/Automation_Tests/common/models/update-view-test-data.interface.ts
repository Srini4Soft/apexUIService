export interface IUpdateViewTestData {
	oldName: string;
	newName: string;
}
