export interface IRule {
	ruleName?: string;
	facilities?: string;
	eventTypes?: string;
	global?: boolean;
	enabled?: boolean;
	skipSending?: boolean;
	groups?: string;
	facilityContactTypes?: string;
	users?: string;
	emails?: string;
	recipientUsers?: boolean;
	sendSingleEmail?: boolean;
	includeInitiator?: boolean;
	excludeInitiator?: boolean;
	digestOfNotifications?: boolean;
	recipientGroupType?: string;
	eventsThreshold?: string;
	schedule?: boolean;
	actions?: {
		method: string;
		template: string;
	};
}
