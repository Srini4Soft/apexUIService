export interface IPayer {
	payerCategoryId?: string;
	name?: string;
	primaryPayerId?: string;
	description?: string;
	isGlobal?: boolean;
	canBePrimary?: boolean;
	canBeAncillary?: boolean;
	canBeCoinsurance?: boolean;
	eligibilityProviderKey?: string;
	primaryStateId?: string;
	dischargeBillingType?: string;
	requiresAuthorization?: boolean;
	simplifiedAuthorization?: boolean;
	verificationDefaultStartType?: string;
	isPending?: boolean;
	isReviewed?: boolean;
	reviewedOn?: string;
}
