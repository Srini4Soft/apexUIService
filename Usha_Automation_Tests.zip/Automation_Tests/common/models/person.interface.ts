export interface IPerson {
	facilityIds?: string;
	type?: string;
	lastName?: string;
	firstName?: string;
	middleName?: string;
	gender?: string;
	birthDate?: string;
	isApproved?: boolean;
	isGlobal?: boolean;
	speciality?: string;
	npi?: string;
	addressLine1?: string;
	addressLine2?: string;
	city?: string;
	stateId?: string;
	zipCode?: string;
	countyId?: string;
	email?: string;
	workPhoneNumber?: string;
	workPhoneNumberExt?: string;
	mobilePhoneNumber?: string;
	homePhoneNumber?: string;
	faxNumber?: string;
	userId?: string;
	employeeStartDate?: string;
	location?: string;
	organizations?: {
		organizationId: string;
		lookupPositionId: string;
	};
}
