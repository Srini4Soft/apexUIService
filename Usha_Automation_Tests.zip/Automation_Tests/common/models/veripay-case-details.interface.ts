export interface IVeripayCaseDetails {
	// Case section
	dischargeDate?: string;
	// Payer Information section
	effectiveDate?: string;
	payerCategoryId?: string;

	// Preadmission Screening and Resident Review section
	authorizationNumber?: string;
}
