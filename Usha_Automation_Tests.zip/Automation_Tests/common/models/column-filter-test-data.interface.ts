export interface IColumnFilterTestData {
	columnDefinitionName: string;
	columnsToDisplay: string[];
	filterTitle: string;
	filterType?: 'filter-column-filled' | 'eye';
	filterValue?: string;
	filterValues?: string[];
	textNodeIndex: number | undefined;
	expectedValue?: string;
	expectedPattern?: RegExp; // Need to check the value for compliance with the pattern
	expectedIcon?: boolean; // Need to check the icon
	sortingColumn?: string; // Use in case "columnDefinitionName" is not sortable
	columnForCheck?: string; // Use in case you need to verify another column
}
