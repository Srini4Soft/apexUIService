export interface ICondition {
	propertyName?: string[];
	comparisonPredicate?: string;
	value?: boolean;
	field?: boolean;
	comparisonValue?: string;
}
