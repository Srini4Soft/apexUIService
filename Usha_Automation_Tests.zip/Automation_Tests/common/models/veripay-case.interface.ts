export interface IVeripayCase {
	facilityId?: number | string;
	ownerUserId?: number | string;
	lastName?: string;
	firstName?: string;
	birthDate?: string;
	ssn?: string;
	medicareNumber?: string;
	medicaidNumber?: string;
}
