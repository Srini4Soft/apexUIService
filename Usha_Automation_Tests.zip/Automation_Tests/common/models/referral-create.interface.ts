export interface IReferralCreate {
	facilityId: string;
	ownerUserId?: string;
	lastName: string;
	firstName?: string;
	birthDate?: string;
	ssn?: string;
	medicareNumber?: string;
	medicaidNumber?: {
		state: string;
		number: string;
	};
}
