export interface ISaveViewTestData {
	viewName: string;
	columnsToDisplay: string[];
	columnDefinitionName: string;
	filterValue: string[];
}
