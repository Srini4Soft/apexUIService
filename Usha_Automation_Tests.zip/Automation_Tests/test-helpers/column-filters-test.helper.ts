import { expect } from '@playwright/test';
import { DateRange, ErrorMessages, FilterConditions, SortingOrder } from 'src/common/enums/index.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { ColumnFiltersSteps, GridSteps } from 'src/steps/index.js';

export async function testTextFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const recordsBeforeFiltering = await stepsGrid.getTotalRecordCount();
	let filterValue: string = '';
	let recordsActual: number = 0;
	if (!testData.filterValue) {
		await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
		await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.NOT_BLANK);
		await stepsColumnFilters.applyFilter();
		const initialCellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
		filterValue = initialCellValues[0]?.[testData.textNodeIndex!] ?? '';
	} else {
		filterValue = testData.filterValue;
	}
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;

	// EQUALS Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.EQUALS, filterValue);
	await stepsColumnFilters.applyFilter();
	let cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, testData.textNodeIndex);

	// EQUALS Assert
	cellValues.forEach((array, rowIndex) => {
		const normalized = array.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${array.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});

	// DOES_NOT_EQUAL Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_EQUAL, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_EQUAL Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// CONTAINS Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.CONTAINS, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, testData.textNodeIndex);

	// CONTAINS Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		const hasPartialMatch = array.some((v) => v.trim().toLowerCase().includes(expected));
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});

	// DOES_NOT_CONTAIN Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_CONTAIN, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_CONTAIN Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// STARTS_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.STARTS_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, testData.textNodeIndex);

	// STARTS_WITH Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		const hasPartialMatch = array.some((v) => v.trim().toLowerCase().includes(expected));
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});

	// DOES_NOT_START_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_START_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_START_WITH Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// ENDS_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.ENDS_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, testData.textNodeIndex);

	// ENDS_WITH Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		const hasPartialMatch = array.some((v) => v.trim().toLowerCase().includes(expected));
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});
}

export async function testTextNameFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const recordsBeforeFiltering = await stepsGrid.getTotalRecordCount();
	let filterValue: string = testData.filterValue!;
	let recordsActual: number = 0;
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;

	// EQUALS Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.EQUALS, filterValue);
	await stepsColumnFilters.applyFilter();
	let cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);

	// EQUALS Assert
	cellValues.forEach((array, rowIndex) => {
		const normalized = array.flatMap((v) => v.split(',').map((item) => item.trim().toLowerCase()));
		expect
			.soft(
				normalized[testData.textNodeIndex!],
				`Row ${rowIndex}: none of the values [${array.join(', ')}] match expected value "${expectedValue}"`
			)
			.toBe(expectedValue.trim().toLowerCase());
	});

	// DOES_NOT_EQUAL Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_EQUAL, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_EQUAL Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// CONTAINS Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.CONTAINS, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);

	// CONTAINS Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		const normalized = array.flatMap((v) => v.split(',').map((item) => item.trim().toLowerCase()));
		const targetElement = normalized[testData.textNodeIndex!];
		const hasPartialMatch = targetElement!.includes(expected);
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});

	// DOES_NOT_CONTAIN Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_CONTAIN, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_CONTAIN Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// STARTS_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.STARTS_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);
	log.debug(JSON.stringify(cellValues));

	// STARTS_WITH Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		log.debug(`expected: ${expected}`);
		const normalized = array.flatMap((v) => v.split(',').map((item) => item.trim().toLowerCase()));
		log.debug(`normalized: ${JSON.stringify(normalized)}`);
		const targetElement = normalized[testData.textNodeIndex!];
		log.debug(`targetElement: ${targetElement}`);
		const hasPartialMatch = targetElement!.includes(expected);
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});

	// DOES_NOT_START_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.DOES_NOT_START_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	recordsActual = await stepsGrid.getTotalRecordCount();

	// DOES_NOT_START_WITH Assert
	expect.soft(recordsActual, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeFiltering);

	// ENDS_WITH Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillTextFilter(testData.filterTitle, FilterConditions.ENDS_WITH, filterValue);
	await stepsColumnFilters.applyFilter();
	cellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);

	// ENDS_WITH Assert
	cellValues.forEach((array, rowIndex) => {
		const expected = expectedValue.trim().toLowerCase();
		const normalized = array.flatMap((v) => v.split(',').map((item) => item.trim().toLowerCase()));
		const targetElement = normalized[testData.textNodeIndex!];
		const hasPartialMatch = targetElement!.includes(expected);
		expect
			.soft(hasPartialMatch, `Row ${rowIndex}: none of the values [${array.join(', ')}] contain "${expectedValue}"`)
			.toBe(true);
	});
}

export async function testNumberFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const recordsBeforeFiltering = await stepsGrid.getTotalRecordCount();
	let filteredCellValues,
		filteredCellValuesDesSorting,
		filteredCellValuesAscSorting: string[][] = [];
	let filterValue: number = 0;
	if (!testData.filterValue) {
		await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
		await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.GREATER_THEN, 0);
		await stepsColumnFilters.applyFilter();
		const initialCellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
		filterValue = Number(initialCellValues[0]?.[testData.textNodeIndex!]?.replace(/[^0-9.-]+/g, '') ?? 0);
	} else {
		filterValue = Number(testData.filterValue);
	}
	const expectedValue = testData.expectedValue ? Number(testData.expectedValue) : filterValue;

	// EQUALS Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.EQUALS, filterValue);
	await stepsColumnFilters.applyFilter();
	filteredCellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// EQUALS Assert
	expect(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(
		recordsBeforeFiltering
	);
	filteredCellValues.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${array[testData.textNodeIndex!]}" should match the expected value "${expectedValue}"`
			)
			.toBe(expectedValue)
	);

	// DOES_NOT_EQUAL Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.DOES_NOT_EQUAL, expectedValue);
	await stepsColumnFilters.applyFilter();

	// DOES_NOT_EQUAL Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThan(recordsBeforeFiltering);

	// LESS_THEN Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.LESS_THEN, expectedValue);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// LESS_THEN Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThan(recordsBeforeFiltering);
	filteredCellValuesDesSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${array[testData.textNodeIndex!]}" should be less then expected value "${expectedValue}"`
			)
			.toBeLessThan(expectedValue)
	);
	filteredCellValuesAscSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${array[testData.textNodeIndex!]}" should be less then expected value "${expectedValue}"`
			)
			.toBeLessThan(expectedValue)
	);

	// LESS_THEN_OR_EQUAL Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.LESS_THEN_OR_EQUAL, expectedValue);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// LESS_THEN_OR_EQUAL Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThanOrEqual(recordsBeforeFiltering);
	filteredCellValuesDesSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${
					array[testData.textNodeIndex!]
				}" should be less or equal then expected value "${expectedValue}"`
			)
			.toBeLessThanOrEqual(expectedValue)
	);
	filteredCellValuesAscSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${
					array[testData.textNodeIndex!]
				}" should be less or equal then expected value "${expectedValue}"`
			)
			.toBeLessThanOrEqual(expectedValue)
	);

	// GREATER_THEN Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.GREATER_THEN, expectedValue);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// GREATER_THEN Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThan(recordsBeforeFiltering);
	filteredCellValuesDesSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${array[testData.textNodeIndex!]}" should be greater then expected value "${expectedValue}"`
			)
			.toBeGreaterThan(expectedValue - 1)
	);
	filteredCellValuesAscSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${array[testData.textNodeIndex!]}" should be greater then expected value "${expectedValue}"`
			)
			.toBeGreaterThan(expectedValue - 1)
	);

	// GREATER_THEN_OR_EQUAL Act
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(
		testData.filterTitle,
		FilterConditions.GREATER_THEN_OR_EQUAL,
		expectedValue
	);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// GREATER_THEN_OR_EQUAL Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThanOrEqual(recordsBeforeFiltering);
	filteredCellValuesDesSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${
					array[testData.textNodeIndex!]
				}" should be greater or equal then expected value "${expectedValue}"`
			)
			.toBeGreaterThanOrEqual(expectedValue)
	);
	filteredCellValuesAscSorting.forEach((array) =>
		expect
			.soft(
				parseFinancialNumber(array[testData.textNodeIndex!]!),
				`Actual value "${
					array[testData.textNodeIndex!]
				}" should be greater or equal then expected value "${expectedValue}"`
			)
			.toBeGreaterThanOrEqual(expectedValue)
	);

	// BETWEEN Act
	const minValue = expectedValue - 2;
	const maxValue = expectedValue;
	await stepsGrid.resetGridFilters();
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillNumberFilter(testData.filterTitle, FilterConditions.BETWEEN, minValue, maxValue);
	await stepsColumnFilters.applyFilter();
	filteredCellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// BETWEEN Assert
	expect
		.soft(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE)
		.toBeLessThanOrEqual(recordsBeforeFiltering);
	filteredCellValues.forEach((array, index) => {
		const actualValue = Number(array[testData.textNodeIndex!]?.replace(/[^0-9.-]+/g, ''));
		expect
			.soft(
				actualValue,
				`Value at index ${index} ("${actualValue}") is not in the range between ${minValue} and ${maxValue}`
			)
			.toBeGreaterThanOrEqual(minValue);

		expect
			.soft(
				actualValue,
				`Value at index ${index} ("${actualValue}") is not in the range between ${minValue} and ${maxValue}`
			)
			.toBeLessThanOrEqual(maxValue);
	});
}

export async function testEnumCheckboxFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;
	const targetColumn = testData.columnForCheck ? testData.columnForCheck : testData.columnDefinitionName;
	let filteredCellValuesDesSorting: string[][] = [];
	let filteredCellValuesAscSorting: string[][] = [];
	let filteredCellIconsDesSorting: string[][][] = [];
	let filteredCellIconsAscSorting: string[][][] = [];

	// Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillEnumCheckboxFilter(testData.filterTitle, [filterValue]);
	await stepsColumnFilters.applyFilter();

	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.DESCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	}

	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsDesSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesDesSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}

	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.ASCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	}

	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsAscSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesAscSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}

	// Assert
	if (testData.expectedIcon) {
		if (testData.columnDefinitionName == 'tasks') {
			filteredCellIconsDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellIconsAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
		} else {
			filteredCellValuesDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellValuesAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
		}
	} else if (testData.expectedPattern) {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
	} else {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
	}
}

export async function testCheckboxListFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;
	const targetColumn = testData.columnForCheck ? testData.columnForCheck : testData.columnDefinitionName;
	let filteredCellValuesDesSorting: string[][] = [];
	let filteredCellValuesAscSorting: string[][] = [];
	let filteredCellIconsDesSorting: string[][][] = [];
	let filteredCellIconsAscSorting: string[][][] = [];
	// Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillCheckboxListFilter(testData.filterTitle, [filterValue]);
	await stepsColumnFilters.applyFilter();
	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.DESCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	}
	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsDesSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesDesSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}
	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.ASCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	}
	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsAscSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesAscSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}
	// Assert
	if (testData.expectedIcon) {
		if (testData.columnDefinitionName == 'tasks') {
			filteredCellIconsDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellIconsAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
		} else {
			filteredCellValuesDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellValuesAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
		}
	} else if (testData.expectedPattern) {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
	} else {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
	}
}

export async function testMultiEnumCheckboxFilter(testData: IColumnFilterTestData) {
	// Arrange
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;

	// Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillMultiEnumCheckboxFilter(testData.filterTitle, [filterValue]);
	await stepsColumnFilters.applyFilter();
	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.DESCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	}
	const filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.ASCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	}
	const filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// Assert
	filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
	filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
}

export async function testEnumRadioFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;

	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillEnumRadioFilter(testData.filterTitle, filterValue);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// Assert
	if (testData.expectedPattern) {
		expect(filteredCellValuesDesSorting.every((value) => testData.expectedPattern!.test(value[0]!))).toBe(true);
		expect(filteredCellValuesAscSorting.every((value) => testData.expectedPattern!.test(value[0]!))).toBe(true);
		return;
	}
	filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
	filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
}

export async function testEnumDropdownFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;

	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillEnumDropdownFilter(testData.filterTitle, filterValue);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);

	// Assert
	if (testData.expectedPattern) {
		expect(filteredCellValuesDesSorting.every((value) => testData.expectedPattern!.test(value[0]!))).toBe(true);
		expect(filteredCellValuesAscSorting.every((value) => testData.expectedPattern!.test(value[0]!))).toBe(true);
		return;
	}
	filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
	filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
		const normalized = cellValues.map((v) => v.trim().toLowerCase());
		expect
			.soft(
				normalized,
				`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
			)
			.toContain(expectedValue.trim().toLowerCase());
	});
}

export async function testPresetDateRangeFilter(testData: IColumnFilterTestData) {
	// Arrange
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();

	await stepsGrid.resetView();
	await stepsGrid.selectColumnsToDisplay(testData.columnsToDisplay);
	await stepsGrid.setPageSize(100);
	const todayDate = new Date();
	const today = `${todayDate.getMonth() + 1}/${todayDate.getDate()}/${todayDate.getFullYear()}`;
	const format = 'M/d/yyyy';
	const patternBlank: RegExp = /^$|^\.\.\.$/;
	const patternDate: RegExp = /\b(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/\d{4}\b/;
	let filteredCellValuesDesSorting: string[][] = [];
	let filteredCellValuesAscSorting: string[][] = [];

	// BLANK Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.BLANK);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(
		testData.columnDefinitionName,
		testData.textNodeIndex
	);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(
		testData.columnDefinitionName,
		testData.textNodeIndex
	);

	// Assert
	filteredCellValuesDesSorting.forEach((array) => {
		const value = array[0] ?? '';
		expect.soft(patternBlank.test(value), `Actual value "${value}" should match the blank pattern`).toBe(true);
	});
	filteredCellValuesAscSorting.forEach((array) => {
		const value = array[0] ?? '';
		expect.soft(patternBlank.test(value), `Actual value "${value}" should match the blank pattern`).toBe(true);
	});

	// NOT_BLANK Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.NOT_BLANK);
	await stepsColumnFilters.applyFilter();
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(
		testData.columnDefinitionName,
		testData.textNodeIndex
	);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(
		testData.columnDefinitionName,
		testData.textNodeIndex
	);

	// Assert
	filteredCellValuesDesSorting.forEach((array) => {
		const value = array[0] ?? '';
		expect.soft(patternDate.test(value), `Actual value "${value}" should match the not blank pattern`).toBe(true);
	});
	filteredCellValuesAscSorting.forEach((array) => {
		const value = array[0] ?? '';
		expect.soft(patternDate.test(value), `Actual value "${value}" should match the not blank pattern`).toBe(true);
	});

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.TODAY);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultTodayBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultTodayAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultTodayBeforeSorting.forEach((array) => {
	// 	expect
	// 		.soft(
	// 			array[0]?.toLowerCase(),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.TODAY}"`
	// 		)
	// 		.toBe(today);
	// });
	// resultTodayAfterSorting.forEach((array) => {
	// 	expect
	// 		.soft(
	// 			array[0]?.toLowerCase(),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.TODAY}"`
	// 		)
	// 		.toBe(today);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.THIS_WEEK);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultThisWeekBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultThisWeekAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultThisWeekBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(
	// 			isThisWeek(date, { weekStartsOn: 1 }),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.THIS_WEEK}"`
	// 		)
	// 		.toBe(true);
	// });
	// resultThisWeekAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(
	// 			isThisWeek(date, { weekStartsOn: 1 }),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.THIS_WEEK}"`
	// 		)
	// 		.toBe(true);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.THIS_MONTH);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultThisMonthBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultThisMonthAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultThisMonthBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(
	// 			isThisMonth(date),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.THIS_MONTH}"`
	// 		)
	// 		.toBe(true);
	// });
	// resultThisMonthAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(
	// 			isThisMonth(date),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.THIS_MONTH}"`
	// 		)
	// 		.toBe(true);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.YESTERDAY);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultYesterdayBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultYesterdayAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultYesterdayBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(isYesterday(date), `Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.YESTERDAY}"`)
	// 		.toBe(true);
	// });
	// resultYesterdayAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	expect
	// 		.soft(isYesterday(date), `Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.YESTERDAY}"`)
	// 		.toBe(true);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.LAST_7_DAYS);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultLast7DaysBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultLast7DaysAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultLast7DaysBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const last7DaysStart = subDays(today, 6);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, last7DaysStart) || isEqual(date, last7DaysStart)) &&
	// 				(isBefore(date, today) || isEqual(date, today)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_7_DAYS}"`
	// 		)
	// 		.toBe(true);
	// });
	// resultLast7DaysAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const last7DaysStart = subDays(today, 7);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, last7DaysStart) || isEqual(date, last7DaysStart)) &&
	// 				(isBefore(date, today) || isEqual(date, today)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_7_DAYS}"`
	// 		)
	// 		.toBe(true);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.LAST_30_DAYS);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultLast30DaysBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultLast30DaysAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultLast30DaysBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const last30DaysStart = subDays(today, 29);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, last30DaysStart) || isEqual(date, last30DaysStart)) &&
	// 				(isBefore(date, today) || isEqual(date, today)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_30_DAYS}"`
	// 		)
	// 		.toBe(true);
	// });
	// resultLast30DaysAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const last30DaysStart = subDays(today, 30);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, last30DaysStart) || isEqual(date, last30DaysStart)) &&
	// 				(isBefore(date, today) || isEqual(date, today)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_30_DAYS}"`
	// 		)
	// 		.toBe(true);
	// });

	// // Act
	// await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.LAST_WEEK);
	// await stepsColumnFilters.applyFilter();
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// const resultLastWeekBeforeSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );
	// await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// const resultLastWeekAfterSorting = await stepsGrid.getColumnTextValues(
	// 	testData.columnDefinitionName,
	// 	testData.textNodeIndex
	// );

	// // Assert
	// resultLastWeekBeforeSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const currentWeekStart = startOfWeek(today, { weekStartsOn: 1 });
	// 	const lastWeekStart = subDays(currentWeekStart, 7);
	// 	const lastWeekEnd = subDays(currentWeekStart, 1);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, lastWeekStart) || isEqual(date, lastWeekStart)) &&
	// 				(isBefore(date, lastWeekEnd) || isEqual(date, lastWeekEnd)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_WEEK}"`
	// 		)
	// 		.toBe(true);
	// });
	// resultLastWeekAfterSorting.forEach((array) => {
	// 	const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 	const currentWeekStart = startOfWeek(today, { weekStartsOn: 1 });
	// 	const lastWeekStart = subDays(currentWeekStart, 7);
	// 	const lastWeekEnd = subDays(currentWeekStart, 1);
	// 	expect
	// 		.soft(
	// 			(isAfter(date, lastWeekStart) || isEqual(date, lastWeekStart)) &&
	// 				(isBefore(date, lastWeekEnd) || isEqual(date, lastWeekEnd)),
	// 			`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_WEEK}"`
	// 		)
	// 		.toBe(true);
	// });

	// 	// Act
	// 	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	// 	await stepsColumnFilters.fillDateRangePeriodFilter(DateRange.LAST_MONTH);
	// 	await stepsColumnFilters.applyFilter();
	// 	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	// 	const resultLastMonthBeforeSorting = await stepsGrid.getColumnTextValues(
	// 		testData.columnDefinitionName,
	// 		testData.textNodeIndex
	// 	);
	// 	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	// 	const resultLastMonthAfterSorting = await stepsGrid.getColumnTextValues(
	// 		testData.columnDefinitionName,
	// 		testData.textNodeIndex
	// 	);

	// 	// Assert
	// 	resultLastMonthBeforeSorting.forEach((array) => {
	// 		const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 		const lastMonthStart = startOfMonth(subMonths(today, 1));
	// 		const lastMonthEnd = endOfMonth(subMonths(today, 1));
	// 		expect
	// 			.soft(
	// 				(isAfter(date, lastMonthStart) || isEqual(date, lastMonthStart)) &&
	// 					(isBefore(date, lastMonthEnd) || isEqual(date, lastMonthEnd)),
	// 				`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_MONTH}"`
	// 			)
	// 			.toBe(true);
	// 	});
	// 	resultLastMonthAfterSorting.forEach((array) => {
	// 		const date = parse(array[0]?.toLowerCase() ?? '', format, new Date());
	// 		const lastMonthStart = startOfMonth(subMonths(today, 1));
	// 		const lastMonthEnd = endOfMonth(subMonths(today, 1));
	// 		expect
	// 			.soft(
	// 				(isAfter(date, lastMonthStart) || isEqual(date, lastMonthStart)) &&
	// 					(isBefore(date, lastMonthEnd) || isEqual(date, lastMonthEnd)),
	// 				`Actual date "${array[0]}". ${ErrorMessages.NO_IN_TIME_PERIOD} "${DateRange.LAST_MONTH}"`
	// 			)
	// 			.toBe(true);
	// 	});
}

export async function testBooleanFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	const filterValue = testData.filterValue ? testData.filterValue : '';
	const expectedValue = testData.expectedValue ? testData.expectedValue : filterValue;
	const targetColumn = testData.columnForCheck ? testData.columnForCheck : testData.columnDefinitionName;
	let filteredCellValuesDesSorting: string[][] = [];
	let filteredCellValuesAscSorting: string[][] = [];
	let filteredCellIconsDesSorting: string[][][] = [];
	let filteredCellIconsAscSorting: string[][][] = [];

	// Act
	await stepsGrid.openColumnFilter(testData.columnDefinitionName, testData.filterType);
	await stepsColumnFilters.fillBooleanFilter('', testData.filterValue ?? '');
	await stepsColumnFilters.applyFilter();

	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.DESCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	}

	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsDesSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesDesSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesDesSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}

	if (testData.sortingColumn) {
		await stepsGrid.sortColumn(testData.sortingColumn, SortingOrder.ASCENDING);
	} else {
		await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	}

	if (testData.expectedIcon) {
		if (targetColumn == 'tasks') {
			filteredCellIconsAscSorting = await stepsGrid.getTasksColumnIconValues(targetColumn);
		}
		filteredCellValuesAscSorting = await stepsGrid.getColumnIconValues(targetColumn);
	} else {
		filteredCellValuesAscSorting = await stepsGrid.getColumnTextValues(targetColumn);
	}

	// Assert
	if (testData.expectedIcon) {
		if (testData.columnDefinitionName == 'tasks') {
			filteredCellIconsDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellIconsAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((taskItem, itemIndex) => {
					const actual = taskItem[0];
					expect
						.soft(actual, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${actual}"`)
						.toBe(expectedValue);
				});
			});
		} else {
			filteredCellValuesDesSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
			filteredCellValuesAscSorting.forEach((cell, rowIndex) => {
				cell.forEach((icon, itemIndex) => {
					expect
						.soft(icon, `Row ${rowIndex}, item ${itemIndex}: expected "${expectedValue}", but got "${icon}"`)
						.toBe(expectedValue);
				});
			});
		}
	} else if (testData.expectedPattern) {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			if (cellValues.length === 0) {
				expect(true).toBe(true);
			} else {
				expect
					.soft(
						testData.expectedPattern!.test(cellValues[0]!),
						`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected pattern`
					)
					.toBe(true);
			}
		});
	} else {
		filteredCellValuesDesSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
		filteredCellValuesAscSorting.forEach((cellValues, rowIndex) => {
			const normalized = cellValues.map((v) => v.trim().toLowerCase());
			expect
				.soft(
					normalized,
					`Row ${rowIndex}: none of the values [${cellValues.join(', ')}] match expected value "${expectedValue}"`
				)
				.toContain(expectedValue.trim().toLowerCase());
		});
	}
}

export async function testIconsBooleanFilter(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();

	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillBooleanFilter('', testData.filterValue ?? '');
	await stepsColumnFilters.applyFilter();

	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const filteredCellValuesDesSorting = await stepsGrid.getColumnIconValues(testData.columnDefinitionName);
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const filteredCellValuesAscSorting = await stepsGrid.getColumnIconValues(testData.columnDefinitionName);

	filteredCellValuesDesSorting.forEach((array) =>
		expect
			.soft(
				array[0]?.toLowerCase(),
				`Actual icon "${array[0]}" should match the expected icon "${testData.expectedValue}"`
			)
			.toBe(testData.expectedValue?.toLowerCase())
	);
	filteredCellValuesAscSorting.forEach((array) =>
		expect
			.soft(
				array[0]?.toLowerCase(),
				`Actual icon "${array[0]}" should match the expected icon "${testData.expectedValue}"`
			)
			.toBe(testData.expectedValue?.toLowerCase())
	);
}

function parseFinancialNumber(value: string): number {
	if (!value || value.trim() === '...') return 0;

	const isNegative = /^\(\$?[\d,]+(\.\d{2})?\)$/.test(value); // скобки = отрицательное
	const cleaned = value.replace(/[^0-9.]+/g, ''); // удаляем $, (, ), ,

	const numeric = Number(cleaned);
	return isNegative ? -numeric : numeric;
}
