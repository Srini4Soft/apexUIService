import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { CsvUtils } from 'src/common/utils/csv-reader.js';
import log from 'src/common/utils/logger.js';
import { GridSteps } from 'src/steps/index.js';

export async function testExportGridToCsv(page: Page, expectedColumns: string[], expectedTotalRowsCount: number) {
	const stepsGrid = new GridSteps();

	const downloadPromise = page.waitForEvent('download');
	await stepsGrid.exportToCSV();
	const download = await downloadPromise;
	const csvPath = test.info().outputPath(download.suggestedFilename());
	await download.saveAs(csvPath);

	const exportedColumns = await CsvUtils.getHeaderColumns(csvPath);
	const exportedRows = (await CsvUtils.getRowCount(csvPath)) - 1;

	log.debug('Exported columns: ' + exportedColumns);
	log.debug('Exported rows number: ' + exportedRows);

	expect(exportedColumns, ErrorMessages.GRID_SAME_COLUMNS).toEqual(expectedColumns);
	expect(exportedRows, ErrorMessages.ROWS_NUMBER_SAME).toBe(expectedTotalRowsCount);
}
