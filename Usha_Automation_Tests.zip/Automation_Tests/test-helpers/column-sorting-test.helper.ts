import { expect } from '@playwright/test';
import { SortingOrder } from 'src/common/enums/index.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { GridSteps } from 'src/steps/index.js';

export async function testSortNumericColumn(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();

	function parseToNumber(value: string): number {
		if (!value) return NaN;

		const trimmed = value.trim();
		const isNegative = /^\(\$?\d{1,3}(,\d{3})*(\.\d{2})?\)$/.test(trimmed);
		const cleaned = trimmed.replace(/[^0-9.]/g, '');
		const numeric = Number(cleaned);
		if (isNaN(numeric)) {
			log.warn(`Failed to convert value "${value}" to a number`);
			return NaN;
		}

		return isNegative ? -numeric : numeric;
	}

	// DESCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const descRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const descParsed = descRaw.map((cell) => parseToNumber(cell[testData.textNodeIndex!]!));

	let isDescSorted = true;
	let descErrorMessage = '';
	for (let i = 1; i < descParsed.length; i++) {
		const prev = descParsed[i - 1];
		const curr = descParsed[i];
		if (!isNaN(prev!) && !isNaN(curr!) && curr! > prev!) {
			isDescSorted = false;
			descErrorMessage = `Descending order violated at index ${i}: ${prev} < ${curr}`;
			break;
		}
	}

	expect.soft(isDescSorted, descErrorMessage).toBe(true);

	// ASCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const ascRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const ascParsed = ascRaw.map((cell) => parseToNumber(cell[testData.textNodeIndex!]!));

	let isAscSorted = true;
	let ascErrorMessage = '';
	for (let i = 1; i < ascParsed.length; i++) {
		const prev = ascParsed[i - 1];
		const curr = ascParsed[i];
		if (!isNaN(prev!) && !isNaN(curr!) && curr! < prev!) {
			isAscSorted = false;
			ascErrorMessage = `Ascending order violated at index ${i}: ${prev} > ${curr}`;
			break;
		}
	}

	expect.soft(isAscSorted, ascErrorMessage).toBe(true);
}

export async function testSortTextColumn(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();

	function normalizeText(value: string | undefined): string {
		return (value ?? '').trim().toLowerCase();
	}

	// DESCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const descRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const descParsed = descRaw.map((cell) => normalizeText(cell[testData.textNodeIndex!]!));

	let isDescSorted = true;
	let descErrorMessage = '';
	for (let i = 1; i < descParsed.length; i++) {
		const prev = descParsed[i - 1];
		const curr = descParsed[i];

		if (!prev || prev === '...' || !curr || curr === '...') continue;

		if (curr.localeCompare(prev) > 0) {
			isDescSorted = false;
			descErrorMessage = `Descending order violated at index ${i}: "${prev}" < "${curr}"`;
			break;
		}
	}

	expect.soft(isDescSorted, descErrorMessage).toBe(true);

	// ASCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const ascRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const ascParsed = ascRaw.map((cell) => normalizeText(cell[testData.textNodeIndex!]!));

	let isAscSorted = true;
	let ascErrorMessage = '';
	for (let i = 1; i < ascParsed.length; i++) {
		const prev = ascParsed[i - 1];
		const curr = ascParsed[i];

		if (!prev || prev === '...' || !curr || curr === '...') continue;

		if (curr.localeCompare(prev) < 0) {
			isAscSorted = false;
			ascErrorMessage = `Ascending order violated at index ${i}: "${prev}" > "${curr}"`;
			break;
		}
	}

	expect.soft(isAscSorted, ascErrorMessage).toBe(true);
}

export async function testSortIconsColumn(testData: IColumnFilterTestData) {
	// Arrange
	const stepsGrid = new GridSteps();

	// Act
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const initialValuesDescendingOrder = await stepsGrid.getColumnIconValues(testData.columnDefinitionName);
	const actualValuesDescendingOrder = initialValuesDescendingOrder.map((subArray) => subArray[0]);
	const expectedValuesDescendingOrder = [...actualValuesDescendingOrder].sort((a, b) =>
		(b ?? '').localeCompare(a ?? '', undefined, { sensitivity: 'base' })
	);

	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const initialValuesAscendingOrder = await stepsGrid.getColumnIconValues(testData.columnDefinitionName);
	const actualValuesAscendingOrder = initialValuesAscendingOrder.map((subArray) => subArray[0]);
	const expectedValuesAscendingOrder = [...actualValuesAscendingOrder].sort((a, b) =>
		(a ?? '').localeCompare(b ?? '', undefined, { sensitivity: 'base' })
	);

	// Assert
	expect(
		actualValuesDescendingOrder,
		`Expected array to be sorted in descending order, but found: ${JSON.stringify(actualValuesDescendingOrder)}`
	).toEqual(expectedValuesDescendingOrder);

	expect(
		actualValuesAscendingOrder,
		`Expected array to be sorted in ascending order, but found: ${JSON.stringify(actualValuesAscendingOrder)}`
	).toEqual(expectedValuesAscendingOrder);
}

export async function testSortDateColumn(testData: IColumnFilterTestData) {
	const stepsGrid = new GridSteps();

	function parseToDate(value: string): number {
		if (!value || value.trim() === '...') return NaN;

		const trimmed = value.trim();
		const match = trimmed.match(/\b(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/\d{4}\b/);
		if (!match) {
			console.warn(`Invalid date format: "${value}"`);
			return NaN;
		}

		const [month, day, year] = match[0].split('/').map(Number);
		const date = new Date(year!, month! - 1, day);
		return date.getTime();
	}

	// DESCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.DESCENDING);
	const descRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const descParsed = descRaw.map((cell) => parseToDate(cell[testData.textNodeIndex!]!));

	let isDescSorted = true;
	let descErrorMessage = '';
	for (let i = 1; i < descParsed.length; i++) {
		const prev = descParsed[i - 1];
		const curr = descParsed[i];
		if (!isNaN(prev!) && !isNaN(curr!) && curr! > prev!) {
			isDescSorted = false;
			descErrorMessage = `Descending date order violated at index ${i}: ${new Date(
				prev!
			).toLocaleDateString()} < ${new Date(curr!).toLocaleDateString()}`;
			break;
		}
	}

	expect.soft(isDescSorted, descErrorMessage).toBe(true);

	// ASCENDING
	await stepsGrid.sortColumn(testData.columnDefinitionName, SortingOrder.ASCENDING);
	const ascRaw = await stepsGrid.getColumnTextValues(testData.columnDefinitionName);
	const ascParsed = ascRaw.map((cell) => parseToDate(cell[testData.textNodeIndex!]!));

	let isAscSorted = true;
	let ascErrorMessage = '';
	for (let i = 1; i < ascParsed.length; i++) {
		const prev = ascParsed[i - 1];
		const curr = ascParsed[i];
		if (!isNaN(prev!) && !isNaN(curr!) && curr! < prev!) {
			isAscSorted = false;
			ascErrorMessage = `Ascending date order violated at index ${i}: ${new Date(
				prev!
			).toLocaleDateString()} > ${new Date(curr!).toLocaleDateString()}`;
			break;
		}
	}

	expect.soft(isAscSorted, ascErrorMessage).toBe(true);
}
