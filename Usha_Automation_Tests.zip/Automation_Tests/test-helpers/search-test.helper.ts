import { expect } from '@playwright/test';
import { ErrorMessages, FilterConditions } from 'src/common/enums/index.js';
import { ISearchTestData } from 'src/common/models/index.js';
import { ColumnFiltersSteps, GridSteps } from 'src/steps/index.js';

export async function testGridSearch(testData: ISearchTestData) {
	// Arrange
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();
	let searchValue: string = '';

	await stepsGrid.resetView();
	await stepsGrid.setPageSize(100);

	if (!testData.searchValue) {
		await stepsGrid.openColumnFilter(testData.columnDefinitionName);
		await stepsColumnFilters.fillTextFilter('', FilterConditions.NOT_BLANK);
		await stepsColumnFilters.applyFilter();
		const initialCellValues: string[][] = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);
		searchValue = initialCellValues[0]?.[0] ?? '';
	} else {
		searchValue = testData.searchValue;
	}

	// Act
	const recordsBeforeSearch = await stepsGrid.getTotalRecordCount();
	await stepsGrid.search(searchValue);
	const recordsAfterSearch = await stepsGrid.getTotalRecordCount();
	const foundCellValues = await stepsGrid.getColumnTextValues(testData.columnDefinitionName, 0);

	// Assert
	expect.soft(recordsAfterSearch, ErrorMessages.ROWS_NUMBER_LESS_THEN_BEFORE).toBeLessThan(recordsBeforeSearch);
	foundCellValues.forEach((array) =>
		expect
			.soft(
				array[0]?.toLocaleLowerCase(),
				`Actual value "${array[0]}" should match the expected value "${searchValue}"`
			)
			.toContain(searchValue.toLocaleLowerCase())
	);

	// Act
	await stepsGrid.resetGridFilters();
	const recordsAfterReset = await stepsGrid.getTotalRecordCount();

	// Assert
	expect.soft(recordsAfterReset, ErrorMessages.ROWS_NUMBER_SAME).toBe(recordsBeforeSearch);
}
