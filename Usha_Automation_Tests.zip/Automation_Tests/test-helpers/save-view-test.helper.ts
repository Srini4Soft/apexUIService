import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { ISaveViewTestData, IUpdateViewTestData } from 'src/common/models/index.js';
import { ColumnFiltersSteps, GridSteps } from 'src/steps/index.js';

export async function testSaveView(testData: ISaveViewTestData) {
	// Arrange
	const stepsGrid = new GridSteps();
	const stepsColumnFilters = new ColumnFiltersSteps();

	await stepsGrid.resetView();
	await stepsGrid.setPageSize(100);

	// Act
	const recordsBeforeFiltering = await stepsGrid.getTotalRecordCount();

	await stepsGrid.selectColumnsToDisplay(testData.columnsToDisplay);
	await stepsGrid.openColumnFilter(testData.columnDefinitionName);
	await stepsColumnFilters.fillEnumCheckboxFilter('', testData.filterValue);
	await stepsColumnFilters.applyFilter();

	const expectedRecordsNumber = await stepsGrid.getTotalRecordCount();

	await stepsGrid.saveView(testData.viewName);
	await stepsGrid.resetView();

	// Assert
	expect(await stepsGrid.getTotalRecordCount(), ErrorMessages.ROWS_NUMBER_SAME).toBe(recordsBeforeFiltering);

	// Act
	await stepsGrid.applyView(testData.viewName);
	const actualRecordsNumber = await stepsGrid.getTotalRecordCount();
	const actualColumns = await stepsGrid.getColumnNames();

	// Assert
	expect.soft(actualRecordsNumber, ErrorMessages.ROWS_NUMBER_SAME).toBe(expectedRecordsNumber);
	expect.soft(actualColumns.sort(), ErrorMessages.GRID_SAME_COLUMNS).toEqual(testData.columnsToDisplay.sort());
}

export async function testUpdateViewLink(testData: IUpdateViewTestData) {
	// Arrange
	const stepsGrid = new GridSteps();

	await stepsGrid.resetView();

	// Act
	await stepsGrid.applyView(testData.oldName);
	const expectedRecordsNumber = await stepsGrid.getTotalRecordCount();
	const expectedColumns = await stepsGrid.getColumnNames();

	await stepsGrid.updateView(testData.oldName, testData.newName);
	await stepsGrid.resetView();
	await stepsGrid.applyView(testData.newName);
	const actualRecordsNumber = await stepsGrid.getTotalRecordCount();
	const actualColumns = await stepsGrid.getColumnNames();

	// Assert
	expect.soft(actualRecordsNumber, ErrorMessages.ROWS_NUMBER_SAME).toBe(expectedRecordsNumber);
	expect.soft(actualColumns.sort(), ErrorMessages.GRID_SAME_COLUMNS).toEqual(expectedColumns.sort());
}
