import { expect } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';

/**
 * Verifies that all specified breadcrumb items are visible and contain the correct text.
 * @param {string[]} items - An array of strings representing the expected breadcrumb items in specific order.
 */
export async function testBreadcrumbs(...items: string[]) {
	const locBreadcrumbsElement = '//amp-breadcrumbs//ul';
	await verifyBreadcrumbs(items, locBreadcrumbsElement);
}

/**
 * Verifies that all specified breadcrumb items are visible and contain the correct text for MVC version of the page.
 * @param {string[]} items - An array of strings representing the expected breadcrumb items in specific order.
 */
export async function testBreadcrumbsMvc(...items: string[]) {
	const locBreadcrumbsElement = '//div[@id="pageHeader"]//div[@class="page-bar"]/ul[@class="page-breadcrumb"]';
	await verifyBreadcrumbs(items, locBreadcrumbsElement);
}

async function verifyBreadcrumbs(items: string[], elementSelector: string) {
	const page = PageInstance.getInstance().getPage();
	await expect(page.locator(elementSelector), ErrorMessages.NO_BREADCRUMBS_ELEMENT).toBeVisible();
	for (const [index, item] of items.entries()) {
		const selector = `${elementSelector}/li[${index + 1}]//a`;
		await expect(page.locator(selector), ErrorMessages.NO_BREADCRUMBS_ITEM).toBeVisible();
		const text = await page.textContent(selector);
		expect(text?.trim(), `Expected breadcrumbs item text "${item}", actual text "${text}"`).toBe(item);
	}
}
