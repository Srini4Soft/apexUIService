import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbs } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the Verifications section',
	{ tag: ['@verifications', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for Verifications -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.verifications.openDashboardPage();
			await stepsCommon.dashboard.selectDashboardByPositionNumber(1);

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Verifications', 'Dashboard');
			await stepsCommon.dashboard.verifyDashboardSettingsButtonIsVisible();
		});

		test('UI checks for Verifications -> Verification List page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.verifications.openVerificationListPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Verifications', 'Verification List');
			await stepsSection.verifications.uiAssertions.verifyEligibilityButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Verifications -> Batches page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.verifications.openBatchesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Verifications', 'Batches');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Verifications -> Reverification Rules page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.verifications.openReverificationRulesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Verifications', 'Reverification Rules');
			await stepsSection.verifications.uiAssertions.verifyCreateRuleButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Verifications -> Verification Deltas page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.verifications.openVerificationDeltasPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Verifications', 'Verification Deltas');
			await stepsSection.verifications.uiAssertions.verifySelectViewDropdownIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});
	}
);
