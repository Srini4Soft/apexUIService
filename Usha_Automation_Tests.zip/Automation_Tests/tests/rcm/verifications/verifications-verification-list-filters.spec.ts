import { expect, Page } from '@playwright/test';
import { FilterConditions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import {
	testEnumCheckboxFilter,
	testEnumRadioFilter,
	testIconsBooleanFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testSortDateColumn,
	testSortNumericColumn,
	testTextFilter,
} from 'src/test-helpers/index.js';

test.describe(
	'Verifications -> Verification List grid: column filtering',
	{ tag: ['@verifications', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let stepsCommon: CommonStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		[
			{
				columnDefinitionName: 'residentIdAndVerificationRequestId',
				columnsToDisplay: ['#', 'Resident Name', 'Payer'],
				filterTitle: 'Verification Request Id',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'residentIdAndVerificationRequestId',
				columnsToDisplay: ['#', 'Resident Name', 'Payer'],
				filterTitle: 'Resident Id',
				textNodeIndex: 1,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test number filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testNumberFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'payer',
				columnsToDisplay: ['Payer', '#', 'Resident Name'],
				filterTitle: 'Payer Name',
				filterValue: 'NY Medicaid',
				textNodeIndex: 1,
			},
			{
				columnDefinitionName: 'created',
				columnsToDisplay: ['Created', '#', 'Resident Name'],
				filterTitle: 'Created By',
				textNodeIndex: 3,
			},
			{
				columnDefinitionName: 'residentPayer',
				columnsToDisplay: ['Resident Payer', '#', 'Resident Name'],
				filterTitle: 'Resident Payer Name',
				textNodeIndex: 1,
			},
			{
				columnDefinitionName: 'ssn',
				columnsToDisplay: ['SSN', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'currentHmoProvider',
				columnsToDisplay: ['Current HMO Provider', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'priorHmoProvider',
				columnsToDisplay: ['Prior HMO Provider', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test text filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testTextFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'payer',
				columnsToDisplay: ['Payer', '#', 'Resident Name'],
				filterTitle: 'Verification Payer Category',
				filterValue: 'Medicare',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligible',
				columnsToDisplay: ['Eligible', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Failed',
				expectedIcon: true,
				expectedValue: 'Request Time',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isEligible',
				columnsToDisplay: ['Eligible', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Eligible',
				expectedIcon: true,
				expectedValue: 'Eligible',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isEligible',
				columnsToDisplay: ['Eligible', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Not Eligible',
				expectedIcon: true,
				expectedValue: 'Not Eligible',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'censusStatus',
				columnsToDisplay: ['Census Status', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Active',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'censusStatus',
				columnsToDisplay: ['Census Status', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Inactive',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'residentPayer',
				columnsToDisplay: ['Resident Payer', '#', 'Resident Name'],
				filterTitle: 'Resident Payer Category',
				filterValue: 'Medicaid',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'residentPayer',
				columnsToDisplay: ['Resident Payer', '#', 'Resident Name'],
				filterTitle: 'Resident Payer Category',
				filterValue: 'Unknown',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'payerCategory',
				columnsToDisplay: ['Verification Payer Category', '#', 'Resident Name'],
				filterTitle: 'Medicaid',
				filterValue: 'Medicaid',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'payerCategory',
				columnsToDisplay: ['Verification Payer Category', '#', 'Resident Name'],
				filterTitle: 'Commercial',
				filterValue: 'Commercial',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test checkbox filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumCheckboxFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'dolba',
				columnsToDisplay: ['DOLBA', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'doeba',
				columnsToDisplay: ['DOEBA', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'terminationPartA',
				columnsToDisplay: ['Termination Part A', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'terminationPartB',
				columnsToDisplay: ['Termination Part B', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'terminationPartC',
				columnsToDisplay: ['Termination Part C', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'terminationPartD',
				columnsToDisplay: ['Termination Part D', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'currentHmoEnrollment',
				columnsToDisplay: ['Current HMO Enrollment', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'currentHmoTermination',
				columnsToDisplay: ['Current HMO Termination', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'priorHmoEnrollment',
				columnsToDisplay: ['Prior HMO Enrollment', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'priorHmoTermination',
				columnsToDisplay: ['Prior HMO Termination', '#', 'Resident Name'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test date filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testPresetDateRangeFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'isEligiblePartA',
				columnsToDisplay: ['Is Eligible Part A', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligiblePartA',
				columnsToDisplay: ['Is Eligible Part A', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligiblePartB',
				columnsToDisplay: ['Is Eligible Part B', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligiblePartB',
				columnsToDisplay: ['Is Eligible Part B', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligiblePartC',
				columnsToDisplay: ['Is Eligible Part C', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'isEligiblePartC',
				columnsToDisplay: ['Is Eligible Part C', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test radio icon filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testIconsBooleanFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'partCOptionCode',
				columnsToDisplay: ['Part C Option Code', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Option Code C',
				expectedValue: 'Option Code C',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'partCOptionCode',
				columnsToDisplay: ['Part C Option Code', '#', 'Resident Name'],
				filterTitle: '',
				filterValue: 'Option Code 1',
				expectedValue: 'Option Code 1',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test radio filters in "Verification List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumRadioFilter(testData);
			});
		});

		test('Filter "Verification List" grid "Resident Name" column by "Last Name"', async () => {
			test.info().annotations.push({
				type: 'Test',
				description:
					'This test opens "Verification List" grid and filters "Resident Name" column by "Last Name". Column uses "Text Filter".',
			});

			// Arrange
			const columnName = 'residentName';
			const columnsToDisplay = ['Resident Name', '#'];

			await stepsCommon.navigation.verifications.openVerificationListPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
			await stepsCommon.grid.setPageSize(100);

			const recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident Last Name', FilterConditions.NOT_BLANK);
			await stepsCommon.columnFilter.applyFilter();
			const cellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			const expectedLastName = cellValues[0]![0]!.split(',')[0]!.trim();

			// Act
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident Last Name', FilterConditions.EQUALS, expectedLastName);
			await stepsCommon.columnFilter.applyFilter();
			let filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			expect(filteredCellValues.every((value) => value[0]!.split(',')[0] === expectedLastName)).toBe(true);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident Last Name',
				FilterConditions.DOES_NOT_EQUAL,
				expectedLastName
			);
			await stepsCommon.columnFilter.applyFilter();
			let recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident Last Name', FilterConditions.CONTAINS, expectedLastName);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			expect(filteredCellValues.every((value) => value[0]!.split(',')[0] === expectedLastName)).toBe(true);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident Last Name',
				FilterConditions.DOES_NOT_CONTAIN,
				expectedLastName
			);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident Last Name',
				FilterConditions.STARTS_WITH,
				expectedLastName
			);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			expect(filteredCellValues.every((value) => value[0]!.split(',')[0] === expectedLastName)).toBe(true);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident Last Name',
				FilterConditions.DOES_NOT_START_WITH,
				expectedLastName
			);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident Last Name', FilterConditions.ENDS_WITH, expectedLastName);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			expect(filteredCellValues.every((value) => value[0]!.split(',')[0] === expectedLastName)).toBe(true);
		});

		test('Filter "Verification List" grid "Resident Name" column by "First Name"', async () => {
			test.info().annotations.push({
				type: 'Test',
				description:
					'This test opens "Verification List" grid and filters "Resident Name" column by "First Name". Column uses "Text Filter".',
			});

			// Arrange
			const columnName = 'residentName';
			const columnsToDisplay = ['Resident Name', '#'];

			await stepsCommon.navigation.verifications.openVerificationListPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
			await stepsCommon.grid.setPageSize(100);

			const recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident First Name', FilterConditions.NOT_BLANK);
			await stepsCommon.columnFilter.applyFilter();
			const cellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			const expectedFirstName = cellValues[0]![0]!.split(',')[1]!.trim();

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter('Resident First Name', FilterConditions.EQUALS, expectedFirstName);
			await stepsCommon.columnFilter.applyFilter();
			let filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			filteredCellValues.forEach((value) => {
				const firstName = value[0]!.split(',')[1]!.trim();
				expect.soft(firstName.toLowerCase()).toContain(expectedFirstName.toLowerCase());
			});

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.DOES_NOT_EQUAL,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			let recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.CONTAINS,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			filteredCellValues.forEach((value) => {
				const firstName = value[0]!.split(',')[1]!.trim();
				expect.soft(firstName.toLowerCase()).toContain(expectedFirstName.toLowerCase());
			});

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.DOES_NOT_CONTAIN,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.STARTS_WITH,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			filteredCellValues.forEach((value) => {
				const firstName = value[0]!.split(',')[1]!.trim();
				expect.soft(firstName.toLowerCase()).toContain(expectedFirstName.toLowerCase());
			});

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.DOES_NOT_START_WITH,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberActual = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Does the number of records in the table differ?').not.toBe(
				recordsNumberActual
			);

			// Act
			await stepsCommon.grid.resetGridFilters();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillTextFilter(
				'Resident First Name',
				FilterConditions.ENDS_WITH,
				expectedFirstName
			);
			await stepsCommon.columnFilter.applyFilter();
			filteredCellValues = await stepsCommon.grid.getColumnTextValues(columnName);
			// Assert
			filteredCellValues.forEach((value) => {
				const firstName = value[0]!.split(',')[1]!.trim();
				expect.soft(firstName.toLowerCase()).toContain(expectedFirstName.toLowerCase());
			});
		});

		[
			{
				columnDefinitionName: 'residentIdAndVerificationRequestId',
				columnsToDisplay: ['#', 'Resident Name'],
				textNodeIndex: 0,
			},
		].forEach((testData) => {
			test(`Sort numeric columns in "Verification List" grid by "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Number sorting".`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);
				await testSortNumericColumn(testData);
			});
		});

		[
			{
				columnDefinitionName: 'dolba',
				columnsToDisplay: ['DOLBA', '#', 'Resident Name'],
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'doeba',
				columnsToDisplay: ['DOEBA', '#', 'Resident Name'],
				textNodeIndex: 0,
			},
		].forEach((testData) => {
			test(`Sort date columns in "Verification List" grid by "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Verification List" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Date sorting".`,
				});

				await stepsCommon.navigation.verifications.openVerificationListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testSortDateColumn(testData);
			});
		});
	}
);
