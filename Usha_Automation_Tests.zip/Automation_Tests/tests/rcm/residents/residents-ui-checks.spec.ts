import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbs } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the Residents section',
	{ tag: ['@residents', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for Residents -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.navigation.residents.openDashboardPage();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Dashboard');
			await stepsSection.residents.uiAssertions.verifyWidgetTitleIsVisible('Data Issues');
			await stepsSection.residents.uiAssertions.verifyWidgetTitleIsVisible('Data Accuracy');
			await stepsSection.residents.uiAssertions.verifyWidgetTitleIsVisible('Outstanding Balance');
			await stepsSection.residents.uiAssertions.verifyWidgetTitleIsVisible('Residents');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
		});

		test('UI checks for Residents -> Master Data page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Master Data');
			await stepsSection.residents.uiAssertions.verifyCreateResidentButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test.fail('UI checks for Residents -> Census Delta page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
			await stepsCommon.navigation.residents.openCensusDeltaPage();
			await stepsSection.residents.censusDeltaSteps.fillSources('Master', 'Medicare');

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Census Delta');
			await stepsSection.residents.uiAssertions.verifySectionIsVisible('Census');
			await stepsSection.residents.uiAssertions.verifySectionIsVisible('Admissions');
		});

		test('UI checks for Residents -> Submission Queue page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.navigation.residents.openSubmissionQueuePage();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Submission Queue');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Residents -> Global Resident page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.navigation.residents.openGlobalResidentsPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Global Residents');
			await stepsSection.residents.uiAssertions.verifyCreateGlobalResidentButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Residents -> Settings -> Validation Rules page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks for the presence of UI elements on the page',
			});

			// Act
			await stepsCommon.navigation.residents.openRulesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Residents', 'Settings', 'Validation Rules');
			await stepsSection.residents.uiAssertions.verifyCreateRuleButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});
	}
);
