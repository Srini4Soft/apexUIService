import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testExportGridToCsv } from 'src/test-helpers/index.js';

test.describe('Residents: export grid to CSV', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Export "Residents Master Data" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Residents Master Data" grid to CSV',
		});

		const expectedColumns = [
			'Discrepancy',
			'Resident Id',
			'Census Status',
			'Last Name',
			'First Name',
			'Middle Name',
			'DOB',
			'Sex',
			'Payer Name',
			'Payer Category',
			'A/R',
			'SSN',
			'MCR #',
			'MCD #',
			'Source',
			'Last Updated On',
			'Last Updated By',
			'Facility',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
		await stepsCommon.navigation.residents.openMasterDataPage();
		await stepsCommon.grid.resetView();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});
});
