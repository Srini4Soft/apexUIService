import { Page } from '@playwright/test';
import { DateRange } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testExportGridToCsv } from 'src/test-helpers/index.js';

test.describe('Census: export grid to CSV', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Export "Census Changes" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Census Changes" grid to CSV',
		});

		const expectedColumns = [
			'Resident Id',
			'Resident Name',
			'Change Type',
			'Effective Date',
			'Admission Date',
			'Discharge Date',
			'Census Date',
			'Census Status',
			'Source System',
			'Facility',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
		await stepsCommon.navigation.census.openChangesPage();
		await stepsCommon.grid.resetView();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});

	test('Export "Census Residents" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Census Residents" grid to CSV',
		});

		const expectedColumns = [
			'#',
			'Source',
			'Resident Name',
			'Gender',
			'Admission Date',
			'Discharge Date',
			'Census Date',
			'Census Status',
			'Payer Category',
			'Payer Name',
			'Is Bedhold',
			'Bed',
			'Room Unit Type',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
		await stepsCommon.navigation.census.openResidentsPage();
		await stepsCommon.grid.resetView();

		await stepsCommon.grid.openColumnFilter('censusDate');
		await stepsCommon.columnFilter.fillDateRangePeriodFilter(DateRange.ALL_TIME);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openColumnFilter('censusStatusId');
		await stepsCommon.columnFilter.fillEnumCheckboxFilter('', ['Draft']);
		await stepsCommon.columnFilter.applyFilter();

		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});
});
