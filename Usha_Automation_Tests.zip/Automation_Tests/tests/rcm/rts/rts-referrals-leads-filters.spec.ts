import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testEnumCheckboxFilter, testPresetDateRangeFilter, testTextFilter } from 'src/test-helpers/index.js';

test.describe('RTS -> Leads grid: column filtering', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	[
		{
			columnDefinitionName: 'leadId',
			columnsToDisplay: ['#', 'File Name', 'Facility'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', 'File Name', 'Facility'],
			filterTitle: 'Created By',
			textNodeIndex: 3,
		},
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', 'File Name', 'Facility'],
			filterTitle: 'Last Updated By',
			textNodeIndex: 3,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text filters in "Leads" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Leads" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
			});

			await stepsCommon.navigation.rts.openLeadsPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'leadType',
			columnsToDisplay: ['Type', '#', 'File Name', 'Facility'],
			filterTitle: '',
			filterValue: 'Fax \\ Email',
			sortingColumn: 'leadId',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'leadType',
			columnsToDisplay: ['Type', '#', 'File Name', 'Facility'],
			filterTitle: '',
			filterValue: 'Phone',
			sortingColumn: 'leadId',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'status',
			columnsToDisplay: ['Status', 'File Name', 'Facility'],
			filterTitle: '',
			filterValue: 'New',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'status',
			columnsToDisplay: ['Status', 'File Name', 'Facility'],
			filterTitle: '',
			filterValue: 'Processed',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox filters in "Leads" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Leads" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.rts.openLeadsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', 'File Name', 'Facility'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', 'File Name', 'Facility'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test date filters in "Leads" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Leads" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
			});

			await stepsCommon.navigation.rts.openLeadsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testPresetDateRangeFilter(testData);
		});
	});
});
