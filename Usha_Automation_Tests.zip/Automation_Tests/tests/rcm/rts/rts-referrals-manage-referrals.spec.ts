import { expect, Page } from '@playwright/test';
import { ApiClient } from 'src/common/api-client/api-client.js';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IReferralCreate, IReferralDetails } from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('RTS -> Referrals: create referral', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Create new referral', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test checks that it is possible to create a new referral that is not in the search. The test does not fill in the referral details.',
		});

		// Arrange
		let referral: IReferralCreate = {
			facilityId: 'Beacon Rehabilitation and Nursing Center',
			lastName: `Autotest-referral-${Date.now()}`,
		};

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.createReferral(referral);

		// Assert
		await expect(page).toHaveURL(/\/v2\/referrals\/list\/details\/\d+\/referral/);
		const residentId = stepsSection.rts.referralsSteps.getReferralId();
		expect(residentId, ErrorMessages.BLANK_VALUE('Resident ID')).not.toBe('');
		expect(residentId, ErrorMessages.NO_MATCH_PATTERN('Resident ID')).toMatch(/^\d{7}$/);

		// Teardown
		const apiClient = new ApiClient(request);
		await apiClient.veripay.deleteCase(residentId);
	});

	test('Create new referral with existing last name', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test checks that it is impossible to create a new referral with existing "Last Name". This test checks that "Create New Resident button" is disabled.',
		});

		// Arrange
		const referral: IReferralCreate = {
			facilityId: 'Beacon Rehabilitation and Nursing Center',
			lastName: 'test',
		};

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.fillNewReferralForm(referral);

		// Assert
		expect(
			await stepsSection.rts.referralsSteps.isCreateButtonEnabled(),
			ErrorMessages.NOT_ENABLED('Create New Resident')
		).toBe(false);
	});

	test('Create new referral with filled details page', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates new referral and fills details page. Then checks that the referral was created and can be found in the Referrals list.',
		});

		// Arrange
		const formattedStartDate = new Date().toLocaleDateString('en-US', {
			month: '2-digit',
			day: '2-digit',
			year: 'numeric',
		});
		const formattedEndDate = new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString('en-US', {
			month: '2-digit',
			day: '2-digit',
			year: 'numeric',
		});
		const newReferralData: IReferralCreate = {
			facilityId: 'Beacon Rehabilitation and Nursing Center',
			lastName: `Autotest-referral-${Date.now()}`,
		};
		const referralDetailsData: IReferralDetails = {
			caseStatusId: 'Admitted',
			prospectiveAdmissionDate: formattedStartDate,
			admissionDate: formattedStartDate,
			caseSourceId: 'Home',
			caseSourceContactId: 'Abboudi',
			hospitalDates: [formattedStartDate, formattedEndDate],
			projectedDailyDrugCost: '10',
			projectedDailyRehabCost: '15',
			firstName: 'Test',
			middleName: 'T',
			ssn: (Math.floor(Math.random() * 900_000_000) + 100_000_000).toString(),
			medicareNumber: (Math.floor(Math.random() * 900_000_000) + 100_000_000).toString(),
			medicaidNumber: (Math.floor(Math.random() * 900_000_000) + 100_000_000).toString(),
			payerCategoryId: 'Medicaid',
		};

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.createReferral(newReferralData);
		const residentId = stepsSection.rts.referralsSteps.getReferralId();
		await stepsSection.rts.referralsSteps.createReferralWithDetails(referralDetailsData);
		await stepsCommon.grid.search(residentId);

		//Assert
		expect(await stepsCommon.grid.getRowsCount(), ErrorMessages.GRID_IS_EMPTY).toBe(1);

		// Act
		await stepsCommon.grid.openFirstRecord();
		const actualReferralDetails: IReferralDetails = await stepsCommon.formReader.getFormData();

		//Assert
		expect.soft(actualReferralDetails.caseStatusId, 'Verify "Case Status"').toBe(referralDetailsData.caseStatusId);
		expect
			.soft(actualReferralDetails.prospectiveAdmissionDate, 'Verify "Prospective Admission"')
			.toBe(referralDetailsData.prospectiveAdmissionDate);
		expect.soft(actualReferralDetails.admissionDate, 'Verify "Admission Date"').toBe(referralDetailsData.admissionDate);
		expect.soft(actualReferralDetails.caseSourceId, 'Verify "Source"').toBe(referralDetailsData.caseSourceId);
		expect
			.soft(actualReferralDetails.caseSourceContactId, 'Verify "Source Contact"')
			.toContain(referralDetailsData.caseSourceContactId);
		expect
			.soft(actualReferralDetails.hospitalDates, 'Verify "Hospital Dates"')
			.toBe(`${referralDetailsData.hospitalDates![0]} to ${referralDetailsData.hospitalDates![1]}`);
		expect
			.soft(actualReferralDetails.projectedDailyDrugCost, 'Verify "Daily Drug Cost"')
			.toBe(referralDetailsData.projectedDailyDrugCost);
		expect
			.soft(actualReferralDetails.projectedDailyRehabCost, 'Verify "Rehab Cost"')
			.toBe(referralDetailsData.projectedDailyRehabCost);
		expect.soft(actualReferralDetails.firstName, 'Verify "First Name"').toBe(referralDetailsData.firstName);
		expect.soft(actualReferralDetails.middleName, 'Verify "Middle Name"').toBe(referralDetailsData.middleName);
		expect.soft(actualReferralDetails.ssn!.replace(/-/g, ''), 'Verify "Ssn"').toBe(referralDetailsData.ssn);
		expect
			.soft(actualReferralDetails.medicareNumber, 'Verify "Medicare Number"')
			.toBe(referralDetailsData.medicareNumber);
		expect
			.soft(actualReferralDetails.medicaidNumber, 'Verify "Medicaid Number"')
			.toBe(referralDetailsData.medicaidNumber);
		expect
			.soft(actualReferralDetails.payerCategoryId, 'Verify "Payer Category"')
			.toBe(referralDetailsData.payerCategoryId);

		// Teardown
		const apiClient = new ApiClient(request);
		await apiClient.veripay.deleteCase(residentId);
	});

	test('Delete referral', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates a new referral without filling details data and then removes it. After that checks that the referral can not be found in the Referrals list.',
		});

		// Arrange
		const referral: IReferralCreate = {
			facilityId: 'Beacon Rehabilitation and Nursing Center',
			lastName: `Autotest-referral-${Date.now()}`,
		};

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.createReferral(referral);
		const residentId = stepsSection.rts.referralsSteps.getReferralId();
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.search(residentId);

		// Assert
		expect(
			await stepsCommon.grid.getRowsCount(),
			`Only one record with Resident Name "${referral.lastName}" found?`
		).toBe(1);

		// Act
		await stepsCommon.grid.performRowAction(1, 'Delete');
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.search(residentId);

		// Assert
		expect(await stepsCommon.grid.getRowsCount(), ErrorMessages.GRID_IS_NOT_EMPTY).toBe(0);

		// Teardown
		const apiClient = new ApiClient(request);
		await apiClient.veripay.deleteCase(residentId);
	});

	test('Admit referral', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates a new referral with "Admitted" status. After that checks that related Veripay case is created.',
		});

		// Arrange
		const ssn = Math.floor(100000000 + Math.random() * 900000000);
		const expectedReferral = `Autotest-referral-${Date.now()}`;
		const admissionDate = new Date().toLocaleDateString('en-US', {
			month: '2-digit',
			day: '2-digit',
			year: 'numeric',
		});
		const newReferralData: IReferralCreate = {
			facilityId: 'Demo Facility',
			lastName: expectedReferral,
			ssn: ssn.toString(),
		};
		const referralDetailsData: IReferralDetails = {
			caseStatusId: 'Admitted',
			admissionDate: admissionDate,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.createReferral(newReferralData);
		const residentId = stepsSection.rts.referralsSteps.getReferralId();
		await stepsSection.rts.referralsSteps.createReferralWithDetails(referralDetailsData);
		await stepsCommon.grid.search(residentId);
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.rts.referralsSteps.openRelatedCase();

		const currentUrl = page.url();
		const regex = /\/v2\/veripay\/cases\/details\/[^/]+\/case/;

		// Assert
		expect(currentUrl).toMatch(regex);

		// Act
		let actualReferralName = await stepsSection.veripay.caseDetailsSteps.getReferralName();
		actualReferralName = actualReferralName.replace(',', '');

		// Assert
		expect(actualReferralName.toLowerCase()).toBe(expectedReferral.toLowerCase());

		// Teardown
		const apiClient = new ApiClient(request);
		await apiClient.veripay.deleteCase(residentId);
	});
});
