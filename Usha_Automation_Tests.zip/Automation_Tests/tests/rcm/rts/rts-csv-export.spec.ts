import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testExportGridToCsv } from 'src/test-helpers/index.js';

test.describe('RTS: export grid to CSV', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Export "Referrals" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Referrals" grid to CSV',
		});

		const expectedColumns = [
			'Case Id',
			'Resident Id',
			'Census Status',
			'Case Tips',
			'Full Name',
			'Payer Category',
			'Payer Name',
			'Source Name',
			'Hospital',
			'Status',
			'Facility',
			'Created On',
			'Created By',
			'Last Updated On',
			'Last Updated By',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});
});
