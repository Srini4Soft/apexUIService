import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbs } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the RTS section',
	{ tag: ['@residents', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for RTS -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.rts.openDashboardPage();
			await stepsCommon.dashboard.selectDashboardByName('Referral Dashboard');

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Dashboard');
			await stepsCommon.dashboard.verifyDashboardSettingsButtonIsVisible();
			await stepsSection.rts.uiAssertions.verifyWidgetIsVisible('New Leads');
			await stepsSection.rts.uiAssertions.verifyWidgetIsVisible('Active Referrals');
			await stepsSection.rts.uiAssertions.verifyWidgetIsVisible("Today's Admissions");
			await stepsSection.rts.uiAssertions.verifyWidgetIsVisible('Approved Referrals');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for RTS -> Referrals page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Referrals');
			await stepsSection.rts.uiAssertions.verifyCreateReferralButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for RTS -> Reports page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.rts.openReportsPage();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Reports');
			await stepsSection.rts.uiAssertions.verifyReportsListIsVisible();

			// Act
			await stepsSection.rts.reportsSteps.openReport();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Reports', 'Details');
			await stepsSection.rts.uiAssertions.verifyReportsTabIsVisible();
			await stepsSection.rts.uiAssertions.verifyViewReportButtonIsVisible();
			await stepsSection.rts.uiAssertions.verifyReturnButtonIsVisible();
		});

		test('UI checks for RTS -> Rules page -> Automation rules', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.rts.openRulesPage();
			await stepsSection.rts.rulesSteps.openAutomationRulesTab();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Settings', 'Rules', 'Automation Rules');
			await stepsSection.rts.uiAssertions.verifyCreateRuleButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for RTS -> Rules page -> Validation rules', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.rts.openRulesPage();
			await stepsSection.rts.rulesSteps.openValidationRulesTab();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('RTS', 'Settings', 'Rules', 'Validation Rules');
			await stepsSection.rts.uiAssertions.verifyCreateRuleButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});
	}
);
