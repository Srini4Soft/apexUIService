import { expect, Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IMapping } from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Settings: Mappings management', { tag: ['@settings', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Create Mapping', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can create a new Mapping',
		});

		// Arrange
		const mapping: IMapping = {
			mappingTypeId: 'A/R Transaction Type',
			sourceSystemId: 'Bridge',
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			description: 'Mapping description',
			startDate: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			organizationType: 'Adult Home',
			organizationId: 'Arbor House',
			isDisabled: false,
			isGlobal: false,
			tenantEntityId: 'Beacon',
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		await stepsCommon.grid.openFirstRecord();
		const actualMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualMappingData.mappingTypeId, 'Verify "Mapping Type"').toBe(mapping.mappingTypeId);
		expect.soft(actualMappingData.sourceSystemId, 'Verify "Source System"').toBe(mapping.sourceSystemId);
		expect.soft(actualMappingData.input, 'Verify "* Input"').toBe(mapping.input);
		expect.soft(actualMappingData.output, 'Verify "* Output"').toBe(mapping.output);
		expect.soft(actualMappingData.description, 'Verify "Description"').toBe(mapping.description);
		expect.soft(actualMappingData.startDate, 'Verify "Start Date"').toBe(mapping.startDate);
		expect.soft(actualMappingData.endDate, 'Verify "End Date"').toBe(mapping.endDate);
		expect.soft(actualMappingData.organizationType, 'Verify "Organization Type"').toBe(mapping.organizationType);
		expect.soft(actualMappingData.organizationId, 'Verify "Organization"').toContain(mapping.organizationId);
		expect.soft(actualMappingData.isDisabled, 'Verify "Disabled"').toBe(mapping.isDisabled);
		expect.soft(actualMappingData.isGlobal, 'Verify "Global"').toBe(mapping.isGlobal);
	});

	test('Disable and enable Mapping via grid menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates a new mapping, then disables it via the grid menu. Then it re-enables that mapping. The test checks the checkbox on the form and the icon in the grid.',
		});

		// Arrange
		const actions = ['Disable', 'Enable'];
		const icons = ['success', 'cancel'];
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();
		await stepsCommon.grid.clickDynamicGridMenuItem(actions[0]!);
		const iconDisabled = await stepsCommon.grid.getColumnIconValues('isDisabled');
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.openFirstRecord();
		const disabledMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(iconDisabled[0]![0], 'Verify "Disabled" icon in the grid').toBe(icons[0]);
		expect.soft(disabledMappingData.isDisabled, 'Verify "Disabled" checkbox on the form').toBe(true);

		// Act
		await stepsSection.settings.mappingListSteps.closeMappingForm();
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();
		await stepsCommon.grid.clickDynamicGridMenuItem(actions[1]!);
		const iconEnabled = await stepsCommon.grid.getColumnIconValues('isDisabled');
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.openFirstRecord();
		const enabledMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(iconEnabled[0]![0], 'Verify "Enabled" icon in the grid').toBe(icons[1]);
		expect.soft(enabledMappingData.isDisabled, 'Verify "Enabled"').toBe(false);
	});

	test('Disable and enable Mapping via action menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates a new mapping, then disables it via row action menu. Then it re-enables that mapping. The test checks the checkbox on the form and the icon in the grid.',
		});

		// Arrange
		const actions = ['Disable', 'Enable'];
		const icons = ['success', 'cancel'];
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		await stepsCommon.grid.performRowAction(1, actions[0]!);
		await stepsCommon.toaster.close();
		const iconDisabled = await stepsCommon.grid.getColumnIconValues('isDisabled');
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.openFirstRecord();
		const disabledMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(iconDisabled[0]![0], 'Verify "Disabled" icon in the grid').toBe(icons[0]);
		expect.soft(disabledMappingData.isDisabled, 'Verify "Disabled" checkbox on the form').toBe(true);

		// Act
		await stepsSection.settings.mappingListSteps.closeMappingForm();
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.performRowAction(1, actions[1]!);
		await stepsCommon.toaster.close();
		const iconEnabled = await stepsCommon.grid.getColumnIconValues('isDisabled');
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.openFirstRecord();
		const enabledMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(iconEnabled[0]![0], 'Verify "Enabled" icon in the grid').toBe(icons[1]);
		expect.soft(enabledMappingData.isDisabled, 'Verify "Enabled"').toBe(false);
	});

	test('Delete Mapping via grid menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates a new mapping and deletes it via the grid menu.',
		});

		// Arrange
		const action = 'Delete';
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();
		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResultBeforeDelete = await stepsCommon.grid.getRowsCount();
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();
		await stepsCommon.grid.clickDynamicGridMenuItem(action);
		await stepsCommon.grid.confirmActionDialog();
		await stepsCommon.grid.waitForPageLoad();

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResultAfterDelete = await stepsCommon.grid.getRowsCount();

		// Assert
		expect.soft(searchResultBeforeDelete, 'Check that mappings are found').toBe(1);
		expect.soft(searchResultAfterDelete, 'Check that mapping was deleted').toBe(0);
	});

	test('Delete Mapping via action menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates a new mapping and deletes it via action menu.',
		});

		// Arrange
		const action = 'Delete';
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResultBeforeDelete = await stepsCommon.grid.getRowsCount();
		await stepsCommon.grid.performRowAction(1, action);
		await stepsCommon.grid.confirmActionDialog();
		await stepsCommon.grid.waitForPageLoad();

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResultAfterDelete = await stepsCommon.grid.getRowsCount();

		// Assert
		expect.soft(searchResultBeforeDelete, 'Check that mappings are found').toBe(1);
		expect.soft(searchResultAfterDelete, 'Check that mapping was deleted').toBe(0);
	});

	test('Edit Mapping via grid menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can create a new Mapping and update it via grid menu',
		});

		// Arrange
		const action = 'Update Mappings';
		const initialMapping: IMapping = {
			mappingTypeId: 'A/R Transaction Type',
			sourceSystemId: 'Bridge',
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
			isGlobal: false,
		};
		const expectedMapping: IMapping = {
			output: `Autotest-updated-output-${Date.now()}`,
			description: 'Mapping description',
			startDate: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			organizationType: 'Adult Home',
			organizationId: 'Arbor House',
			isDisabled: false,
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(initialMapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.search(initialMapping.input ? initialMapping.input : '');
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();
		await stepsCommon.grid.clickDynamicGridMenuItem(action);
		await stepsSection.settings.mappingListSteps.updateMapping(expectedMapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.search(initialMapping.input ? initialMapping.input : '');
		await stepsCommon.grid.openFirstRecord();
		const actualMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualMappingData.mappingTypeId, 'Verify "Mapping Type"').toBe(initialMapping.mappingTypeId);
		expect.soft(actualMappingData.sourceSystemId, 'Verify "Source System"').toBe(initialMapping.sourceSystemId);
		expect.soft(actualMappingData.input, 'Verify "* Input"').toBe(initialMapping.input);
		expect.soft(actualMappingData.output, 'Verify "* Output"').toBe(expectedMapping.output);
		expect.soft(actualMappingData.description, 'Verify "Description"').toBe(expectedMapping.description);
		expect.soft(actualMappingData.startDate, 'Verify "Start Date"').toBe(expectedMapping.startDate);
		expect.soft(actualMappingData.endDate, 'Verify "End Date"').toBe(expectedMapping.endDate);
		expect
			.soft(actualMappingData.organizationType, 'Verify "Organization Type"')
			.toBe(expectedMapping.organizationType);
		expect.soft(actualMappingData.organizationId, 'Verify "Organization"').toContain(expectedMapping.organizationId);
		expect.soft(actualMappingData.isDisabled, 'Verify "Disabled"').toBe(expectedMapping.isDisabled);
		expect.soft(actualMappingData.isGlobal, 'Verify "Global"').toBe(initialMapping.isGlobal);
	});

	test('Edit Mapping via action menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can create a new Mapping and update it via action menu button',
		});

		// Arrange
		const action = 'Edit';
		const initialMapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};
		const expectedMapping: IMapping = {
			mappingTypeId: 'A/R Transaction Type',
			sourceSystemId: 'Bridge',
			description: 'Mapping description',
			startDate: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			organizationType: 'Adult Home',
			organizationId: 'Arbor House',
			isDisabled: false,
			isGlobal: false,
		};

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(initialMapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.search(initialMapping.input ? initialMapping.input : '');
		await stepsCommon.grid.performRowAction(1, action);
		await stepsSection.settings.mappingListSteps.updateMapping(expectedMapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.search(initialMapping.input ? initialMapping.input : '');
		await stepsCommon.grid.openFirstRecord();
		const actualMappingData: IMapping = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualMappingData.mappingTypeId, 'Verify "Mapping Type"').toBe(expectedMapping.mappingTypeId);
		expect.soft(actualMappingData.sourceSystemId, 'Verify "Source System"').toBe(expectedMapping.sourceSystemId);
		expect.soft(actualMappingData.input, 'Verify "* Input"').toBe(initialMapping.input);
		expect.soft(actualMappingData.output, 'Verify "* Output"').toBe(initialMapping.output);
		expect.soft(actualMappingData.description, 'Verify "Description"').toBe(expectedMapping.description);
		expect.soft(actualMappingData.startDate, 'Verify "Start Date"').toBe(expectedMapping.startDate);
		expect.soft(actualMappingData.endDate, 'Verify "End Date"').toBe(expectedMapping.endDate);
		expect
			.soft(actualMappingData.organizationType, 'Verify "Organization Type"')
			.toBe(expectedMapping.organizationType);
		expect.soft(actualMappingData.organizationId, 'Verify "Organization"').toContain(expectedMapping.organizationId);
		expect.soft(actualMappingData.isDisabled, 'Verify "Disabled"').toBe(expectedMapping.isDisabled);
		expect.soft(actualMappingData.isGlobal, 'Verify "Global"').toBe(expectedMapping.isGlobal);
	});

	test('Copy Mapping via grid menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates a new mapping and copy it via the grid menu to another facility.',
		});

		// Arrange
		const action = 'Copy';
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};
		const expectedTenant = 'Demo';
		const columnWithTenant = 'tenantEntity';

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.facilityFilter.selectPortfolioByExactName('Beacon');
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();
		await page.waitForTimeout(4000);

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();
		await stepsCommon.grid.clickDynamicGridMenuItem(action);
		await stepsSection.settings.mappingListSteps.copyMapping(expectedTenant);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.facilityFilter.selectPortfolioByName(expectedTenant);
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResult = await stepsCommon.grid.getRowsCount();
		const actualTenant = await stepsCommon.grid.getColumnTextValues(columnWithTenant);

		// Assert
		expect.soft(searchResult, 'Check that mapping was found').toBe(1);
		expect.soft(actualTenant[0]![1], 'Verify tenant name').toBe(expectedTenant);
	});

	test('Copy Mapping via action menu', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates a new mapping and copy it via action menu to another facility.',
		});

		// Arrange
		const action = 'Copy';
		const mapping: IMapping = {
			input: `Autotest-input-${Date.now()}`,
			output: `Autotest-output-${Date.now()}`,
			tenantEntityId: 'Beacon',
		};
		const expectedTenant = 'Demo';
		const columnWithTenant = 'tenantEntity';

		// Act
		await stepsCommon.navigation.settings.openMappingListPage();
		await stepsCommon.facilityFilter.selectPortfolioByExactName('Beacon');
		await stepsCommon.grid.resetView();
		await stepsSection.settings.mappingListSteps.createMapping(mapping);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		await stepsCommon.grid.performRowAction(1, action);
		await stepsSection.settings.mappingListSteps.copyMapping(expectedTenant);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.toaster.close();

		await stepsCommon.facilityFilter.selectPortfolioByName(expectedTenant);
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.search(mapping.input ? mapping.input : '');
		const searchResult = await stepsCommon.grid.getRowsCount();
		const actualTenant = await stepsCommon.grid.getColumnTextValues(columnWithTenant);

		// Assert
		expect.soft(searchResult, 'Check that mapping was found').toBe(1);
		expect.soft(actualTenant[0]![1], 'Verify tenant name').toBe(expectedTenant);
	});
});
