import { expect, Page } from '@playwright/test';
import { ApiClient } from 'src/common/api-client/api-client.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import {
	ILookup,
	IPayer,
	IPerson,
	ISaveViewTestData,
	ISearchTestData,
	IUpdateViewTestData,
} from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testGridSearch, testSaveView, testUpdateViewLink } from 'src/test-helpers/index.js';

test.describe('Settings: Entities management', { tag: ['@settings', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Open grid and check basic functionality', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can open grid adn basic functionality works properly',
		});

		// Arrange
		const expectedMenuItems = ['Delete Persons', 'Approve Persons', 'Replace Persons'];

		// Act
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsSection.settings.manageEntitiesSteps.openPeopleTab();

		const expectedColumns = (await stepsCommon.grid.selectColumnsToDisplay(['All'])).sort();
		let actualColumns = await stepsCommon.grid.getColumnNames();
		actualColumns.push('Check Box');
		actualColumns.sort();

		// Assert
		expect(actualColumns).toEqual(expectedColumns);

		// Act
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();

		// Assert
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[0]!);
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[1]!);
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[2]!);
	});

	test('Create Person', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can create a new Person',
		});

		// Arrange
		const personNew: IPerson = {
			type: 'Doctor',
			lastName: `Autotest-person-${Date.now()}`,
			firstName: 'Test',
			middleName: 'Auto',
			gender: 'Male',
			birthDate: new Date(new Date().setMonth(new Date().getMonth() - 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			isGlobal: true,
			employeeStartDate: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			location: 'Test location',
			organizations: {
				organizationId: 'St. Josephs Regional MC',
				lookupPositionId: 'HR Contact',
			},
		};
		const personDetails: IPerson = {
			isApproved: true,
			speciality: 'Ph.D.',
			npi: 'Some Text',
			addressLine1: 'Address line 1',
			addressLine2: 'Address line 2',
			city: 'Pine Bluff',
			stateId: 'AR',
			countyId: 'Jefferson County',
			email: 'test@test.com',
			workPhoneNumber: '24567890',
			workPhoneNumberExt: '321',
			mobilePhoneNumber: '123432123',
			homePhoneNumber: '42324512',
			faxNumber: '023836367354',
		};

		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();

		await stepsSection.settings.manageEntitiesSteps.openPeoplePage();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.manageEntitiesSteps.createPerson(personNew);

		// Assert
		await stepsCommon.grid.search(personNew.lastName!);
		expect(
			await stepsCommon.grid.getRowsCount(),
			`Only one record with Person Name "${personNew.lastName}" found?`
		).toBe(1);

		// Act
		const personId = await stepsCommon.grid.getColumnTextValues('personId');
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.settings.manageEntitiesSteps.editPerson(personDetails);

		await stepsCommon.grid.search(personNew.lastName!);
		await stepsCommon.grid.openFirstRecord();
		const actualPersonData: IPerson = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualPersonData.type, 'Verify "Type"').toBe(personNew.type);
		expect.soft(actualPersonData.lastName, 'Verify "Last Name"').toBe(personNew.lastName);
		expect.soft(actualPersonData.firstName, 'Verify "First Name"').toBe(personNew.firstName);
		expect.soft(actualPersonData.middleName, 'Verify "Middle Name"').toBe(personNew.middleName);
		expect.soft(actualPersonData.gender, 'Verify "Gender"').toBe(personNew.gender);
		expect.soft(actualPersonData.birthDate, 'Verify "Birth Date"').toBe(personNew.birthDate);
		expect.soft(actualPersonData.isApproved, 'Verify "Is Approved"').toBe(personDetails.isApproved);
		expect.soft(actualPersonData.isGlobal, 'Verify "Is Global"').toBe(personNew.isGlobal);
		expect.soft(actualPersonData.speciality, 'Verify "Doctor Speciality"').toBe(personDetails.speciality);
		expect.soft(actualPersonData.npi, 'Verify "NPI"').toBe(personDetails.npi);
		expect.soft(actualPersonData.addressLine1, 'Verify "Address line 1"').toBe(personDetails.addressLine1);
		expect.soft(actualPersonData.addressLine2, 'Verify "Address line 2"').toBe(personDetails.addressLine2);
		expect.soft(actualPersonData.city, 'Verify "City"').toBe(personDetails.city);
		expect.soft(actualPersonData.stateId, 'Verify "State"').toBe(personDetails.stateId);
		expect.soft(actualPersonData.countyId, 'Verify "County"').toBe(personDetails.countyId);
		expect.soft(actualPersonData.email, 'Verify "Email"').toBe(personDetails.email);
		expect.soft(actualPersonData.workPhoneNumber, 'Verify "Work #"').toBe(personDetails.workPhoneNumber);
		expect.soft(actualPersonData.workPhoneNumberExt, 'Verify "Work # ext"').toBe(personDetails.workPhoneNumberExt);
		expect.soft(actualPersonData.mobilePhoneNumber, 'Verify "Mobile #"').toBe(personDetails.mobilePhoneNumber);
		expect.soft(actualPersonData.homePhoneNumber, 'Verify "Home #"').toBe(personDetails.homePhoneNumber);
		expect.soft(actualPersonData.faxNumber, 'Verify "Fax #"').toBe(personDetails.faxNumber);
		expect.soft(actualPersonData.employeeStartDate, 'Verify "User"').toBe(personNew.employeeStartDate);
		expect.soft(actualPersonData.location, 'Verify "Location"').toBe(personNew.location);

		// Teardown
		const apiClient = new ApiClient(request);
		const ids = personId.map(Number);
		await apiClient.settings.deletePeople(ids);
	});

	test('Search in the "Lookups" tab on the "Manage Entities" page', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can search lookups on the Lookups grid and reset view after',
		});

		// Arrange
		const testData: ISearchTestData = {
			columnDefinitionName: 'name',
			searchValue: '',
		};

		// Act
		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
		await testGridSearch(testData);
	});

	test('Save and update "Current View" on "Manage Entities" page "Lookups" tab', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test opens the "Lookups" grid on the "Manage Entities" page. The grid is then filtered and the "Current View" is saved. The name of the saved view is then updated.',
		});

		// Arrange
		const saveViewTestData: ISaveViewTestData = {
			viewName: `AT-view-${Date.now()}`,
			columnsToDisplay: ['#', 'Name', 'Type'],
			columnDefinitionName: 'lookupNamespaceId',
			filterValue: ['Address Type'],
		};
		const updateViewTestData: IUpdateViewTestData = {
			oldName: saveViewTestData.viewName,
			newName: `UPDATED-${saveViewTestData.viewName}`,
		};

		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
		await testSaveView(saveViewTestData);
		await testUpdateViewLink(updateViewTestData);
	});

	test('Create Lookup', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that user can create a new Lookup',
		});

		const lookup: ILookup = {
			name: `Autotest-lookup-${Date.now()}`,
			lookupNamespaceId: 'A/R Balance Status',
			code: 'automation',
			isGlobal: false,
			facilityIds: 'Beacon',
			displayColorId: 'cerulean (3)',
		};

		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectPortfolioByExactName('Beacon');
		await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.manageEntitiesSteps.createLookup(lookup);
		await stepsCommon.grid.search(lookup.name!);
		const lookupId = await stepsCommon.grid.getColumnTextValues('lookupId');

		// Assert
		expect(await stepsCommon.grid.getRowsCount(), `Only one record with Lookup name "${lookup.name}" found?`).toBe(1);

		// Act
		await stepsCommon.grid.openFirstRecord();
		const actualLookupData: ILookup = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualLookupData.name, 'Verify "Name"').toBe(lookup.name);
		expect.soft(actualLookupData.lookupNamespaceId, 'Verify "Type"').toBe(lookup.lookupNamespaceId);
		expect.soft(actualLookupData.code, 'Verify "Code"').toBe(lookup.code);
		expect.soft(actualLookupData.isGlobal, 'Verify "Global"').toBe(lookup.isGlobal);
		expect.soft(actualLookupData.displayColorId, 'Verify "Display Color"').toBe(lookup.displayColorId);

		// Teardown
		const apiClient = new ApiClient(request);
		const ids = lookupId.map(Number);
		await apiClient.settings.deleteLookups(ids);
	});

	test('Approve Lookup from the grid', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test filters the grid by the "Approved" column and selects a lookup with the "not approved" status. The status is then changed to "approved" via grid actions.',
		});

		// Arrange
		const columnDefinitionName = 'name';
		const filteredColumn = 'isApproved';
		const filterValue = 'True';
		const expectedMenuItems = ['Delete Lookups', 'Approve Lookups', 'Replace Lookups'];
		const lookupData: ILookup = {
			isApproved: false,
		};

		// Act
		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.openColumnFilter(filteredColumn);
		await stepsCommon.columnFilter.fillBooleanFilter('', filterValue);
		await stepsCommon.columnFilter.applyFilter();
		const approvedLookupsNumber = await stepsCommon.grid.getTotalRecordCount();
		let lookupsNames = await stepsCommon.grid.getColumnTextValues(columnDefinitionName);
		const expectedName = lookupsNames[0]![0];
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.settings.manageEntitiesSteps.editLookup(lookupData);

		// Assert
		expect(await stepsCommon.grid.getTotalRecordCount(), 'Number of entries less by one?').toBe(
			approvedLookupsNumber - 1
		);

		// Act
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.search(expectedName!);
		await stepsCommon.grid.selectRow(1);
		await stepsCommon.grid.openGridMenu();

		// Assert
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[0]!);
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[1]!);
		await stepsCommon.grid.verifyDynamicGridMenuItemIsVisible(expectedMenuItems[2]!);

		// Act
		await stepsCommon.grid.clickDynamicGridMenuItem(expectedMenuItems[1]!);
		await stepsCommon.grid.waitForPageLoad();
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.openColumnFilter(filteredColumn);
		await stepsCommon.columnFilter.fillBooleanFilter('', filterValue);
		await stepsCommon.columnFilter.applyFilter();

		// Assert
		expect(await stepsCommon.grid.getTotalRecordCount(), 'Is the number of records in the table the same?').toBe(
			approvedLookupsNumber
		);
	});

	test('Search in the "Payers" tab on the "Manage Entities" page', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test checks that user can search payers on the "Manage Entities" grid and reset filters after (https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/58840).',
		});

		// Arrange
		const testData: ISearchTestData = {
			columnDefinitionName: 'name',
		};

		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectPortfolioByName('Beacon');
		await stepsSection.settings.manageEntitiesSteps.openPayersTab();
		await testGridSearch(testData);
	});

	test('Save and update "Current View" on "Manage Entities" page "Payers" tab', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test opens the "Payers" grid on the "Manage Entities" page. The grid is then filtered and the "Current View" is saved. The name of the saved view is then updated (https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/58839).',
		});

		// Arrange
		const saveViewTestData: ISaveViewTestData = {
			viewName: `AT-view-${Date.now()}`,
			columnsToDisplay: ['#', 'Name', 'Payer Category'],
			columnDefinitionName: 'payerCategoryId',
			filterValue: ['Commercial'],
		};
		const updateViewTestData: IUpdateViewTestData = {
			oldName: saveViewTestData.viewName,
			newName: `UPDATED-${saveViewTestData.viewName}`,
		};

		// Act
		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsSection.settings.manageEntitiesSteps.openPayersTab();
		await testSaveView(saveViewTestData);
		await testUpdateViewLink(updateViewTestData);
	});

	test('Create Payer', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test checks that user can create a new Payer (https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/58843).',
		});

		// Arrange
		const payer: IPayer = {
			payerCategoryId: 'Private',
			name: `Autotest-payer-${Date.now()}`,
			primaryPayerId: 'AARP MEDICARE COMPLETE',
			description: 'Lorem ipsum dolor sit amet',
			isGlobal: true,
			canBePrimary: true,
			canBeAncillary: true,
			canBeCoinsurance: true,
			eligibilityProviderKey: '2285 (NBF_HMO) - 1199 National Benefit Fund',
			primaryStateId: 'AL',
			dischargeBillingType: 'Discharge Date',
			requiresAuthorization: true,
			simplifiedAuthorization: true,
			verificationDefaultStartType: 'Current Date',
			isPending: true,
			reviewedOn: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
		};

		// Act
		await stepsCommon.navigation.settings.openManageEntitiesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsSection.settings.manageEntitiesSteps.openPayersTab();
		await stepsCommon.grid.resetView();
		await stepsSection.settings.manageEntitiesSteps.createPayer(payer);
		await stepsCommon.grid.search(payer.name!);

		// Assert
		expect(await stepsCommon.grid.getRowsCount(), `Only one record with Payer name "${payer.name}" found?`).toBe(1);

		// Act
		await stepsCommon.grid.openFirstRecord();
		const actualPayerData: IPayer = await stepsCommon.formReader.getFormData();

		// Assert
		expect.soft(actualPayerData.payerCategoryId, 'Verify "Payer Category"').toBe(payer.payerCategoryId);
		expect.soft(actualPayerData.name, 'Verify "Name"').toBe(payer.name);
		expect.soft(actualPayerData.primaryPayerId, 'Verify "Primary Payer"').toContain(payer.primaryPayerId);
		expect.soft(actualPayerData.description, 'Verify "Description"').toBe(payer.description);
		expect.soft(actualPayerData.isGlobal, 'Verify "Is Global"').toBe(payer.isGlobal);
		expect.soft(actualPayerData.canBePrimary, 'Verify "Can Be Primary"').toBe(payer.canBePrimary);
		expect.soft(actualPayerData.canBeAncillary, 'Verify "Can Be Ancillary"').toBe(payer.canBeAncillary);
		expect.soft(actualPayerData.canBeCoinsurance, 'Verify "Can Be Coinsurance"').toBe(payer.canBeCoinsurance);
		expect
			.soft(payer.eligibilityProviderKey, 'Verify "Eligibility Provider Key"')
			.toContain(actualPayerData.eligibilityProviderKey);
		expect.soft(actualPayerData.primaryStateId, 'Verify "State"').toBe(payer.primaryStateId);
		expect
			.soft(actualPayerData.dischargeBillingType, 'Verify "Discharge Billing Type"')
			.toBe(payer.dischargeBillingType);
		expect
			.soft(actualPayerData.requiresAuthorization, 'Verify "Requires Authorization"')
			.toBe(payer.requiresAuthorization);
		expect.soft(actualPayerData.simplifiedAuthorization, 'Verify "Simplified"').toBe(payer.simplifiedAuthorization);
		expect
			.soft(actualPayerData.verificationDefaultStartType, 'Verify "Verification Default Start Type"')
			.toBe(payer.verificationDefaultStartType);
		expect.soft(actualPayerData.isPending, 'Verify "Is Pending"').toBe(payer.isPending);
	});
});
