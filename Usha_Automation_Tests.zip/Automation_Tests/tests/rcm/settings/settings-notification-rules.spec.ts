import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IRule } from 'src/common/models/index.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe(
	'Settings: Events & Notifications / Notification Rules',
	{ tag: ['@settings', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test("User can't save rule without required fields", async () => {
			test.info().annotations.push({
				type: 'Test',
				description: "This test checks that user can't save rule without filling in the required fields",
			});

			// Act
			await stepsCommon.navigation.settings.openNotificationRulesPage();
			await stepsSection.settings.notificationRulesSteps.clickCreateRuleButton();

			// Assert
			await stepsSection.settings.notificationRulesSteps.verifyFinishButtonIsDisabled();
			await stepsSection.settings.notificationRulesSteps.verifySaveButtonIsDisabled();
		});

		test('User opens existing rule without errors in console', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test opens existing rule and checks the browser console for errors',
			});

			// Arrange
			const consoleErrors: string[] = [];
			page.on('console', (message) => {
				log.info(`Console message: [${message.type()}] ${message.text()}`);
				if (message.type() === 'error') {
					consoleErrors.push(message.text());
				}
			});

			// Act
			await stepsCommon.navigation.settings.openNotificationRulesPage();
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.openFirstRecord();

			// Assert
			expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);
		});

		test('Create a new Notification rule', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks that user can create a new Notification rule with given data',
			});

			// Arrange
			const ruleName = `autotest-rule-${Date.now()}`;
			const expectedRuleData: IRule = {
				ruleName: ruleName,
				facilities: 'Beacon',
				eventTypes: 'Website',
				enabled: false,
				global: false,
				skipSending: true,
				groups: 'Apex Reporting Group',
				facilityContactTypes: 'Building Administrator',
				users: 'ABeecher',
				emails: 'test@langate.com',
				recipientUsers: true,
				sendSingleEmail: true,
				includeInitiator: true,
				excludeInitiator: true,
				digestOfNotifications: true,
				recipientGroupType: 'Recipient Access',
				eventsThreshold: '21',
				schedule: true,
				actions: {
					method: 'Email',
					template: 'Account Created',
				},
			};

			// Act
			await stepsCommon.navigation.settings.openNotificationRulesPage();
			await stepsCommon.grid.resetView();

			if (expectedRuleData.facilities !== undefined) {
				await stepsCommon.facilityFilter.selectPortfolioByExactName(expectedRuleData.facilities);
			}
			await stepsSection.settings.notificationRulesSteps.createRule(expectedRuleData);
			await stepsCommon.grid.search(ruleName);

			const rules: string[][] = await stepsCommon.grid.getColumnTextValues('name');

			// Assert
			expect(rules.length, 'Does the table contain only one record?').toBe(1);
			expect(rules[0]![0], 'Does the table contain the expected rule name?').toBe(ruleName);

			// Act
			await stepsCommon.grid.openFirstRecord();
			const actualRuleData: IRule = await stepsCommon.formReader.getFormData();

			// Assert
			// Compare only fields that are present in the actualRuleData object
			Object.keys(expectedRuleData).forEach((key) => {
				if (key in actualRuleData) {
					expect(actualRuleData[key as keyof IRule], 'Is the rule field equal to expected?').toEqual(
						expectedRuleData[key as keyof IRule]
					);
				}
			});
		});
	}
);
