import { expect, Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/facade-common.steps.js';
import { SectionStepsFacade } from 'src/steps/facade-pages.steps.js';
import {
	testEnumCheckboxFilter,
	testIconsBooleanFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testSortIconsColumn,
	testSortNumericColumn,
	testSortTextColumn,
	testTextFilter,
} from 'src/test-helpers/index.js';

test.describe(
	'Settings -> Entities management grid: column filtering',
	{ tag: ['@settings', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test('Should clear custom filtering for grid column on Payers tab', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks that the custom filter is reset after clicking the button in the column filter',
			});

			// Arrange
			const columnName = 'payerCategoryId';
			const columnsToDisplay = ['Payer Category'];
			const filterValue = ['Medicare'];
			let recordsNumberBeforeFiltering = 0;
			let recordsNumberAfterFiltering = 0;

			await stepsCommon.navigation.settings.openManageEntitiesPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
			await stepsSection.settings.manageEntitiesSteps.openPayersTab();

			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
			await stepsCommon.grid.setPageSize(100);

			// Act
			recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillEnumCheckboxFilter('', filterValue);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberAfterFiltering = await stepsCommon.grid.getTotalRecordCount();

			// Assert
			expect(recordsNumberBeforeFiltering, 'Is the number of records less than before filtering?').not.toBe(
				recordsNumberAfterFiltering
			);

			// Act
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.clearFilter();
			const actualRecordsNumber = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Is the number of records the same as before filtering?').toBe(
				actualRecordsNumber
			);
		});

		test('Should clear custom filtering for grid column on Lookups tab', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'This test checks that the custom filter is reset after clicking the button in the column filter',
			});

			// Arrange
			const columnName = 'lookupNamespaceId';
			const columnsToDisplay = ['Type'];
			const filterValue = ['Address Type'];
			let recordsNumberBeforeFiltering = 0;
			let recordsNumberAfterFiltering = 0;

			await stepsCommon.navigation.settings.openManageEntitiesPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
			await stepsSection.settings.manageEntitiesSteps.openLookupsTab();

			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
			await stepsCommon.grid.setPageSize(100);

			// Act
			recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.fillEnumCheckboxFilter('', filterValue);
			await stepsCommon.columnFilter.applyFilter();
			recordsNumberAfterFiltering = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Is the number of records less than before filtering?').not.toBe(
				recordsNumberAfterFiltering
			);

			// Act
			await stepsCommon.grid.openColumnFilter(columnName);
			await stepsCommon.columnFilter.clearFilter();
			const actualRecordsNumber = await stepsCommon.grid.getTotalRecordCount();
			// Assert
			expect(recordsNumberBeforeFiltering, 'Is the number of records the same as before filtering?').toBe(
				actualRecordsNumber
			);
		});

		// >>> PAYERS GRID

		[
			{
				columnDefinitionName: 'payerCategoryId',
				columnsToDisplay: ['Payer Category', '#', 'Name'],
				filterTitle: '',
				filterValue: 'Medicare',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'managedCareType',
				columnsToDisplay: ['Managed Care Type', '#', 'Name'],
				filterTitle: '',
				filterValue: 'Regular',
				expectedValue: 'Regular',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'managedCareType',
				columnsToDisplay: ['Managed Care Type', '#', 'Name'],
				filterTitle: '',
				filterValue: 'Medicaid Managed Care',
				expectedValue: 'Medicaid',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'managedCareType',
				columnsToDisplay: ['Managed Care Type', '#', 'Name'],
				filterTitle: '',
				filterValue: 'Medicare Managed Care',
				expectedValue: 'Medicare',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test checkbox filters in "Manage Entities Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumCheckboxFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'name',
				columnsToDisplay: ['Name', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'primaryStateName',
				columnsToDisplay: ['State Name', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'primaryPayerName',
				columnsToDisplay: ['Primary Payer Name', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'eligibilityProviderKey',
				columnsToDisplay: ['Eligibility Provider Key', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'created',
				columnsToDisplay: ['Created', '#', 'Payer Category'],
				filterTitle: 'Created By',
				textNodeIndex: 3,
			},
			{
				columnDefinitionName: 'lastUpdated',
				columnsToDisplay: ['Last Updated', '#', 'Payer Category'],
				filterTitle: 'Last Updated By',
				textNodeIndex: 3,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test text filters in "Manage Entities Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testTextFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'payerId',
				columnsToDisplay: ['#', 'Name', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test number filters in "Manage Entities Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testNumberFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'isPending',
				columnsToDisplay: ['Is Pending', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isPending',
				columnsToDisplay: ['Is Pending', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'requiresAuthorization',
				columnsToDisplay: ['Requires Authorization', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'requiresAuthorization',
				columnsToDisplay: ['Requires Authorization', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test radio filters in "Manage Entities Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testIconsBooleanFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'created',
				columnsToDisplay: ['Created', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'lastUpdated',
				columnsToDisplay: ['Last Updated', '#', 'Payer Category'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test date filters in "Manage Entities Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testPresetDateRangeFilter(testData);
			});
		});

		// <<< PAYERS GRID

		// >>> LOOKUPS GRID

		[
			{
				columnDefinitionName: 'lookupId',
				columnsToDisplay: ['#', 'Name', 'Type'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test number filters in "Manage Entities Lookups" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Lookups" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testNumberFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'lookupNamespaceId',
				columnsToDisplay: ['Type', '#', 'Name'],
				filterTitle: '',
				filterValue: 'Task Category',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test checkbox filters in "Manage Entities Lookups" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Lookups" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumCheckboxFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'name',
				columnsToDisplay: ['Name', '#', 'Type'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'code',
				columnsToDisplay: ['Code', '#', 'Type'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'created',
				columnsToDisplay: ['Created', '#', 'Type'],
				filterTitle: 'Created By',
				textNodeIndex: 3,
			},
			{
				columnDefinitionName: 'lastUpdated',
				columnsToDisplay: ['Last Updated', '#', 'Type'],
				filterTitle: 'Last Updated By',
				textNodeIndex: 3,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test text filters in "Manage Entities Lookups" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Lookups" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testTextFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'created',
				columnsToDisplay: ['Created', '#', 'Type'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'lastUpdated',
				columnsToDisplay: ['Last Updated', '#', 'Type'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test date filters in "Manage Entities Lookups" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Lookups" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testPresetDateRangeFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'isApproved',
				columnsToDisplay: ['Approved', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isApproved',
				columnsToDisplay: ['Approved', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test radio filters in "Manage Entities Lookups" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Lookups" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testIconsBooleanFilter(testData);
			});
		});

		// <<< LOOKUPS GRID

		[
			{
				columnDefinitionName: 'type',
				columnsToDisplay: ['Type', '#', 'First Name'],
				filterTitle: '',
				filterValue: 'Doctor',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test checkbox filters in "Manage Entities People" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities People" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectAllPortfolios();
				await stepsSection.settings.manageEntitiesSteps.openPeopleTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumCheckboxFilter(testData);
			});
		});

		[{ columnDefinitionName: 'payerId', columnsToDisplay: ['#', 'Payer Category', 'Name'] }].forEach((testData) => {
			test(`Sort "Manage Entities Payers" grid by field "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Number sorting".`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testSortNumericColumn(testData);
			});
		});

		[{ columnDefinitionName: 'name', columnsToDisplay: ['Name', '#', 'Payer Category'] }].forEach((testData) => {
			test(`Sort "Manage Entities Payers" grid by field "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Text sorting".`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testSortTextColumn(testData);
			});
		});

		[
			{ columnDefinitionName: 'isPending', columnsToDisplay: ['Is Pending', 'Name', '#'] },
			{ columnDefinitionName: 'isGlobal', columnsToDisplay: ['Global', 'Name', '#'] },
		].forEach((testData) => {
			test(`Sort "Manage Entities Payers" grid by field "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Manage Entities Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Icons sorting".`,
				});

				await stepsCommon.navigation.settings.openManageEntitiesPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsSection.settings.manageEntitiesSteps.openPayersTab();
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);

				await testSortIconsColumn(testData);
			});
		});
	}
);
