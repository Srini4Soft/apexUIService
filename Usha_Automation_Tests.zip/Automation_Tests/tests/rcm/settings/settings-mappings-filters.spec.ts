import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testEnumCheckboxFilter, testIconsBooleanFilter, testTextFilter } from 'src/test-helpers/index.js';

test.describe(
	'Settings -> Mappings management grid: column filtering',
	{ tag: ['@settings', '@smoke', '@regression'] },
	() => {
		let page: Page;
		let stepsCommon: CommonStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		[
			{
				columnDefinitionName: 'mappingTypeId',
				columnsToDisplay: ['Type', '#'],
				filterTitle: '',
				filterValue: 'A/R Transaction Type',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'mappingTypeId',
				columnsToDisplay: ['Type', '#'],
				filterTitle: '',
				filterValue: 'Undefined',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'sourceSystem',
				columnsToDisplay: ['Source System', '#'],
				filterTitle: '',
				filterValue: 'Master',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'sourceSystem',
				columnsToDisplay: ['Source System', '#'],
				filterTitle: '',
				filterValue: 'Connectwise',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test checkbox filters in "Mapping List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Mapping List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
				});

				await stepsCommon.navigation.settings.openMappingListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testEnumCheckboxFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'input',
				columnsToDisplay: ['Input', '#'],
				filterTitle: '',
				textNodeIndex: 0,
			},
			{
				columnDefinitionName: 'bindedOutput',
				columnsToDisplay: ['Output', '#'],
				filterTitle: '',
				textNodeIndex: 0,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test text filters in "Mapping List" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Mapping List" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
				});

				await stepsCommon.navigation.settings.openMappingListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testTextFilter(testData);
			});
		});

		[
			{
				columnDefinitionName: 'isDisabled',
				columnsToDisplay: ['Disabled', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isDisabled',
				columnsToDisplay: ['Disabled', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'True',
				expectedIcon: true,
				expectedValue: 'success',
				textNodeIndex: undefined,
			},
			{
				columnDefinitionName: 'isGlobal',
				columnsToDisplay: ['Global', '#'],
				filterTitle: '',
				filterValue: 'False',
				expectedIcon: true,
				expectedValue: 'cancel',
				textNodeIndex: undefined,
			},
		].forEach((testData: IColumnFilterTestData) => {
			test(`Test radio filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
				});

				await stepsCommon.navigation.settings.openMappingListPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(25);

				await testIconsBooleanFilter(testData);
			});
		});
	}
);
