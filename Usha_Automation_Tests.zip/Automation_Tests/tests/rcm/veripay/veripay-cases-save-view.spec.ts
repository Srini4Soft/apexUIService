import { expect, Locator, Page } from '@playwright/test';
import { FilterConditions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Veripay -> Cases grid: column filtering', { tag: ['@veripay', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
		await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Save view', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates a custom filter and saves the view. Afterwards, it resets the view and applies the saved settings.',
		});

		// Arrange
		const columnsToDisplay = ['Assets', 'Full Name', 'Total Income'];
		const filteredColumn = ['Last Medicaid Application', 'Assets', 'Total Amount'];
		const viewName = `AT-${Date.now()}`;

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();

		// Act
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionInput(filteredColumn, FilterConditions.GREATER_THEN, '500');
		await stepsCommon.customFilter.apply();
		await stepsCommon.grid.saveView(viewName);
		const expectRecordsNumber = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.applyView(viewName);
		const actualRecordsNumber = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(actualRecordsNumber, 'Is the number of records in the table the same?').toBe(expectRecordsNumber);
	});

	test('Delete view', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test creates and saves the view. Afterwards, it deletes the view and checks that the view is not on the list.',
		});

		// Arrange
		const columnsToDisplay = ['#', 'Assets', 'Full Name', 'Total Income'];
		const viewName = `AT-${Date.now()}`;

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();

		// Act
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.saveView(viewName);
		await stepsCommon.profileMenu.viewAllLinks();
		await stepsCommon.grid.search(viewName);
		await stepsCommon.grid.performRowAction(1, 'Delete');
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.search(viewName);
		const actualRecordsNumber = await stepsCommon.grid.getRowsCount();

		// Assert
		expect(actualRecordsNumber, 'Is table empty?').toBe(0);
	});

	test('Compare cases', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates a custom filters and saves the views. Afterwards, it compares saved views.',
		});

		// Arrange
		const columnsToDisplay = ['Assets', 'Full Name', 'Total Income'];
		const filteredColumn = ['Last Medicaid Application', 'Assets', 'Total Amount'];
		const firstView = `AT-${Date.now()}`;
		const secondView = `AT-${Date.now() + 1}`;

		// Act
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionInput(filteredColumn, FilterConditions.GREATER_THEN, '500');
		await stepsCommon.customFilter.apply();
		await stepsCommon.grid.saveView(firstView);

		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionInput(filteredColumn, FilterConditions.GREATER_THEN, '1000');
		await stepsCommon.customFilter.apply();
		await stepsCommon.grid.saveView(secondView);

		await stepsCommon.grid.resetView();
		await stepsCommon.grid.openCompareListConditions();
		await stepsCommon.conditionComparison.compareListConditions(firstView, secondView);
		const parentWindow: Locator = stepsCommon.conditionComparison.getWindowLocator();

		// Assert
		await stepsCommon.conditionComparison.openAllCasesChangesTab();
		expect(
			await stepsCommon.grid.getTotalRecordCount(parentWindow),
			'Does number on the badge match the total number of records?'
		).toBe(await stepsCommon.conditionComparison.getAllCasesChangesBadgeText());
		await stepsCommon.grid.verifyMenuButtonIsVisible();
		await stepsCommon.grid.verifySearchButtonIsVisible();
		await stepsCommon.grid.verifySelectAllButtonIsVisible();
		await stepsCommon.grid.verifyPageSizeSelectorIsVisible(parentWindow);
		await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
		await stepsCommon.grid.verifyPagesListIsVisible();
		await stepsCommon.grid.verifyNextPageButtonIsVisible();

		await stepsCommon.conditionComparison.openAddedCasesTab();
		expect(
			await stepsCommon.grid.getTotalRecordCount(parentWindow),
			'Does number on the badge match the total number of records?'
		).toBe(await stepsCommon.conditionComparison.getAddedCasesBadgeText());
		await stepsCommon.grid.verifyMenuButtonIsVisible();
		await stepsCommon.grid.verifySearchButtonIsVisible();
		await stepsCommon.grid.verifySelectAllButtonIsVisible();
		await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
		await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
		await stepsCommon.grid.verifyPagesListIsVisible();
		await stepsCommon.grid.verifyNextPageButtonIsVisible();

		await stepsCommon.conditionComparison.openRemovedCasesTab();
		expect(
			await stepsCommon.grid.getTotalRecordCount(parentWindow),
			'Does number on the badge match the total number of records?'
		).toBe(await stepsCommon.conditionComparison.getRemovedCasesBadgeText());
		await stepsCommon.grid.verifyMenuButtonIsVisible();
		await stepsCommon.grid.verifySearchButtonIsVisible();
		await stepsCommon.grid.verifySelectAllButtonIsVisible();
		await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
		await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
		await stepsCommon.grid.verifyPagesListIsVisible();
		await stepsCommon.grid.verifyNextPageButtonIsVisible();
	});
});
