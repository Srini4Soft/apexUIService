import { expect, Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IVeripayCase } from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Veripay -> Create Veripay Case', { tag: ['@rts', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Create new veripay case', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that it is possible to create a new veripay case that is not in the search.',
		});

		// Arrange
		let newCase: IVeripayCase = {
			facilityId: 'Demo Facility',
			lastName: `autotest-case-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();

		// new
		await stepsSection.veripay.casesSteps.createCase(newCase);

		// Assert
		await expect(page).toHaveURL(/\/v2\/veripay\/cases\/details\/\d+\/case/);
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		expect(await stepsCommon.grid.getTotalRecordCount()).toBe(1);
	});
});
