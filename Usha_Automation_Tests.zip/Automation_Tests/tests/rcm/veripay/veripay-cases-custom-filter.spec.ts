import { expect, Page } from '@playwright/test';
import { FilterConditions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';

test.describe('Veripay -> Cases grid: custom filters', { tag: ['@veripay', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
		await stepsCommon.facilityFilter.selectPortfolioByName('Demo');
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Custom filter for "Census Status" column', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test filters "Census Status" column',
		});

		// Arrange
		const columnName = 'censusStatus';
		const columnsToDisplay = ['Census Status'];
		const filteredColumn = ['Resident', 'Census Status'];
		let filteredCellValuesBeforeSorting: string[][] = [];
		let filteredCellValuesAfterSorting: string[][] = [];
		const filterValues = {
			UNDEFINED: 'Undefined',
			ACTIVE: 'Active',
			INACTIVE: 'Inactive',
		};

		// Act
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		const recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionSelect(filteredColumn, FilterConditions.EQUALS, filterValues.UNDEFINED);
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[0] === filterValues.UNDEFINED)).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[0] === filterValues.UNDEFINED)).toBe(true);

		// Act
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionSelect(filteredColumn, FilterConditions.EQUALS, filterValues.ACTIVE);
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[0] === filterValues.ACTIVE)).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[0] === filterValues.ACTIVE)).toBe(true);

		// Act
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionSelect(filteredColumn, FilterConditions.EQUALS, filterValues.INACTIVE);
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[0] === filterValues.INACTIVE)).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[0] === filterValues.INACTIVE)).toBe(true);

		// Act
		await stepsCommon.grid.resetGridFilters();
		const recordsNumberAfterResetFilter = await stepsCommon.grid.getTotalRecordCount();
		// Assert
		expect(recordsNumberAfterResetFilter, 'Is the number of records in the table the same?').toBe(
			recordsNumberBeforeFiltering
		);
	});

	test('Custom filter for "Facility Name" column', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test filters "Facility Name" column',
		});

		// Arrange
		const columnName = 'facility';
		const columnsToDisplay = ['Facility'];
		const filteredColumn = ['Resident', 'Facility', 'Name'];
		let filteredCellValuesBeforeSorting: string[][] = [];
		let filteredCellValuesAfterSorting: string[][] = [];
		const filterValues = ['Demo', 'Beacon'];

		// Act
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		await stepsCommon.facilityFilter.selectMultiplePortfolios(filterValues);
		const recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionInput(filteredColumn, FilterConditions.EQUALS, filterValues[0]!);
		await stepsCommon.customFilter.apply();
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);

		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[1] === filterValues[0])).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[1] === filterValues[0])).toBe(true);

		// Act
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionInput(filteredColumn, FilterConditions.EQUALS, filterValues[1]!);
		await stepsCommon.customFilter.apply();
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);

		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[1] === filterValues[1])).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[1] === filterValues[1])).toBe(true);

		// Act
		await stepsCommon.grid.resetGridFilters();
		const recordsNumberAfterResetFilter = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(recordsNumberAfterResetFilter, 'Is the number of records in the table the same?').toBe(
			recordsNumberBeforeFiltering
		);
	});

	test('Custom filter for "MCD App Status" column', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test filters "MCD App Status Name" column',
		});

		// Arrange
		const columnName = 'lastMedicaidApplication_status';
		const columnsToDisplay = ['#', 'Full Name', 'MCD App Status'];
		const filteredColumn = ['Last Medicaid Application', 'Medicaid Application Status Id'];
		const filterValue = 'Pending';
		let filteredCellValuesBeforeSorting: string[][] = [];
		let filteredCellValuesAfterSorting: string[][] = [];

		// Act
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.addConditionSelect(filteredColumn, FilterConditions.EQUALS, filterValue);
		const recordsNumberBeforeFiltering = await stepsCommon.grid.getTotalRecordCount();
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[0] === filterValue)).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[0] === filterValue)).toBe(true);

		// Act
		await stepsCommon.grid.openCustomFilter();
		const expression = await stepsCommon.customFilter.getExpression();
		await stepsCommon.customFilter.close();
		await stepsCommon.grid.resetGridFilters();
		await stepsCommon.grid.openCustomFilter();
		await stepsCommon.customFilter.setExpression(expression);
		await stepsCommon.customFilter.apply();
		const recordsNumberAfterFiltering = await stepsCommon.grid.getTotalRecordCount();
		filteredCellValuesBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		filteredCellValuesAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		// Assert
		expect(filteredCellValuesBeforeSorting.every((value) => value[0] === filterValue)).toBe(true);
		expect(filteredCellValuesAfterSorting.every((value) => value[0] === filterValue)).toBe(true);
		expect(recordsNumberAfterFiltering, 'Is the number of records in the table the same?').toBe(
			recordsNumberBeforeFiltering
		);
	});
});
