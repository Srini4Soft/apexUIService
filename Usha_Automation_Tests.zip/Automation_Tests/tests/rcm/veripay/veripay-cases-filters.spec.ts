import { expect, Page } from '@playwright/test';
import { SortingOrder } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import {
	testEnumCheckboxFilter,
	testEnumRadioFilter,
	testMultiEnumCheckboxFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testSortDateColumn,
	testSortNumericColumn,
	testSortTextColumn,
	testTextFilter,
} from 'src/test-helpers/index.js';

test.describe('Veripay -> Cases grid: column filtering', { tag: ['@veripay', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	const patternPositive: RegExp = /^\$\d{1,3}(,\d{3})*\.\d{2}$/; // RegExp for: $1.00, $22.00, $999.99, $4,788.00, $65,654,722,322.00
	const patternNegative: RegExp = /^(\(\$\d{1,3}(,\d{3})*\.\d{2}\)|)$/; // RegExp for: ($0.00), ($22.00), ($999.99)
	const patternBlank: RegExp = /^$|^\.\.\.$/; // RegExp for: not empty string or '...'
	const patterNotBlank: RegExp = /\S+/; // RegExp for: not empty string
	const patternOnlyZeroNegative: RegExp = /^\(\$0\.00\)$/; // RegExp for: ($0.00)

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	[
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Case Id',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Resident Id',
			textNodeIndex: 1,
		},
		{
			columnDefinitionName: 'payerCoPayment',
			columnsToDisplay: ['Co-pay', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'outstandingBalance',
			columnsToDisplay: ['A/R', '#', 'Full Name', 'Payer'],
			filterTitle: 'A/R',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test number filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testNumberFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Name',
			filterValue: 'Private Pay',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'medicaidNumber',
			columnsToDisplay: ['MCD #', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'medicareNumber',
			columnsToDisplay: ['MCR #', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'ssn',
			columnsToDisplay: ['SSN', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		// Need FIX. Now "MCD App Login" contains values with spaces before and after word.
		// {
		// 	columnDefinitionName: 'lastMedicaidApplication_login',
		// 	columnsToDisplay: ['MCD App Login', '#', 'Full Name', 'Payer'],
		// 	filterTitle: 'App Username',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'description',
			columnsToDisplay: ['Post-It', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'MS MCD',
			textNodeIndex: 0,
		},
		// {
		// 	// NEED MORE INFO
		// 	columnDefinitionName: 'arNotes',
		// 	columnsToDisplay: ['A/R Notes', '#', 'Full Name', 'Payer'],
		// 	filterType: 'eye',
		// 	filterTitle: 'A/R Notes',
		// 	filterValue: 'MCR',
		// 	sortingColumn: '#',
		// 	textNodeIndex: 0,
		// } as IColumnFilterTestData,
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Category',
			filterValue: 'Commercial',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Category',
			filterValue: 'Medicare',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'ancillaryPayer',
			columnsToDisplay: ['Ancillary Payer', '#', 'Full Name', 'Payer'],
			filterTitle: 'Payer Category',
			filterValue: 'Commercial',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'tags',
			columnsToDisplay: ['Tags', '#', 'Full Name', 'Payer'],
			filterTitle: 'Scope',
			filterValue: 'General',
			filterType: 'eye',
			expectedValue: 'General:',
			sortingColumn: '#',
			textNodeIndex: 0,
		} as IColumnFilterTestData,
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test multi checkbox filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default multi checkbox filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testMultiEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Last Medicaid Application Status',
			filterValue: 'Pending',
			textNodeIndex: undefined,
			expectedValue: 'MCD App: Medicaid Pending',
		},
		{
			columnDefinitionName: 'totalIncome',
			columnsToDisplay: ['Total Income', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Positive Income',
			expectedPattern: patternPositive,
			textNodeIndex: undefined,
		},
		// {
		// 	// DATA PROBLEM: INCOME RECORDS PRESENT
		// 	columnDefinitionName: 'totalIncome',
		// 	columnsToDisplay: ['Total Income', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	filterValue: 'No Income',
		// 	expectedPattern: patternNegative,
		// 	textNodeIndex: undefined,
		// },
		{
			columnDefinitionName: 'totalIncome',
			columnsToDisplay: ['Total Income', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Income Not Entered',
			expectedPattern: patternBlank,
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tasks',
			columnsToDisplay: ['Tasks', '#', 'Full Name', 'Payer'],
			filterTitle: 'Task Status',
			filterValue: 'Not Started',
			expectedIcon: true,
			sortingColumn: '#',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tasks',
			columnsToDisplay: ['Tasks', '#', 'Full Name', 'Payer'],
			filterTitle: 'Task Status',
			filterValue: 'In Progress',
			expectedIcon: true,
			sortingColumn: '#',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tasks',
			columnsToDisplay: ['Tasks', '#', 'Full Name', 'Payer'],
			filterTitle: 'Task Status',
			filterValue: 'Completed',
			expectedIcon: true,
			sortingColumn: '#',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tasks',
			columnsToDisplay: ['Tasks', '#', 'Full Name', 'Payer'],
			filterTitle: 'Task Status',
			filterValue: 'Waiting',
			expectedIcon: true,
			sortingColumn: '#',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tasks',
			columnsToDisplay: ['Tasks', '#', 'Full Name', 'Payer'],
			filterTitle: 'Task Status',
			filterValue: 'Cancelled',
			expectedIcon: true,
			sortingColumn: '#',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Tracked',
			expectedValue: 'TRACKED',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Tracking Stopped',
			expectedValue: 'Not Tracked',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Never Tracked',
			expectedValue: 'Not Tracked',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'isTracked',
			columnsToDisplay: ['Is Tracked', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Tracked',
			expectedValue: 'success',
			expectedIcon: true,
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'paymentMethod',
			columnsToDisplay: ['Payment Method', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Personal Check',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Available Income', '#', 'Full Name', 'Payer'],
			filterTitle: 'Income',
			filterValue: 'Positive Income',
			expectedPattern: patternPositive,
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Available Income', '#', 'Full Name', 'Payer'],
			filterTitle: 'Income',
			filterValue: 'Negative Income',
			expectedPattern: patternNegative,
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Available Income', '#', 'Full Name', 'Payer'],
			filterTitle: 'Income',
			filterValue: 'Unknown Income',
			textNodeIndex: 0,
		},
		// Need investigation. Possibly fix in testEnumCheckboxFilter()
		// {
		// 	columnDefinitionName: 'arNotes',
		// 	columnsToDisplay: ['A/R Notes', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	filterValue: 'Hide Cases Without Notes',
		// 	expectedPattern: patterNotBlank,
		// 	sortingColumn: '#',
		// 	textNodeIndex: undefined,
		// },
		// {
		//	// NEED MORE INFO
		// 	columnDefinitionName: 'arNotes',
		// 	columnsToDisplay: ['A/R Notes', '#', 'Full Name', 'Payer', 'Payer Category'],
		// 	filterType: 'eye',
		// 	filterTitle: 'Payer Category',
		// 	filterValue: 'Medicaid',
		// 	textNodeIndex: undefined,
		// 	sortingColumn: '#',
		// 	columnForCheck: 'payerCategory',
		// } as IColumnFilterTestData,
		// {
		// 	// BUG: ADDING A COLUMN CAUSES THE GRID TO FREEZE
		// 	columnDefinitionName: 'workflows',
		// 	columnsToDisplay: ['Case Workflows', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	filterValue: 'QIT',
		// 	sortingColumn: '#',
		// 	textNodeIndex: undefined,
		// },
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'asset',
			columnsToDisplay: ['Assets', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Positive Asset',
			expectedPattern: patternPositive,
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'asset',
			columnsToDisplay: ['Assets', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'No Asset',
			expectedPattern: patternOnlyZeroNegative,
			textNodeIndex: undefined,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test radio filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumRadioFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'lastMedicaidApplication_submissionDate',
			columnsToDisplay: ['MCD App Submission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastMedicaidApplication_expectedEffectiveDate',
			columnsToDisplay: ['MCD App Effective Date (MCD SOS)', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastMedicaidApplication_appExpirationDate',
			columnsToDisplay: ['MCD App Expiration Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerEffectiveDate',
			columnsToDisplay: ['Payer Effective Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'prospectiveDischargeDate',
			columnsToDisplay: ['Prospective Discharge Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		// {
		// 	BUGGED NOW
		// 	columnDefinitionName: 'payerPaidThrough',
		// 	columnsToDisplay: ['Paid Through', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'payerCoInsSnfEndOn',
			columnsToDisplay: ['MCR 100th Day', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 2,
		},
		{
			columnDefinitionName: 'lastCoveredDay',
			columnsToDisplay: ['Last Covered Day', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test date filters in "Veripay Cases" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testPresetDateRangeFilter(testData);
		});
	});

	[
		{ columnDefinitionName: '#', columnsToDisplay: ['#', 'Full Name'], filterTitle: '', textNodeIndex: 0 },
		{
			columnDefinitionName: 'payerCoPayment',
			columnsToDisplay: ['Co-pay', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'outstandingBalance',
			columnsToDisplay: ['A/R', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'totalIncome',
			columnsToDisplay: ['Total Income', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'asset',
			columnsToDisplay: ['Assets', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Sort numeric columns in "Veripay Cases" grid by "${testData.columnsToDisplay[0]}"`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Number sorting".`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(50);
			await testSortNumericColumn(testData);
		});
	});

	[
		{
			columnDefinitionName: 'lastMedicaidApplication_submissionDate',
			columnsToDisplay: ['MCD App Submission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastMedicaidApplication_expectedEffectiveDate',
			columnsToDisplay: ['MCD App Effective Date (MCD SOS)', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastMedicaidApplication_appExpirationDate',
			columnsToDisplay: ['MCD App Expiration Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerEffectiveDate',
			columnsToDisplay: ['Payer Effective Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'prospectiveDischargeDate',
			columnsToDisplay: ['Prospective Discharge Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerPaidThrough',
			columnsToDisplay: ['Paid Through', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerCoInsSnfEndOn',
			columnsToDisplay: ['MCR 100th Day', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 2,
		},
		{
			columnDefinitionName: 'lastCoveredDay',
			columnsToDisplay: ['Last Covered Day', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		// BUG
		// {
		// 	columnDefinitionName: 'payerAuthorizedThru',
		// 	columnsToDisplay: ['Authorized Thru', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'birthDate',
			columnsToDisplay: ['Birth Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Sort date columns in "Veripay Cases" grid by "${testData.columnsToDisplay[0]}"`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Date sorting".`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(50);
			await testSortDateColumn(testData);
		});
	});

	[
		{
			columnDefinitionName: 'medicaidNumber',
			columnsToDisplay: ['MCD #', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'medicareNumber',
			columnsToDisplay: ['MCR #', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{ columnDefinitionName: 'ssn', columnsToDisplay: ['SSN', '#', 'Full Name'], filterTitle: '', textNodeIndex: 0 },
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'paymentMethod',
			columnsToDisplay: ['Payment Method', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Sort text columns in "Veripay Cases" grid by "${testData.columnsToDisplay[0]}"`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Cases" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Text sorting".`,
			});

			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(50);
			await testSortTextColumn(testData);
		});
	});

	test(`Filter columns in "Veripay Cases" grid by "Authorized Thru" using "Lapsed" filter`, async () => {
		test.info().annotations.push({
			type: 'Test',
			description: `This test opens "Veripay Cases" grid and sorts "Authorized Thru" and "Lapsed" filter. Column uses custom filter.`,
		});

		const columnsToDisplay: string[] = ['Authorized Thru', '#', 'Full Name'];
		const columnDefinitionName: string = 'payerAuthorizedThru';
		const filterTitle: string = 'Lapsed';
		const expectedValue: string = 'triangle-exclamation';

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.facilityFilter.selectMultiplePortfolios(['Demo', 'Lexington']);
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(50);

		await stepsCommon.grid.openColumnFilter(columnDefinitionName);
		await stepsCommon.columnFilter.fillCustomCheckboxFilter(filterTitle);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.sortColumn(columnDefinitionName, SortingOrder.DESCENDING);
		const filteredCellValuesDesSorting = await stepsCommon.grid.getColumnIconValues(columnDefinitionName);
		await stepsCommon.grid.sortColumn(columnDefinitionName, SortingOrder.ASCENDING);
		const filteredCellValuesAscSorting = await stepsCommon.grid.getColumnIconValues(columnDefinitionName);

		filteredCellValuesDesSorting.forEach((array) =>
			expect
				.soft(array[0]?.toLowerCase(), `Actual icon "${array[0]}" should match the expected icon "${expectedValue}"`)
				.toBe(expectedValue?.toLowerCase())
		);
		filteredCellValuesAscSorting.forEach((array) =>
			expect
				.soft(array[0]?.toLowerCase(), `Actual icon "${array[0]}" should match the expected icon "${expectedValue}"`)
				.toBe(expectedValue?.toLowerCase())
		);
	});

	test.fail(`Filter columns in "Veripay Cases" grid by "Authorized Thru" using "Expiring Soon" filter`, async () => {
		test.info().annotations.push({
			type: 'Test',
			description: `This test opens "Veripay Cases" grid and sorts "Authorized Thru" and "Expiring Soon" filter. Column uses custom filter.`,
		});

		const columnsToDisplay: string[] = ['Authorized Thru', '#', 'Full Name'];
		const columnDefinitionName: string = 'payerAuthorizedThru';
		const filterTitle: string = 'Expiring Soon';
		const filterValue: string = '99';
		const today = new Date();
		today.setHours(0, 0, 0, 0);
		const maxDate = new Date(today);
		maxDate.setDate(maxDate.getDate() + Number(filterValue));

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(50);

		await stepsCommon.grid.openColumnFilter(columnDefinitionName);
		await stepsCommon.columnFilter.fillCustomCheckboxFilter(filterTitle, filterValue);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.sortColumn(columnDefinitionName, SortingOrder.DESCENDING);
		const filteredCellValuesDesSorting = await stepsCommon.grid.getColumnTextValues(columnDefinitionName);
		await stepsCommon.grid.sortColumn(columnDefinitionName, SortingOrder.ASCENDING);
		const filteredCellValuesAscSorting = await stepsCommon.grid.getColumnTextValues(columnDefinitionName);

		filteredCellValuesDesSorting.forEach((array) => {
			const dateStr = array[0]!.trim();
			const parsed = new Date(dateStr);
			expect.soft(isNaN(parsed.getTime()), `Invalid date format: "${dateStr}"`).toBeFalsy();
			parsed.setHours(0, 0, 0, 0);

			expect
				.soft(parsed.getTime(), `Actual date "${dateStr}" is less than today's (${today.toLocaleDateString()})`)
				.toBeGreaterThanOrEqual(today.getTime());
			expect
				.soft(parsed.getTime(), `Actual date "${dateStr}" is later than max date (${maxDate.toLocaleDateString()})`)
				.toBeLessThanOrEqual(maxDate.getTime());
		});
		filteredCellValuesAscSorting.forEach((array) => {
			const dateStr = array[0]!.trim();
			const parsed = new Date(dateStr);
			expect.soft(isNaN(parsed.getTime()), `Invalid date format: "${dateStr}"`).toBeFalsy();
			parsed.setHours(0, 0, 0, 0);

			expect
				.soft(parsed.getTime(), `Actual date "${dateStr}" is less than today's (${today.toLocaleDateString()})`)
				.toBeGreaterThanOrEqual(today.getTime());
			expect
				.soft(parsed.getTime(), `Actual date "${dateStr}" is later than max date (${maxDate.toLocaleDateString()})`)
				.toBeLessThanOrEqual(maxDate.getTime());
		});
	});
});
