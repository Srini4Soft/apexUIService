import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbsMvc } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the Business Intelligence section',
	{ tag: ['@fcc', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for Business Intelligence -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openDashboardPage();
			await stepsCommon.dashboard.selectDashboardByPositionNumberMvc();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Dashboard');
			await stepsCommon.dashboard.verifyDashboardSettingsButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> A/R page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openArPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'A/R');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> A/R Trend page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openArTrendPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'A/R Trend');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> % Collected page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCollectedPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', '% Collected');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> % Collected Trend page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCollectedTrendPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', '% Collected Trend');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> Cash vs. Prior Revenue page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCashVsPriorRevenuePage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'Cash vs. Prior Revenue');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> Cash vs. Revenue page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCashVsRevenuePage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'Cash vs. Revenue');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> Cash vs. Revenue Trend page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCashVsRevenueTrendPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'Cash vs. Revenue Trend');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> Revenue Trend page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openRevenueTrendPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'Revenue Trend');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> Cash Receipts Trend page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openCashReceiptsTrendPage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'Cash Receipts Trend');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> DSO Debit Balance page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openDsoDebitBalancePage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'DSO Debit Balance');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});

		test('UI checks for Business Intelligence -> DSO Net Balance page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.bi.openDsoNetBalancePage();

			// Assert
			expect.soft(consoleErrors.length, 'Is the console error list empty?').toBe(0);
			await testBreadcrumbsMvc('Business Intelligence', 'Revenue Cycle Management', 'DSO Net Balance');
			await stepsCommon.grid.verifyMenuButtonIsVisibleMvc();
		});
	}
);
