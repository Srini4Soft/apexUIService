import { expect, Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Veripay: Upload documents', { tag: ['@fcc', '@veripay', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	['test.txt', 'test.pdf'].forEach((fileName: string) => {
		test(`Upload "${fileName}" file document to the case`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `Upload "${fileName}" file in the "Documents" tab in the veripay case details.`,
			});

			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.navigation.veripay.openCasesPage();
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.openFirstRecord();
			await stepsSection.veripay.caseDetailsSteps.openDocumentsTab();

			const initialDocumentsCount: number = await stepsCommon.grid.getRowsCount();

			await stepsSection.veripay.caseDetailsSteps.uploadFile(`./tests/fcc/test-data/${fileName}`);

			const message: string = await stepsCommon.toaster.getMessage();
			const actualDocumentsCount: number = await stepsCommon.grid.getRowsCount();
			const documentNames: string[][] = await stepsCommon.grid.getColumnTextValues('name');

			expect(message).toBe('File successfully uploaded');
			expect(actualDocumentsCount).toBeGreaterThan(initialDocumentsCount);
			expect(documentNames.flat()).toContain(fileName);
		});
	});
});
