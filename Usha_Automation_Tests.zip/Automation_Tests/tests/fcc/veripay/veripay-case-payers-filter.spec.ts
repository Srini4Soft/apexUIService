import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/facade-common.steps.js';
import {
	testEnumCheckboxFilter,
	testMultiEnumCheckboxFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testSortDateColumn,
	testSortNumericColumn,
	testSortTextColumn,
	testTextFilter,
} from 'src/test-helpers/index.js';

test.describe('Veripay -> Cases grid: column filtering', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	[
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Case Id',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Resident Id',
			textNodeIndex: 1,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test number filters in "Veripay Case Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testNumberFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Name',
			filterValue: 'Private',
			textNodeIndex: undefined,
		},
		// BUG
		// {
		// 	columnDefinitionName: 'medicaidNumber',
		// 	columnsToDisplay: ['MCD #', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		// BUG
		// {
		// 	columnDefinitionName: 'medicareNumber',
		// 	columnsToDisplay: ['MCR #', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'ssn',
			columnsToDisplay: ['SSN', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastName',
			columnsToDisplay: ['Last Name', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'firstName',
			columnsToDisplay: ['First Name', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'middleName',
			columnsToDisplay: ['Middle Name', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text filters in "Veripay Case Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Category',
			filterValue: 'Commercial',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Category',
			filterValue: 'Medicare',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test multi checkbox filters in "Veripay Case Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default multi checkbox filter.`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testMultiEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Tracked',
			expectedValue: 'TRACKED',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Tracking Stopped',
			expectedValue: 'Not Tracked',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'tracking',
			columnsToDisplay: ['Tracking', '#', 'Full Name', 'Payer'],
			filterTitle: 'Is Tracked',
			filterValue: 'Never Tracked',
			expectedValue: 'Not Tracked',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'isTracked',
			columnsToDisplay: ['Is Tracked', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Tracked',
			expectedValue: 'success',
			expectedIcon: true,
			textNodeIndex: undefined,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox filters in "Veripay Case Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'admissionDate',
			columnsToDisplay: ['Admission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'dischargeDate',
			columnsToDisplay: ['Discharge Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerEndDate',
			columnsToDisplay: ['Payer End Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'birthDate',
			columnsToDisplay: ['Birth Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastAdmissionDate',
			columnsToDisplay: ['Last Admission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test date filters in "Veripay Case Payers" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testPresetDateRangeFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'admissionDate',
			columnsToDisplay: ['Admission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'dischargeDate',
			columnsToDisplay: ['Discharge Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payerEndDate',
			columnsToDisplay: ['Payer End Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'birthDate',
			columnsToDisplay: ['Birth Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastAdmissionDate',
			columnsToDisplay: ['Last Admission Date', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData) => {
		test(`Sort date columns in "Veripay Case Payers" grid by "${testData.columnsToDisplay[0]}"`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Date sorting".`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(50);
			await testSortDateColumn(testData);
		});
	});

	[{ columnDefinitionName: '#', columnsToDisplay: ['#', 'Full Name'], filterTitle: '', textNodeIndex: 0 }].forEach(
		(testData) => {
			test(`Sort numeric columns in "Veripay Case Payers" grid by "${testData.columnsToDisplay[0]}"`, async () => {
				test.info().annotations.push({
					type: 'Test',
					description: `This test opens "Veripay Case Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Number sorting".`,
				});

				await stepsCommon.navigation.veripay.openCasePayersPage();
				await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
				await stepsCommon.grid.resetView();
				await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
				await stepsCommon.grid.setPageSize(50);
				await testSortNumericColumn(testData);
			});
		}
	);

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		// BUG
		// {
		// 	columnDefinitionName: 'medicaidNumber',
		// 	columnsToDisplay: ['MCD #', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		// BUG
		// {
		// 	columnDefinitionName: 'medicareNumber',
		// 	columnsToDisplay: ['MCR #', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'ssn',
			columnsToDisplay: ['SSN', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		// BUG
		// {
		// 	columnDefinitionName: 'lastName',
		// 	columnsToDisplay: ['Last Name', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		// BUG
		// {
		// 	columnDefinitionName: 'firstName',
		// 	columnsToDisplay: ['First Name', '#', 'Full Name', 'Payer'],
		// 	filterTitle: '',
		// 	textNodeIndex: 0,
		// },
		{
			columnDefinitionName: 'middleName',
			columnsToDisplay: ['Middle Name', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData) => {
		test(`Sort text columns in "Veripay Case Payers" grid by "${testData.columnsToDisplay[0]}"`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Veripay Case Payers" grid and sorts "${testData.columnsToDisplay[0]}". Column uses "Text sorting".`,
			});

			await stepsCommon.navigation.veripay.openCasePayersPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(50);
			await testSortTextColumn(testData);
		});
	});
});
