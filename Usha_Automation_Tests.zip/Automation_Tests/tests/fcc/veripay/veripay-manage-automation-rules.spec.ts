import { expect, Page } from '@playwright/test';
import { ApiClient } from 'src/common/api-client/api-client.js';
import { RuleActions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import {
	IAddCaseNoteAction,
	IAddCasePayerAction,
	IAddCaseTagAction,
	IAddMedicaidApplicationAction,
	IAutomationRule,
	ICaseTrackingStatusTypeAction,
	ICompleteTaskAction,
	ICondition,
	ICreateTaskAction,
	ICreateWorkflowInstanceAction,
	IRemoveCasePayerAction,
	IRemoveCaseTagAction,
	ISetValueAutomationAction,
	IVeripayCase,
	IVeripayCaseDetails,
} from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Veripay -> Settings: manage automation rules', { tag: ['@rcm'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Create automation rule with "note" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Note" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-note-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		// Arrange
		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let addCaseNote: IAddCaseNoteAction = {
			message: `Automation test note ${Date.now()}`,
			isAggregateMessage: false,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.ADD_CASE_NOTE,
			addCaseNote
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		let currentNotes: string[] = await stepsSection.veripay.caseDetailsSteps.getCurrentNotes();
		expect(currentNotes).toContain(addCaseNote.message);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create automation rule with "case payer" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Case Payer" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-payer-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let addCasePayer: IAddCasePayerAction = {
			payerRole: 'Primary Payer',
			payerCategory: 'Private',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.ADD_CASE_PAYER,
			addCasePayer
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		let payersNumber = await stepsSection.veripay.caseDetailsSteps.getPayersNumber();
		expect(payersNumber).toBe(2);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create automation rule with "case tag" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Case Tag" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-tag-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let addCaseTag: IAddCaseTagAction = {
			scope: 'General',
			lookupId: 'Long Term',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.ADD_CASE_TAG,
			addCaseTag
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const activeTags = await stepsSection.veripay.caseDetailsSteps.getActiveCaseTerms();
		expect(activeTags).toContain(addCaseTag.lookupId);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create automation rule with "medicaid application" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Medicaid Application" action',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-medicaid-app-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let addMedicaidApplication: IAddMedicaidApplicationAction = {};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.ADD_MEDICAID_APPLICATION,
			addMedicaidApplication
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const medicareApps = await stepsSection.veripay.caseDetailsSteps.getMedicaidAppsNumber();
		expect(medicareApps).toBe(1);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test.skip('Create automation rule with "create task" and "complete task" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Create Task" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-create-task-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let createTaskAction: ICreateTaskAction = {
			title: `Automation task name ${Date.now()}`,
			lookupTaskCategoryId: '1 No Primary Payers',
		};

		let completeTaskAction: ICompleteTaskAction = {};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.CREATE_TASK,
			createTaskAction
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const tasks = await stepsSection.veripay.caseDetailsSteps.getTaskList();
		expect(tasks).toEqual(expect.arrayContaining([expect.objectContaining({ title: createTaskAction.title })]));

		// Act
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.openColumnFilter('name');
		await stepsCommon.columnFilter.fillTextFilter('', 'Equals', automationRule.name);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.rulesSteps.deleteSuccessAction();
		await stepsSection.veripay.rulesSteps.addNewAction(RuleActions.COMPLETE_TASK, completeTaskAction);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const taskInfo = await stepsSection.veripay.caseDetailsSteps.getTaskList();
		expect(taskInfo).toEqual(
			expect.arrayContaining([expect.objectContaining({ title: createTaskAction.title, status: 'Completed' })])
		);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test.skip('Create automation rule with "create workflow instance" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Create Workflow Instance" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-create-workflow-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let createWorkflowInstance: ICreateWorkflowInstanceAction = {
			workflowDefinitionId: '257/LOC',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.CREATE_WORKFLOW_INSTANCE,
			createWorkflowInstance
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const workflowInstancesNumber = await stepsSection.veripay.caseDetailsSteps.getLocRequestedNumber();
		expect(workflowInstancesNumber).toBe(1);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test.skip('Create automation rule with "set value" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Set Value" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-set-value-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let setValue: ISetValueAutomationAction = {
			targetValuePath: ['Current Case Stay', 'Discharge Date'],
			valueSourceType: 'Value',
			dateOperator: 'Specific Date',
			value: new Date(new Date().setMonth(new Date().getMonth() + 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.SET_VALUE_AUTO,
			setValue
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();
		const actualCaseData: IVeripayCaseDetails = await stepsCommon.formReader.getFormData();

		// Assert
		expect(actualCaseData.dischargeDate).toBe(setValue.value);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create automation rule with "change case tracking status" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Change Case Tracking Status" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-change-tracking-status-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let caseTrackingStatus: ICaseTrackingStatusTypeAction = {
			caseTrackingStatusType: 'Tracked',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.CHANGE_CASE_TRACKING_STATUS,
			caseTrackingStatus
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		const trackingStatus = await stepsSection.veripay.caseDetailsSteps.getTrackingStatus();
		expect(trackingStatus).toBe('TRACKED');

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test.skip('Create automation rule with "Remove Case Tag" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Remove Case Tag" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-remove-tag-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let removeCaseTag: IRemoveCaseTagAction = {
			scope: 'General',
			lookupId: 'Long Term',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.REMOVE_CASE_TAG,
			removeCaseTag
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();
		const activeTags = await stepsSection.veripay.caseDetailsSteps.getActiveCaseTerms();

		// Assert
		expect(activeTags.length).toBe(0);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test.skip('Create automation rule with "Remove Case Payer" action', async ({ request }) => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Create automation rule for Veripay Case and add "Remove Case Payer" action.',
		});

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-remove-payer-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let removeCasePayer: IRemoveCasePayerAction = {
			payerPeriod: 'Next',
			payerCategory: 'Other',
		};

		let payerInfo: IVeripayCaseDetails = {
			effectiveDate: new Date(new Date().setDate(new Date().getDate() + 1)).toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
			payerCategoryId: 'Other',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.REMOVE_CASE_PAYER,
			removeCasePayer
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		await stepsSection.veripay.caseDetailsSteps.addPayer(payerInfo);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		const activePayers = await stepsSection.veripay.caseDetailsSteps.getPayersNumber();
		expect(activePayers).toBe(2);
		await stepsSection.veripay.caseDetailsSteps.reloadPage();
		const activePayersAfterRule = await stepsSection.veripay.caseDetailsSteps.getPayersNumber();

		// Assert
		expect(activePayersAfterRule).toBe(1);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Edit rule action from the grid', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create automation rule for Veripay Case and add "Remove Case Payer" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/60845',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: '111111',
			},
		};

		let createTaskAction: ICreateTaskAction = {
			title: `Automation task name ${Date.now()}`,
			lookupTaskCategoryId: '1 No Primary Payers',
		};

		let condition: ICondition = {
			propertyName: ['Case', 'Case Id'],
			comparisonPredicate: 'Equals',
			value: true,
			field: false,
			comparisonValue: '222222',
		};

		// Act
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createAutomationRuleWithAction(
			automationRule,
			RuleActions.CREATE_TASK,
			createTaskAction
		);
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openAutomationRulesTab();

		await stepsCommon.grid.openColumnFilter('name');
		await stepsCommon.columnFilter.fillTextFilter('', 'Equals', automationRule.name);
		await stepsCommon.columnFilter.applyFilter();

		await stepsCommon.grid.clickOnColumnCell(1, 'ruleActions');
		await stepsSection.veripay.rulesSteps.editActionCondition(condition);

		await stepsCommon.grid.clickOnColumnCell(1, 'ruleActions');
		const actualCondition: ICondition = await stepsSection.veripay.rulesSteps.getActionCondition();

		expect(actualCondition.comparisonValue).toEqual(condition.comparisonValue);

		// Teardown
		await apiClient.veripay.deleteRule(ruleId);
	});
});
