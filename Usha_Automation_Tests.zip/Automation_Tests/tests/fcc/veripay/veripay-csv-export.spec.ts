import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testExportGridToCsv } from 'src/test-helpers/index.js';

test.describe('Veripay: export grid to CSV', { tag: ['@fcc', '@veripay', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Export "Veripay Cases" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Veripay Cases" grid to CSV',
		});

		const expectedColumns = [
			'Case Id',
			'Resident Id',
			'Census Status',
			'Full Name',
			'Admission Date',
			'Discharge Date',
			'Payer Category',
			'Payer Status',
			'Payer Name',
			'MCD App Status',
			'A/R',
			'Assets',
			'Facility',
			'Is Tracked',
			'Tracking Started On',
			'Tracking Stopped On',
			'Last Updated On',
			'Last Updated By',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Oakdale');
		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.resetView();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});

	test('Export "Veripay Tasks" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Veripay Cases" grid to CSV',
		});

		const expectedColumns = [
			'#',
			'Priority',
			'Title',
			'Description',
			'Category',
			'Full Name',
			'Due Date',
			'Status',
			'Assigned To',
			'Facility',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Oakdale');
		await stepsCommon.navigation.veripay.openTasksPage();
		await stepsCommon.grid.resetView();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});
});
