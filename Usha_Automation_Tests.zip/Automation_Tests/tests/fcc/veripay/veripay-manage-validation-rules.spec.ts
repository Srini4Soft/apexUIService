import { expect, Page } from '@playwright/test';
import { ApiClient } from 'src/common/api-client/api-client.js';
import { ValidationRuleActions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import {
	IRequiredAction,
	ISetValueValidationAction,
	IValidationRule,
	IVeripayCase,
	IVeripayCaseDetails,
	IWarningAction,
} from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Veripay -> Settings: manage validation rules', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Create validation rule with "Required" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Required" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/60699',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-required-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		// let caseDetails: IVeripayCaseDetails = {
		// 	authorizationNumber: '12345',
		// };

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let requiredAction: IRequiredAction = {
			message: `Required rule message ${Date.now()}`,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.REQUIRED,
			requiredAction
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		// await stepsSection.veripay.caseDetailsSteps.addPreadmissionScreening(caseDetails);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		const validationMessages: string[] = await stepsSection.veripay.caseDetailsSteps.getValidationMessages();

		// Assert
		expect(validationMessages).toContain(requiredAction.message);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create validation rule with "Not Required" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Not Required" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/61216',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		const formcontrolname = 'admissionDate';
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-not-required-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};
		// let caseDetails: IVeripayCaseDetails = {
		// 	authorizationNumber: '12345',
		// };

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			targetProperties: ['Current Case Stay', 'Admission Date'],
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let requiredAction: IRequiredAction = {
			message: `Required rule message ${Date.now()}`,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.NOT_REQUIRED,
			requiredAction
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		// await stepsSection.veripay.caseDetailsSteps.addPreadmissionScreening(caseDetails);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();

		// Assert
		expect(await stepsSection.veripay.caseDetailsSteps.isFieldRequired(formcontrolname)).toBe(false);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create validation rule with "Hidden" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Hidden" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/61203',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-hidden-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};
		// let caseDetails: IVeripayCaseDetails = {
		// 	authorizationNumber: '12345',
		// };

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			targetProperties: ['Current Case Stay', 'Discharge Date'],
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.HIDDEN
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		// await stepsSection.veripay.caseDetailsSteps.addPreadmissionScreening(caseDetails);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		expect(await stepsSection.veripay.caseDetailsSteps.isFieldDisplayed('dischargeDate')).toBe(true);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create validation rule with "Readonly" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Readonly" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/61205',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-readonly-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};
		// let caseDetails: IVeripayCaseDetails = {
		// 	authorizationNumber: '12345',
		// };

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			targetProperties: ['Current Case Stay', 'Discharge Date'],
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.READONLY
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		// await stepsSection.veripay.caseDetailsSteps.addPreadmissionScreening(caseDetails);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		await stepsSection.veripay.caseDetailsSteps.reloadPage();

		// Assert
		expect(await stepsSection.veripay.caseDetailsSteps.isFieldReadonly('dischargeDate')).toBe(true);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create validation rule with "Warning" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Warning" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/61234',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-warning-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};
		// let caseDetails: IVeripayCaseDetails = {
		// 	authorizationNumber: '12345',
		// };

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let warningAction: IWarningAction = {
			message: `Warning rule message ${Date.now()}`,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.WARNING,
			warningAction
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.veripay.caseDetailsSteps.selectCaseTerm(2);
		// await stepsSection.veripay.caseDetailsSteps.addPreadmissionScreening(caseDetails);
		await stepsSection.veripay.caseDetailsSteps.saveReferralDetailsForm();
		const validationMessages: string[] = await stepsSection.veripay.caseDetailsSteps.getValidationMessages();

		// Assert
		expect(validationMessages).toContain(warningAction.message);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});

	test('Create validation rule with "Set Value" action', async ({ request }) => {
		test.info().annotations.push(
			{
				type: 'Test',
				description: 'Create validation rule for Veripay Case and add "Set Value" action.',
			},
			{
				type: 'Work Item',
				description: 'https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/61217',
			}
		);

		// Arrange
		const apiClient = new ApiClient(request);
		let newCase: IVeripayCase = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-case-set-value-${Date.now()}`,
			ssn: Math.floor(100000000 + Math.random() * 900000000).toString(),
		};

		const residentId = await apiClient.veripay.createCase(newCase);

		let validationRule: IValidationRule = {
			name: `autotest-rule-${Date.now()}`,
			targetProperties: ['Current Case Stay', 'Discharge Date'],
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: residentId.toString(),
			},
		};

		let setValueAction: ISetValueValidationAction = {
			type: 'Date',
			valueSourceType: 'Value',
			dateOperator: 'Specific Date',
			value: new Date().toLocaleDateString('en-US', {
				month: '2-digit',
				day: '2-digit',
				year: 'numeric',
			}),
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.veripay.openRulesPage();
		await stepsSection.veripay.rulesSteps.openValidationRulesTab();
		await stepsCommon.grid.resetView();
		const ruleId = await stepsSection.veripay.rulesSteps.createValidationRuleWithAction(
			validationRule,
			ValidationRuleActions.SET_VALUE,
			setValueAction
		);

		await stepsCommon.navigation.veripay.openCasesPage();
		await stepsCommon.grid.openColumnFilter('fullName');
		await stepsCommon.columnFilter.fillTextFilter('Last Name', 'Equals', newCase.lastName);
		await stepsCommon.columnFilter.applyFilter();
		await stepsCommon.grid.openFirstRecord();
		const actualCaseDetails: IVeripayCaseDetails = await stepsCommon.formReader.getFormData();

		// Assert
		expect(actualCaseDetails.dischargeDate).toContain(setValueAction.value);

		// Teardown
		await apiClient.veripay.deleteCase(residentId.toString());
		await apiClient.veripay.deleteRule(ruleId);
	});
});
