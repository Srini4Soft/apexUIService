import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import {
	testEnumCheckboxFilter,
	testEnumDropdownFilter,
	testEnumRadioFilter,
	testMultiEnumCheckboxFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testTextFilter,
	testTextNameFilter,
} from 'src/test-helpers/index.js';

test.describe('RTS -> Referrals grid: column filtering', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	const patternPositive: RegExp = /^\$\d{1,3}(,\d{3})*\.\d{2}$/; // RegExp for: $1.00, $22.00, $999.99, $4,788.00, $65,654,722,322.00
	const patternNegative: RegExp = /^(\(\$\d{1,3}(,\d{3})*\.\d{2}\)|)$/; // RegExp for: ($0.00), ($22.00), ($999.99)
	const patternBlank: RegExp = /^$|^\.\.\.$/; // RegExp for: not empty string or '...'
	const patterNotBlank: RegExp = /\S+/; // RegExp for: not empty string
	const patternOnlyZeroNegative: RegExp = /^\(\$0\.00\)$/; // RegExp for: ($0.00)

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Clear custom filtering on the "Referrals" grid', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test resets the column filter and checks that the number of records in the table is different from what it was when the filter was set.',
		});

		// Arrange
		const columnName = 'payer';
		const columnsToDisplay = ['#', 'Payer'];
		const filterName = 'Payer Category';
		const filterValue = 'Medicare';

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		const expectedRecordsNumber = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openColumnFilter(columnName);
		await stepsCommon.columnFilter.fillEnumCheckboxFilter(filterName, [filterValue]);
		await stepsCommon.columnFilter.applyFilter();
		const filteredRecordsNumber = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(filteredRecordsNumber, ErrorMessages.ROWS_NUMBER_DIFFER).not.toBe(expectedRecordsNumber);

		// Act
		await stepsCommon.grid.openColumnFilter(columnName);
		await stepsCommon.columnFilter.clearFilter();
		const actualRecordsNumber = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(actualRecordsNumber, ErrorMessages.ROWS_NUMBER_SAME).toBe(expectedRecordsNumber);
	});

	[
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Case Id',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Resident Id',
			textNodeIndex: 1,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test number filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testNumberFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'medicaidNumber',
			columnsToDisplay: ['MCD #', '#', 'Resident Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'medicareNumber',
			columnsToDisplay: ['MCR #', '#', 'Resident Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Name',
			filterValue: 'Private Pay',
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name', 'Payer'],
			filterTitle: 'Source Name',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name', 'Payer'],
			filterTitle: 'Hospital Name',
			filterValue: 'Baptist Health Little Rock',
			textNodeIndex: 1,
		},
		{
			columnDefinitionName: 'ssn',
			columnsToDisplay: ['SSN', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'middleName',
			columnsToDisplay: ['Middle Name', '#', 'Resident Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', '#', 'Resident Name'],
			filterTitle: 'Created By',
			textNodeIndex: 3,
		},
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', '#', 'Resident Name'],
			filterTitle: 'Last Updated By',
			textNodeIndex: 3,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'fullName',
			columnsToDisplay: ['Full Name', '#', 'Payer'],
			filterTitle: 'Last Name',
			filterValue: 'Nelson',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'fullName',
			columnsToDisplay: ['Full Name', '#', 'Payer'],
			filterTitle: 'First Name',
			filterValue: 'Sheila',
			textNodeIndex: 1,
		},
		{
			columnDefinitionName: 'residentName',
			columnsToDisplay: ['Resident Name', '#', 'Payer'],
			filterTitle: 'Last Name',
			filterValue: 'Nelson',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'residentName',
			columnsToDisplay: ['Resident Name', '#', 'Payer'],
			filterTitle: 'First Name',
			filterValue: 'Sheila',
			textNodeIndex: 1,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text name filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text name filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextNameFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Resident Name'],
			filterTitle: '',
			filterValue: 'Medicare',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: 'Payer Category',
			filterValue: 'Commercial',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'leads',
			columnsToDisplay: ['Lead', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'Blank',
			expectedPattern: patternBlank,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'leads',
			columnsToDisplay: ['Lead', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'Not Blank',
			expectedPattern: patterNotBlank,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'tags',
			columnsToDisplay: ['Tags', '#', 'Full Name', 'Payer'],
			filterTitle: 'Scope',
			filterValue: 'General',
			filterType: 'eye',
			expectedValue: 'General:',
			sortingColumn: '#',
			textNodeIndex: 0,
		} as IColumnFilterTestData,
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test multi checkbox filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default multi checkbox filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testMultiEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'asset',
			columnsToDisplay: ['Assets', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Positive Asset',
			expectedPattern: patternPositive,
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'asset',
			columnsToDisplay: ['Assets', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'No Asset',
			expectedPattern: patternOnlyZeroNegative,
			textNodeIndex: undefined,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Incomes', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Positive Income',
			expectedPattern: patternPositive,
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Incomes', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'Negative Income',
			expectedPattern: patternNegative,
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'income',
			columnsToDisplay: ['Incomes', '#', 'Full Name', 'Payer'],
			filterTitle: '',
			filterValue: 'No Income',
			expectedPattern: patternOnlyZeroNegative,
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test radio filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumRadioFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastUpdatedOn',
			columnsToDisplay: ['Last Updated On', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test date filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testPresetDateRangeFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'status',
			columnsToDisplay: ['Status', '#', 'Full Name'],
			filterTitle: 'Is Readmission',
			filterValue: 'Yes',
			expectedValue: 'Readmission',
			textNodeIndex: 1,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test enum dropdown filters in "Referrals" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Referrals" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default enum dropdown filter.`,
			});

			await stepsCommon.navigation.rts.openReferralsPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumDropdownFilter(testData);
		});
	});

	test('Filter "Referrals" grid by column "Status"', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: `This test filters "Status" column`,
		});

		// Arrange
		const columnName = 'status';
		const columnsToDisplay = ['Status', '#'];
		const filterValues = {
			NEW: 'New',
			REVIEW: 'Review',
			IN_REVIEW: 'In Review',
			DECLINED_PENDING: 'Declined Pending',
			PENDING_CLINICAL_APPROVAL: 'Pending Clinical Approval',
			PENDING_FINANCIAL_APPROVAL: 'Pending Financial Approval',
			BED_OFFER_PENDING: 'Bed Offer Pending',
			TEST: 'Test',
			REJECT: 'Reject',
			DECLINED: 'Declined',
			CANCELLED: 'Cancelled',
			LOST: 'Lost',
			APPROVE: 'Approve',
			ACCEPTED: 'Accepted',
			ADMIT: 'Admit',
			ADMITTED: 'Admitted',
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		await stepsCommon.grid.openColumnFilter(columnName);
		await stepsCommon.columnFilter.fillSelectTreeFilter('', [filterValues.ADMITTED]);
		await stepsCommon.columnFilter.applyFilter();
		const resultBeforeSorting = await stepsCommon.grid.getColumnTextValues(columnName);
		await stepsCommon.grid.sortColumn(columnName);
		const resultAfterSorting = await stepsCommon.grid.getColumnTextValues(columnName);

		// Assert
		resultBeforeSorting.forEach((array) =>
			expect.soft(array[0], ErrorMessages.COMPARE_VALUES(array[0]!, filterValues.ADMITTED)).toBe(filterValues.ADMITTED)
		);
		resultAfterSorting.forEach((array) =>
			expect.soft(array[0], ErrorMessages.COMPARE_VALUES(array[0]!, filterValues.ADMITTED)).toBe(filterValues.ADMITTED)
		);
	});

	test('Filter "Referrals" grid by column "Payer Name"', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test filters "Payer" column by "Payer Name" filter',
		});

		// Arrange
		const columnName = 'payer';
		const columnsToDisplay = ['Payer', '#'];
		const filterCondition = 'Blank';

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		const recordsNumberBefore = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openColumnFilter(columnName);
		await stepsCommon.columnFilter.fillTextFilter('', filterCondition);
		await stepsCommon.columnFilter.applyFilter();
		const recordsNumberAfter = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(recordsNumberAfter, ErrorMessages.ROWS_NUMBER_DIFFER).not.toBe(recordsNumberBefore);
	});

	test('Filter "Referrals" grid by column "Payer Status"', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test filters "Payer" column by "Payer Status" filter',
		});
		// Arrange
		const columnName = 'payer';
		const columnsToDisplay = ['Payer', '#'];
		const filterName = 'Payer Status';
		const filterValue = 'Pending';

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);
		const recordsNumberBefore = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openColumnFilter(columnName);
		await stepsCommon.columnFilter.fillBooleanFilter(filterName, filterValue);
		await stepsCommon.columnFilter.applyFilter();
		const recordsNumberAfter = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(recordsNumberAfter, ErrorMessages.ROWS_NUMBER_DIFFER).not.toBe(recordsNumberBefore);
	});
});
