import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('RTS Referrals grid: add and remove columns', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Should display all columns when select all columns in settings', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that the table displays all the columns that are set in the settings',
		});
		// Arrange
		const expectedColumns: string[] = ['Lead', 'State', 'NRI', 'Physician'];

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(['All']);
		const actualColumns: string[] = await stepsCommon.grid.getColumnNames();

		// Assert
		expect.soft(actualColumns, ErrorMessages.NO_COLUMN(expectedColumns[0]!)).toContainEqual(expectedColumns[0]!);
		expect.soft(actualColumns, ErrorMessages.NO_COLUMN(expectedColumns[1]!)).toContainEqual(expectedColumns[1]!);
		expect.soft(actualColumns, ErrorMessages.NO_COLUMN(expectedColumns[2]!)).toContainEqual(expectedColumns[2]!);
		expect.soft(actualColumns, ErrorMessages.NO_COLUMN(expectedColumns[3]!)).toContainEqual(expectedColumns[3]!);
	});

	test('Should display default columns after reset view', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that the table displays only default columns after reset view',
		});
		// Arrange
		const notExpectedColumns: string[] = ['Lead', 'State', 'NRI', 'Physician'];
		const expectedNumberOfColumns = 70;

		// Act
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		const selectedColumns: string[] = await stepsCommon.grid.selectColumnsToDisplay(['All']);

		// Assert
		expect(selectedColumns.length, `Is the number of columns greater then ${expectedNumberOfColumns}?`).toBeGreaterThan(
			expectedNumberOfColumns
		);

		// Act
		await stepsCommon.grid.resetView();
		const actualColumns: string[] = await stepsCommon.grid.getColumnNames();

		// Assert
		expect
			.soft(actualColumns, ErrorMessages.EXTRA_COLUMN(notExpectedColumns[0]!))
			.not.toContainEqual(notExpectedColumns[0]!);
		expect
			.soft(actualColumns, ErrorMessages.EXTRA_COLUMN(notExpectedColumns[1]!))
			.not.toContainEqual(notExpectedColumns[1]!);
		expect
			.soft(actualColumns, ErrorMessages.EXTRA_COLUMN(notExpectedColumns[2]!))
			.not.toContainEqual(notExpectedColumns[2]!);
		expect
			.soft(actualColumns, ErrorMessages.EXTRA_COLUMN(notExpectedColumns[3]!))
			.not.toContainEqual(notExpectedColumns[3]!);
	});
});
