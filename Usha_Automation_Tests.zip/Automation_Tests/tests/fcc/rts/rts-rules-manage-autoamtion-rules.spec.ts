import { expect, Page } from '@playwright/test';
import { RuleActions } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IAddCaseNoteAction, IAutomationRule, IReferralCreate } from 'src/common/models/index.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('RTS -> Settings: manage automation rules', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test.fixme('Create automation rule', async () => {
		// Need more info from manual QA about how to fill details form
		test.info().annotations.push({
			type: 'Test',
			description: 'This test creates referral, then creates automation rule for this referral.',
		});

		// Arrange
		let referral: IReferralCreate = {
			facilityId: 'The Blossoms at Midtown Rehab',
			lastName: `autotest-referral-${Date.now()}`,
		};
		let automationRule: IAutomationRule = {
			name: `autotest-rule-${Date.now()}`,
			isEnabled: true,
			isGlobal: true,
			condition: {
				propertyName: ['Case', 'Case Id'],
				comparisonPredicate: 'Equals',
				value: true,
				field: false,
				comparisonValue: '',
			},
		};
		let addCaseNote: IAddCaseNoteAction = {
			message: `Automation test note ${Date.now()}`,
			isAggregateMessage: false,
		};

		// Act
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.resetView();
		await stepsSection.rts.referralsSteps.createReferral(referral);
		const residentId = stepsSection.rts.referralsSteps.getReferralId();
		await stepsSection.rts.referralsSteps.finishReferralDetailsForm();

		automationRule.condition!.comparisonValue = residentId;
		await stepsCommon.navigation.rts.openRulesPage();
		await stepsSection.rts.rulesSteps.openAutomationRulesTab();
		await stepsSection.rts.rulesSteps.createRuleWithAction(automationRule, RuleActions.ADD_CASE_NOTE, addCaseNote);

		await stepsCommon.navigation.rts.openReferralsPage();
		await stepsCommon.grid.search(residentId);
		await stepsCommon.grid.openFirstRecord();
		await stepsSection.rts.referralsSteps.saveReferralDetailsForm();
		await stepsSection.rts.referralsSteps.reloadPage();

		const currentNotes: string[] = await stepsSection.rts.referralsSteps.getNotes();

		// Assert
		expect(currentNotes, 'The list of notes does not contain the required entry').toContain(addCaseNote.message);
	});
});
