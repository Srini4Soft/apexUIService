import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { IColumnFilterTestData } from 'src/common/models/index.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import {
	testBooleanFilter,
	testCheckboxListFilter,
	testEnumCheckboxFilter,
	testIconsBooleanFilter,
	testNumberFilter,
	testPresetDateRangeFilter,
	testTextFilter,
} from 'src/test-helpers/index.js';

test.describe('Residents -> Master Data grid: column filtering', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Clear custom filtering on the "Residents Master Data" grid', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'This test checks that the custom filter is reset after clicking the button in the column filter',
		});

		// Arrange
		const columnDefinitionName = 'payer';
		const columnsToDisplay = ['Payer'];
		const filterName = 'Payer Category';
		const filterValue = 'Medicare';

		// Act
		await stepsCommon.navigation.residents.openMasterDataPage();
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.setPageSize(100);

		const expectedRecordsNumber = await stepsCommon.grid.getTotalRecordCount();
		await stepsCommon.grid.openColumnFilter(columnDefinitionName);
		await stepsCommon.columnFilter.fillEnumCheckboxFilter(filterName, [filterValue]);
		await stepsCommon.columnFilter.applyFilter();
		const filteredRecordsNumber = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(expectedRecordsNumber, ErrorMessages.ROWS_NUMBER_DIFFER).not.toBe(filteredRecordsNumber);

		// Act
		await stepsCommon.grid.openColumnFilter(columnDefinitionName);
		await stepsCommon.columnFilter.clearFilter();
		const actualRecordsNumber = await stepsCommon.grid.getTotalRecordCount();

		// Assert
		expect(expectedRecordsNumber, ErrorMessages.ROWS_NUMBER_SAME).toBe(actualRecordsNumber);
	});

	[
		{
			columnDefinitionName: '#',
			columnsToDisplay: ['#', 'Full Name', 'Payer'],
			filterTitle: 'Resident Id',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'outstandingBalance',
			columnsToDisplay: ['A/R', '#', 'Full Name'],
			filterTitle: 'A/R',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'residentId',
			columnsToDisplay: ['Resident Id', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test number filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default numerical filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testNumberFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payerName',
			columnsToDisplay: ['Payer Name', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'medicaidNumber',
			columnsToDisplay: ['MCD #', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'medicareNumber',
			columnsToDisplay: ['MCR #', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{ columnDefinitionName: 'ssn', columnsToDisplay: ['SSN', '#', 'Full Name'], filterTitle: '', textNodeIndex: 0 },
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 3,
		},
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 3,
		},
		{
			columnDefinitionName: 'fullBedNumber',
			columnsToDisplay: ['Bed', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'policyNumber',
			columnsToDisplay: ['Policy #', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test text filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default text filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testTextFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'payer',
			columnsToDisplay: ['Payer', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'Commercial',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testEnumCheckboxFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name'],
			filterTitle: 'With sources',
			filterValue: 'PCC',
			expectedPattern: /\bPCC\b/,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name'],
			filterTitle: 'With sources',
			filterValue: 'MCR',
			expectedPattern: /\bMedicare\b/,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name'],
			filterTitle: 'Without sources',
			filterValue: 'PCC',
			expectedPattern: /^(?!.*\bPCC\b).*/,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'source',
			columnsToDisplay: ['Source', '#', 'Full Name'],
			filterTitle: 'Without sources',
			filterValue: 'MCR',
			expectedPattern: /^(?!.*\bMedicare\b).*/,
			sortingColumn: '#',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test checkbox list filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default checkbox filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testCheckboxListFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'discrepancy',
			columnsToDisplay: ['Discrepancy', '#', 'Full Name'],
			filterTitle: 'Discrepancy',
			filterValue: 'True',
			expectedValue: 'Yes',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'discrepancy',
			columnsToDisplay: ['Discrepancy', '#', 'Full Name'],
			filterTitle: 'Discrepancy',
			filterValue: 'False',
			expectedValue: 'No',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test radio filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testBooleanFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'hasDuplicates',
			columnsToDisplay: ['Has Duplicates', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'True',
			expectedIcon: true,
			expectedValue: 'success',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'hasDuplicates',
			columnsToDisplay: ['Has Duplicates', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'False',
			expectedIcon: true,
			expectedValue: 'cancel',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'isBedhold',
			columnsToDisplay: ['Bedhold', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'True',
			expectedIcon: true,
			expectedValue: 'success',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'isBedhold',
			columnsToDisplay: ['Bedhold', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'False',
			expectedIcon: true,
			expectedValue: 'cancel',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'expired',
			columnsToDisplay: ['Expired', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'True',
			expectedIcon: true,
			expectedValue: 'success',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'expired',
			columnsToDisplay: ['Expired', '#', 'Full Name'],
			filterTitle: '',
			filterValue: 'False',
			expectedIcon: true,
			expectedValue: 'cancel',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test radio icon filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default radio filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testIconsBooleanFilter(testData);
		});
	});

	[
		{
			columnDefinitionName: 'admissionDate',
			columnsToDisplay: ['Admission', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'birthDate',
			columnsToDisplay: ['DOB', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'created',
			columnsToDisplay: ['Created', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
		{
			columnDefinitionName: 'lastUpdated',
			columnsToDisplay: ['Last Updated', '#', 'Full Name'],
			filterTitle: '',
			textNodeIndex: 0,
		},
	].forEach((testData: IColumnFilterTestData) => {
		test(`Test date filters in "Residents Master Data" grid. Column: "${testData.columnsToDisplay[0]}", filter: "${testData.filterTitle}", value: "${testData.filterValue}" or default`, async () => {
			test.info().annotations.push({
				type: 'Test',
				description: `This test opens "Residents Master Data" grid and filters "${testData.columnsToDisplay[0]}" column by "${testData.filterTitle}" filter or uses default date filter.`,
			});

			await stepsCommon.navigation.residents.openMasterDataPage();
			await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
			await stepsCommon.grid.resetView();
			await stepsCommon.grid.selectColumnsToDisplay(testData.columnsToDisplay);
			await stepsCommon.grid.setPageSize(25);

			await testPresetDateRangeFilter(testData);
		});
	});
});
