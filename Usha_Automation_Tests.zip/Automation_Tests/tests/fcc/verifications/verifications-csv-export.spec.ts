import { Page } from '@playwright/test';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { CommonStepsFacade } from 'src/steps/index.js';
import { testExportGridToCsv } from 'src/test-helpers/index.js';

test.describe('Verifications: export grid to CSV', { tag: ['@fcc', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Export "Verifications" grid to CSV', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Exports "Verifications" grid to CSV',
		});

		const expectedColumns = [
			'Verification Request Id',
			'Resident Id',
			'Resident Last Name',
			'Resident First Name',
			'Verification Payer Category',
			'Payer Name',
			'Eligible',
			'Created On',
			'Created By',
			'Facility',
		];

		await stepsCommon.facilityFilter.selectPortfolioByName('Oakdale');
		await stepsCommon.navigation.verifications.openVerificationListPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.openColumnFilter('payer');
		await stepsCommon.columnFilter.fillEnumCheckboxFilter('Verification Payer Category', ['Commercial']);
		await stepsCommon.columnFilter.applyFilter();

		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		await testExportGridToCsv(page, expectedColumns, expectedTotalRowsCount);
	});
});
