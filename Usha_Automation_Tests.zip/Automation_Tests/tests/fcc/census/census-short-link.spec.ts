import { expect, Page } from '@playwright/test';
import { DateRange, ErrorMessages } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import { ColumnFiltersSteps, CommonStepsFacade, GridSteps } from 'src/steps/index.js';

test.describe('Census: short link', { tag: ['@fcc', '@smoke', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsGrid: GridSteps;
	let stepsColumnFilters: ColumnFiltersSteps;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsGrid = new GridSteps();
		stepsColumnFilters = new ColumnFiltersSteps();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Short link to the "Census Changes" grid', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Saves a short link to the grid and checks that it opens correctly',
		});

		const filteredColumn = 'changeType';
		const filterValue = 'Primary Payer Change';
		const columnsToDisplay = ['Case Id', 'Change Type', 'Facility'];

		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.census.openChangesPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsGrid.openColumnFilter(filteredColumn);
		await stepsColumnFilters.fillEnumCheckboxFilter('', [filterValue]);
		await stepsColumnFilters.applyFilter();
		const expectedColumns = await stepsGrid.getColumnNames();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();
		const link = await stepsCommon.shareLink.getShortLink();
		await stepsCommon.grid.resetView();

		await page.goto(link);
		await stepsCommon.waitForPageLoad();

		const actualColumns = await stepsGrid.getColumnNames();
		const actualTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		expect(actualColumns, ErrorMessages.GRID_SAME_COLUMNS).toEqual(expectedColumns);
		expect(actualTotalRowsCount, ErrorMessages.ROWS_NUMBER_DIFFER).toEqual(expectedTotalRowsCount);
	});

	test('Short link to the "Census Residents" grid', async () => {
		test.info().annotations.push({
			type: 'Test',
			description: 'Saves a short link to the grid and checks that it opens correctly',
		});

		const filteredColumn = 'censusDate';
		const columnsToDisplay = ['#', 'Source', 'Census Date'];

		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		await stepsCommon.navigation.census.openResidentsPage();
		await stepsCommon.grid.resetView();
		await stepsCommon.grid.selectColumnsToDisplay(columnsToDisplay);
		await stepsCommon.grid.openColumnFilter(filteredColumn);
		await stepsCommon.columnFilter.fillDateRangePeriodFilter(DateRange.ALL_TIME);
		await stepsCommon.columnFilter.applyFilter();
		const expectedColumns = await stepsGrid.getColumnNames();
		const expectedTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();
		const link = await stepsCommon.shareLink.getShortLink();
		await stepsCommon.grid.resetView();

		await page.goto(link);
		await stepsCommon.waitForPageLoad();

		const actualColumns = await stepsGrid.getColumnNames();
		const actualTotalRowsCount = await stepsCommon.grid.getTotalRecordCount();

		expect(actualColumns, ErrorMessages.GRID_SAME_COLUMNS).toEqual(expectedColumns);
		expect(actualTotalRowsCount, ErrorMessages.ROWS_NUMBER_DIFFER).toEqual(expectedTotalRowsCount);
	});
});
