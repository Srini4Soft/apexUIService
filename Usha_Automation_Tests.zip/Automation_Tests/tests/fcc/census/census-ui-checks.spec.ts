import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbs } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the Census section',
	{ tag: ['@fcc', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for Census -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openDashboardPage();
			await stepsCommon.dashboard.selectDashboardByPositionNumber(1);

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'Dashboard');
			await stepsCommon.dashboard.verifyDashboardSettingsButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyWidgetTitleIsVisible('Census Overview');
			await stepsSection.census.uiAssertions.verifyExpandCollapseButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyMonthButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyWeekButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyDayButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyNextPeriodButtonIsVisible();
			await stepsSection.census.uiAssertions.verifyCalendarButtonIsVisible();
		});

		test('UI checks for Census -> API Requests page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openApiRequestsPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'API Requests');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Census -> Changes page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openChangesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'Census Changes');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Census -> Residents page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openResidentsPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'Census Residents');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Census -> Automation Rules page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openAutomationRulesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'Automation Rules');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Census -> Data Discrepancies page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.census.openDataDiscrepanciesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Census', 'Data Discrepancies');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});
	}
);
