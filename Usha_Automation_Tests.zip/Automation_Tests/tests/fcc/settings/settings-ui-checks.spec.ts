import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/error-massages.enum.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';
import { testBreadcrumbs } from 'src/test-helpers/breadcrumbs-test.helper.js';

test.describe(
	'Tests that check the presence of UI elements on pages in the Settings section',
	{ tag: ['@fcc', '@regression'] },
	() => {
		let page: Page;
		let consoleErrors: string[] = [];
		let stepsCommon: CommonStepsFacade;
		let stepsSection: SectionStepsFacade;

		test.beforeAll(async ({ browser }) => {
			page = await browser.newPage();
			PageInstance.getInstance().setPage(page);

			stepsCommon = new CommonStepsFacade();
			stepsSection = new SectionStepsFacade();

			await page.goto('/');
			await stepsCommon.waitForPageLoad();
			await stepsCommon.facilityFilter.selectAllPortfolios();
		});

		test.afterAll(async () => {
			await PageInstance.getInstance().closePage();
		});

		test.beforeEach(async () => {
			consoleErrors = [];
			page.on('console', (msg) => {
				log.info(`Console message: [${msg.type()}] ${msg.text()}`);
				if (msg.type() === 'error') {
					consoleErrors.push(msg.text());
				}
			});
		});

		test('UI checks for Settings -> Dashboard page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openDashboardPage();
			await stepsCommon.dashboard.selectDashboardByPositionNumber(1);

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Dashboard');
			await stepsCommon.dashboard.verifyDashboardSettingsButtonIsVisible();
		});

		test('UI checks for Settings -> Event Log page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openEventLogPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Events & Notifications', 'Event Log');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Settings -> Notification Rules page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openNotificationRulesPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Events & Notifications', 'Notification Rules');
			await stepsSection.settings.uiAssertions.verifyCreateNotificationRuleButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Settings -> Manage Entities -> Lookup page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openManageEntitiesPage();
			await stepsSection.settings.manageEntitiesSteps.openLookupsTab();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Entities Management', 'Lookups');
			await stepsSection.settings.uiAssertions.verifyCreateEntityButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Settings -> Manage Entities -> Payers page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openManageEntitiesPage();
			await stepsSection.settings.manageEntitiesSteps.openPayersTab();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Entities Management', 'Payers');
			await stepsSection.settings.uiAssertions.verifyCreateEntityButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Settings -> Mapping List page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openMappingListPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Mapping', 'Mapping List');
			await stepsSection.settings.uiAssertions.verifyCreateMappingButtonIsVisible();
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});

		test('UI checks for Settings -> Missing Mappings page', async () => {
			test.info().annotations.push({
				type: 'Test',
				description: 'Ensure that all required UI elements are displayed correctly and are accessible',
			});

			// Act
			await stepsCommon.navigation.settings.openMissingMappingsPage();
			await stepsCommon.grid.resetView();

			// Assert
			expect.soft(consoleErrors.length, ErrorMessages.ERRORS_IN_CONSOLE).toBe(0);
			await testBreadcrumbs('Settings', 'Mapping', 'Missing Mappings');
			await stepsCommon.grid.verifyMenuButtonIsVisible();
			await stepsCommon.grid.verifySearchButtonIsVisible();
			await stepsCommon.grid.verifySelectAllButtonIsVisible();
			await stepsCommon.grid.verifyPageSizeSelectorIsVisible();
			await stepsCommon.grid.verifyPreviousPageButtonIsVisible();
			await stepsCommon.grid.verifyPagesListIsVisible();
			await stepsCommon.grid.verifyNextPageButtonIsVisible();
		});
	}
);
