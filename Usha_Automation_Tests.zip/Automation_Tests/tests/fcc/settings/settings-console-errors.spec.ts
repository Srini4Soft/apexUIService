import { expect, Page } from '@playwright/test';
import { ErrorMessages } from 'src/common/enums/index.js';
import { test } from 'src/common/fixtures/test-fixture.js';
import { PageInstance } from 'src/common/helpers/page-instance.js';
import log from 'src/common/utils/logger.js';
import { CommonStepsFacade, SectionStepsFacade } from 'src/steps/index.js';

test.describe('Settings: Entities management', { tag: ['@fcc', '@regression'] }, () => {
	let page: Page;
	let stepsCommon: CommonStepsFacade;
	let stepsSection: SectionStepsFacade;

	test.beforeAll(async ({ browser }) => {
		page = await browser.newPage();
		PageInstance.getInstance().setPage(page);

		stepsCommon = new CommonStepsFacade();
		stepsSection = new SectionStepsFacade();

		await page.goto('/');
		await stepsCommon.waitForPageLoad();
	});

	test.afterAll(async () => {
		await PageInstance.getInstance().closePage();
	});

	test('Open "Notification Rules" grid without errors', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test opens "Notification Rules" page, then opens existing rule and checks the browser console for errors',
		});

		// Arrange
		const consoleErrors: string[] = [];

		// Act
		await stepsCommon.navigation.settings.openDashboardPage();
		await stepsCommon.facilityFilter.selectPortfolioByName('Blossom');
		page.on('console', (message) => {
			log.info(`Console message: [${message.type()}] ${message.text()}`);
			if (message.type() === 'error') {
				consoleErrors.push(message.text());
			}
		});
		await stepsCommon.navigation.settings.openNotificationRulesPage();
		await stepsCommon.grid.openFirstRecord();

		// Assert
		expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);
	});

	test('Open "Manage Entities" page "People" grid without errors', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test opens "Manage Entities" page, then opens "People" tab and checks the browser console for errors',
		});

		// Arrange
		const consoleErrors: string[] = [];

		// Act
		await stepsCommon.navigation.settings.openDashboardPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		page.on('console', (message) => {
			log.info(`Console message: [${message.type()}] ${message.text()}`);
			if (message.type() === 'error') {
				consoleErrors.push(message.text());
			}
		});
		try {
			await stepsSection.settings.manageEntitiesSteps.openPeoplePage(90000);
		} catch (error) {
			log.info(ErrorMessages.PAGE_STUCK);
		}

		// Assert
		expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);
	});

	test('Open "Manage Entities" page "Payers" grid without errors', async () => {
		test.info().annotations.push({
			type: 'Test',
			description:
				'This test opens "Manage Entities" page, then opens "Payers" tab, select all facility, available grid fields and checks the browser console for errors (https://dev.azure.com/axgsolutions/Apex%20RMP/_workitems/edit/58838).',
		});

		// Arrange
		let consoleErrors: string[] = [];

		// Act
		await stepsCommon.navigation.settings.openDashboardPage();
		await stepsCommon.facilityFilter.selectAllPortfolios();
		page.on('console', (message) => {
			log.info(`Console message: [${message.type()}] ${message.text()}`);
			if (message.type() === 'error') {
				consoleErrors.push(message.text());
			}
		});
		try {
			await stepsSection.settings.manageEntitiesSteps.openPayersPage(90000);
		} catch (error) {
			log.info(ErrorMessages.PAGE_STUCK);
		}
		await stepsCommon.grid.resetView();

		// Assert
		expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);

		// Act
		consoleErrors = [];
		await stepsCommon.grid.selectColumnsToDisplay(['All']);

		// Assert
		expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);

		// Act
		consoleErrors = [];
		await stepsCommon.grid.resetView();

		// Assert
		expect(consoleErrors, ErrorMessages.ERRORS_IN_CONSOLE).toEqual([]);
	});
});
